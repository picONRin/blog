import os
import json
import time
import socket
import threading
import pickle
import base64

class InterProcessCommunication:
    def __init__(self, app_name='reading_timer'):
        self.app_name = app_name
        self.data_dir = 'data'
        os.makedirs(self.data_dir, exist_ok=True)
        self.state_file = os.path.join(self.data_dir, f'{app_name}_state.json')
        self.progress_file = os.path.join(self.data_dir, 'progress_sync.json')
        self.port = 12345
        self.listening = False
        self.lock = threading.Lock()

    def write_state(self, state_type, data):
        try:
            state = {'type': state_type, 'data': data, 'timestamp': time.time(), 'pid': os.getpid()}
            with open(self.state_file, 'w', encoding='utf-8') as f:
                json.dump(state, f, ensure_ascii=False)
            if state_type == 'timer_update':
                timer_data = data.get('data', data)
                if isinstance(timer_data, dict):
                    total = timer_data.get('total_seconds', 0)
                    remaining = timer_data.get('remaining_seconds', 0)
                    if total > 0:
                        elapsed = total - remaining
                        progress = min(100.0, max(0.0, elapsed / total * 100))
                        self._write_progress_sync(progress)
            return True
        except Exception:
            return False

    def read_state(self, clear_after_read=True, max_age=60):
        try:
            if not os.path.exists(self.state_file):
                return None
            with open(self.state_file, 'r', encoding='utf-8') as f:
                state = json.load(f)
            if time.time() - state.get('timestamp', 0) > max_age:
                if clear_after_read:
                    try:
                        os.remove(self.state_file)
                    except:
                        pass
                return None
            if clear_after_read:
                try:
                    os.remove(self.state_file)
                except:
                    pass
            return state
        except Exception:
            return None

    def _write_progress_sync(self, progress_percent):
        with self.lock:
            try:
                data = {'session_progress': float(progress_percent), 'timestamp': time.time()}
                with open(self.progress_file, 'w', encoding='utf-8') as f:
                    json.dump(data, f, ensure_ascii=False)
                return True
            except Exception:
                return False

    def read_progress_sync(self):
        with self.lock:
            try:
                if os.path.exists(self.progress_file):
                    with open(self.progress_file, 'r', encoding='utf-8') as f:
                        sync_data = json.load(f)
                    if time.time() - sync_data.get('timestamp', 0) < 2:
                        return sync_data.get('session_progress', 0.0)
                state = self.read_state(clear_after_read=False, max_age=5)
                if state and state.get('type') == 'timer_update':
                    timer_data = state.get('data', {})
                    total = timer_data.get('total_seconds', 0)
                    remaining = timer_data.get('remaining_seconds', 0)
                    if total > 0:
                        elapsed = total - remaining
                        progress = min(100.0, max(0.0, elapsed / total * 100))
                        self._write_progress_sync(progress)
                        return progress
                shop_data_path = os.path.join(self.data_dir, 'shop_data.json')
                if os.path.exists(shop_data_path):
                    with open(shop_data_path, 'r', encoding='utf-8') as f:
                        shop_data = json.load(f)
                    stats = shop_data.get('stats', {})
                    progress = stats.get('session_progress', 0.0)
                    return progress
                return 0.0
            except Exception:
                return 0.0

    def force_update_progress(self, progress_percent):
        return self._write_progress_sync(progress_percent)

    def check_for_message(self, timeout=5, check_interval=0.5):
        start_time = time.time()
        while time.time() - start_time < timeout:
            state = self.read_state(clear_after_read=False)
            if state:
                return state
            time.sleep(check_interval)
        return None

    def send_restore_signal(self, target_pid=None):
        try:
            flag_file = os.path.join(self.data_dir, 'restore_flag.txt')
            with open(flag_file, 'w') as f:
                f.write(f'restore_{int(time.time())}')
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(2)
                sock.connect(('localhost', self.port))
                sock.send(b'RESTORE')
                sock.close()
            except:
                pass
            return True
        except Exception:
            return False

    def start_listener(self, callback, port=None):
        if port:
            self.port = port

        def listener_thread():
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                sock.bind(('localhost', self.port))
                sock.listen(1)
                sock.settimeout(1)
                self.listening = True
                while self.listening:
                    try:
                        conn, addr = sock.accept()
                        data = conn.recv(1024)
                        if data:
                            callback(data.decode())
                        conn.close()
                    except socket.timeout:
                        continue
                    except Exception:
                        continue
                sock.close()
            except Exception:
                pass
        self.listening = True
        threading.Thread(target=listener_thread, daemon=True).start()

    def stop_listener(self):
        self.listening = False

    def encode_data(self, data):
        try:
            return base64.b64encode(pickle.dumps(data)).decode()
        except Exception:
            return None

    def decode_data(self, encoded_data):
        try:
            return pickle.loads(base64.b64decode(encoded_data))
        except Exception:
            return None
