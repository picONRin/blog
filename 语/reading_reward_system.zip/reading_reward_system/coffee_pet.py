import tkinter as tk
from tkinter import messagebox
import json
import os
import sys
import threading
import time
from pathlib import Path
from PIL import Image, ImageTk
import subprocess
import pickle
import base64
import socket
import webbrowser

DATA_FILE = "data/shop_data.json"

def load_shop_data():
    if not os.path.exists(DATA_FILE):
        default_data = {
            "coffee_beans": 0,
            "purchased_items": ["coffee_caramel"],
            "equipped": {
                "background": "bg_none",
                "coffee_pet": "coffee_caramel"
            },
            "achievements": {
                "focus_count": 0,
                "current_barista": "普通顾客",
                "unlocked_baristas": ["普通顾客"]
            },
            "stats": {
                "total_focus_time": 0,
                "total_pages": 0,
                "current_session_time": 0,
                "session_progress": 0.0
            }
        }
        save_shop_data(default_data)
        return default_data
    
    try:
        with open(DATA_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
    except Exception:
        return {
            "coffee_beans": 0,
            "equipped": {"coffee_pet": "coffee_caramel"},
            "stats": {"session_progress": 0.0}
        }
    
    if "coffee_beans" not in data:
        coffee_beans = 0
        
        if "beans" in data and isinstance(data["beans"], dict) and "focus_beans" in data["beans"]:
            coffee_beans += data["beans"]["focus_beans"]
        
        if "beans" in data and isinstance(data["beans"], dict) and "reading_beans" in data["beans"]:
            coffee_beans += data["beans"]["reading_beans"]
        
        data["coffee_beans"] = coffee_beans
        
        if "beans" in data:
            data.pop("beans", None)
    
    return data

def save_shop_data(data):
    os.makedirs("data", exist_ok=True)
    data.pop("focus_beans", None)
    data.pop("reading_beans", None)
    
    with open(DATA_FILE, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def add_coffee_beans(n=1):
    data = load_shop_data()
    data["coffee_beans"] = data.get("coffee_beans", 0) + n
    save_shop_data(data)
    return data["coffee_beans"]

def get_coffee_beans():
    data = load_shop_data()
    return data.get("coffee_beans", 0)

try:
    from communication import InterProcessCommunication
    COMM_AVAILABLE = True
except ImportError:
    COMM_AVAILABLE = False
    InterProcessCommunication = None

class CoffeePet:
    def __init__(self, floating_window_pid=None, timer_state=None, window_pos=None):
        self.window = None
        self.current_drink = None
        self.current_variant = None
        self.tk_image = None
        self.drag_data = {"x": 0, "y": 0}
        self.is_locked = False
        self.is_transparent = True
        self.pet_state = "desk"
        self.session_progress = 0.0
        
        self.floating_window_pid = floating_window_pid
        self.timer_state = timer_state
        self.window_pos = window_pos
        
        self.comm_port = 12345
        self.stop_comm = False
        
        self.comm = InterProcessCommunication("reading_timer") if COMM_AVAILABLE else None
        self.last_timer_state = None
        self.current_timer_display = ""
        self.is_timer_running = False
        self.timer_remaining = 0
        
        self.load_current_drink()
        self.create_window()
        self.start_communication_server()
        
        if self.comm:
            self.window.after(1000, self.check_timer_sync)
        
        self.window.after(100, self.check_progress_update)
    
    def load_current_drink(self):
        try:
            data = load_shop_data()
            
            equipped = data.get("equipped")
            if not isinstance(equipped, dict):
                equipped = {}
            
            self.current_drink = equipped.get("coffee_pet", "coffee_caramel")
            
            drink_mapping = {
                "coffee_caramel": "01",
                "coffee_seasonal": "02",
                "coffee_chocolate": "03",
                "coffee_diy": "diy",
                "coffee_matcha": "matcha"
            }
            self.current_variant = drink_mapping.get(self.current_drink, "01")
            
            stats = data.get("stats")
            if not isinstance(stats, dict):
                stats = {}
            
            if self.comm:
                realtime_progress = self.comm.read_progress_sync()
                if realtime_progress is not None:
                    self.session_progress = realtime_progress
                else:
                    self.session_progress = stats.get("session_progress", 0.0)
            else:
                self.session_progress = stats.get("session_progress", 0.0)
            
            self.update_pet_state()
            self.coffee_beans_count = get_coffee_beans()
            
        except Exception:
            self.current_drink = "coffee_caramel"
            self.current_variant = "01"
            self.coffee_beans_count = 0
            self.session_progress = 0.0
    
    def update_pet_state(self):
        try:
            progress = float(self.session_progress)
            old_state = self.pet_state
            
            if progress <= 0:
                new_state = "desk"
            elif progress < 30:
                new_state = "desk"
            elif progress < 70:
                new_state = "half"
            else:
                new_state = "empty"
            
            self.pet_state = new_state
            return old_state != new_state
            
        except (ValueError, TypeError):
            self.pet_state = "desk"
            return False
    
    def check_progress_update(self):
        try:
            old_progress = self.session_progress
            
            new_progress = 0.0
            if self.comm:
                new_progress = self.comm.read_progress_sync()
            else:
                data = load_shop_data()
                stats = data.get("stats", {})
                new_progress = stats.get("session_progress", 0.0)
            
            self.session_progress = new_progress
            state_changed = self.update_pet_state()
            
            if abs(new_progress - old_progress) > 0.1 or state_changed:
                self.update_pet_display()
                self.update_status()
            
            self.update_status()
            
            if new_progress >= 100 and old_progress < 100:
                self.status_label.config(text="✅ 已完成！", fg="#2ecc71")
                self.window.after(3000, self.update_status)
        
        except Exception:
            pass
        
        self.window.after(500, self.check_progress_update)
    
    def get_image_path(self):
        try:
            variant = str(self.current_variant) if self.current_variant else "01"
            
            if variant == "diy":
                if self.pet_state == "desk":
                    return "assets/pets/coffee_cup_diy03.png"
                else:
                    return f"assets/pets/coffee_cup_{self.pet_state}03.png"
            elif variant == "matcha":
                return f"assets/pets/matcha_{self.pet_state}.png"
            else:
                return f"assets/pets/coffee_cup_{self.pet_state}{variant}.png"
                
        except Exception:
            return "assets/pets/coffee_cup_desk01.png"
    
    def get_tray_image_path(self):
        try:
            variant = str(self.current_variant) if self.current_variant else "01"
            if variant == "matcha":
                return "assets/tray/matcha_st.png"
            elif variant == "diy":
                return "assets/tray/coffee_cup_diy_st03.png"
            else:
                return f"assets/tray/coffee_cup_st{variant}.png"
        except Exception:
            return "assets/tray/coffee_cup_st01.png"
    
    def create_window(self):
        self.window = tk.Tk()
        self.window.title("咖啡桌宠")
        
        if self.window_pos:
            try:
                x, y = self.window_pos
                if isinstance(x, (int, float)) and isinstance(y, (int, float)):
                    geometry_str = f"128x152+{int(x)}+{int(y)}"
                else:
                    raise ValueError
            except Exception:
                screen_width = self.window.winfo_screenwidth()
                screen_height = self.window.winfo_screenheight()
                x = screen_width - 150
                y = screen_height - 150
                geometry_str = f"128x152+{x}+{y}"
        else:
            screen_width = self.window.winfo_screenwidth()
            screen_height = self.window.winfo_screenheight()
            x = screen_width - 150
            y = screen_height - 150
            geometry_str = f"128x152+{x}+{y}"
        
        self.window.geometry(geometry_str)
        self.window.overrideredirect(True)
        self.window.config(bg='#000001')
        self.window.wm_attributes('-transparentcolor', '#000001')
        self.window.attributes('-topmost', True)
        self.window.attributes('-alpha', 0.95)
        
        main_frame = tk.Frame(self.window, bg='#000001')
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        self.canvas = tk.Canvas(
            main_frame,
            width=128,
            height=128,
            bg='#000001',
            highlightthickness=0,
            bd=0
        )
        self.canvas.pack()
        
        self.update_pet_display()
        
        self.timer_canvas = tk.Canvas(
            main_frame,
            width=128,
            height=24,
            bg='#000001',
            highlightthickness=0,
            bd=0
        )
        self.timer_canvas.pack()
        
        self.timer_photo = None
        self.bind_events()
        self.window.after(15000, self.check_for_updates)
        
        self.status_label = tk.Label(
            self.window,
            text="",
            font=("Arial", 8),
            bg='#000001',
            fg="#ffffff"
        )
        self.status_label.pack(side=tk.BOTTOM, fill=tk.X)
        self.update_status()
    
    def check_timer_sync(self):
        if self.comm:
            state = self.comm.read_state(clear_after_read=False, max_age=5)
            
            if state and state.get("type") == "timer_update":
                timer_data = state.get("data", {})
                
                self.is_timer_running = timer_data.get("is_running", False)
                self.last_timer_state = timer_data
                
                if self.is_timer_running:
                    start_time = timer_data.get("start_time", 0)
                    total_seconds = timer_data.get("total_seconds", 0)
                    current_time = time.time()
                    
                    if start_time > 0 and total_seconds > 0:
                        elapsed = current_time - start_time
                        remaining = max(0, total_seconds - elapsed)
                        self.timer_remaining = remaining
                        
                        minutes = int(remaining // 60)
                        seconds = int(remaining % 60)
                        self.current_timer_display = f"{minutes:02d}:{seconds:02d}"
                        self.update_timer_display(self.current_timer_display, "#8B4513")
                    else:
                        self.current_timer_display = "00:00"
                        self.update_timer_display("", "#8B4513")
                else:
                    if timer_data.get("session_paused", False):
                        self.current_timer_display = "⏸️"
                        self.update_timer_display("⏸️", "#a1887f")
                    else:
                        self.current_timer_display = ""
                        self.update_timer_display("", "#8B4513")
                
                self.update_status()
        
        if self.comm:
            self.window.after(1000, self.check_timer_sync)
    
    def update_timer_display(self, text, color):
        if not text:
            self.timer_canvas.delete("all")
            return
        
        try:
            img = Image.new('RGBA', (128, 24), (0, 0, 0, 0))
            from PIL import ImageDraw, ImageFont
            draw = ImageDraw.Draw(img)
            
            font_names = ["arial.ttf", "msyh.ttf", "segoeui.ttf"]
            font = None
            for font_name in font_names:
                try:
                    font = ImageFont.truetype(font_name, 16)
                    break
                except:
                    continue
            
            if font is None:
                font = ImageFont.load_default()
            
            text_bbox = draw.textbbox((0, 0), text, font=font)
            text_width = text_bbox[2] - text_bbox[0]
            text_height = text_bbox[3] - text_bbox[1]
            x = (128 - text_width) // 2
            y = (24 - text_height) // 2
            
            draw.text((x, y), text, font=font, fill=color, antialias=True)
            self.timer_photo = ImageTk.PhotoImage(img)
            self.timer_canvas.delete("all")
            self.timer_canvas.create_image(64, 12, image=self.timer_photo, anchor=tk.CENTER)
            
        except Exception:
            self.timer_canvas.delete("all")
            self.timer_canvas.create_text(
                64, 12,
                text=text,
                font=("Segoe UI", 14),
                fill=color,
                anchor=tk.CENTER
            )
    
    def update_pet_display(self):
        image_path = self.get_image_path()
        
        if os.path.exists(image_path):
            try:
                img = Image.open(image_path).convert("RGBA")
                transparent_img = Image.new("RGBA", (128, 128), (0, 0, 0, 0))
                img_resized = img.resize((128, 128), Image.Resampling.LANCZOS)
                transparent_img.paste(img_resized, (0, 0), img_resized)
                self.tk_image = ImageTk.PhotoImage(transparent_img)
                self.canvas.delete("all")
                self.canvas.create_image(64, 64, image=self.tk_image, anchor=tk.CENTER)
            except Exception:
                self.show_fallback()
        else:
            self.show_fallback()
    
    def show_fallback(self):
        emoji_map = {
            "coffee_caramel": "☕",
            "coffee_seasonal": "🌟",
            "coffee_chocolate": "🍫",
            "coffee_diy": "🎨",
            "coffee_matcha": "🍵"
        }
        emoji = emoji_map.get(self.current_drink, "☕")
        
        if self.pet_state == "empty":
            color = "#888888"
        elif self.pet_state == "half":
            color = "#CC9966"
        else:
            color = "#8B4513"
        
        self.canvas.delete("all")
        self.canvas.create_text(64, 64, text=emoji, font=("Arial", 64), fill=color, anchor=tk.CENTER)
    
    def bind_events(self):
        self.canvas.bind("<Button-1>", self.start_drag)
        self.canvas.bind("<B1-Motion>", self.drag)
        self.timer_canvas.bind("<Button-1>", self.start_drag)
        self.timer_canvas.bind("<B1-Motion>", self.drag)
        
        self.canvas.bind("<Button-3>", self.show_context_menu)
        self.timer_canvas.bind("<Button-3>", self.show_context_menu)
        
        self.canvas.bind("<Double-Button-1>", self.restore_floating_window)
        self.timer_canvas.bind("<Double-Button-1>", self.restore_floating_window)
        
        self.canvas.bind("<Enter>", self.show_hover_info)
        self.canvas.bind("<Leave>", self.hide_hover_info)
    
    def start_drag(self, event):
        if not self.is_locked:
            self.drag_data["x"] = event.x_root - self.window.winfo_x()
            self.drag_data["y"] = event.y_root - self.window.winfo_y()
            self.status_label.config(text="拖动中...")
    
    def drag(self, event):
        if not self.is_locked:
            x = event.x_root - self.drag_data["x"]
            y = event.y_root - self.drag_data["y"]
            self.window.geometry(f"+{x}+{y}")
    
    def show_context_menu(self, event):
        menu = tk.Menu(self.window, tearoff=0)
        
        beans = get_coffee_beans()
        menu.add_command(label=f"咖啡豆: {beans} ☕", command=self.refresh_beans, state="disabled")
        
        if self.is_timer_running:
            menu.add_command(label=f"计时器: {self.current_timer_display}", state="disabled")
        
        menu.add_command(label=f"进度: {self.session_progress:.1f}%", state="disabled")
        menu.add_command(label=f"状态: {self.get_state_name()}", state="disabled")
        menu.add_separator()
        
        if self.is_locked:
            menu.add_command(label="🔓 取消固定", command=self.toggle_lock)
        else:
            menu.add_command(label="📌 固定位置", command=self.toggle_lock)
        
        if self.is_transparent:
            menu.add_command(label="🎨 显示背景", command=self.toggle_transparency)
        else:
            menu.add_command(label="🎨 透明背景", command=self.toggle_transparency)
        
        menu.add_separator()
        menu.add_command(label="🔄 刷新状态", command=self.refresh_pet)
        menu.add_command(label="🏪 打开商店", command=self.open_shop)
        menu.add_separator()
        menu.add_command(label="🪟 恢复悬浮窗", command=self.restore_floating_window)
        menu.add_command(label="💤 最小化到托盘", command=self.minimize_to_tray)
        menu.add_separator()
        menu.add_command(label="🚪 退出桌宠", command=self.quit_pet)
        
        try:
            menu.tk_popup(event.x_root, event.y_root)
        finally:
            menu.grab_release()
    
    def get_state_name(self):
        state_names = {"desk": "满杯", "half": "半杯", "empty": "空杯"}
        return state_names.get(self.pet_state, "未知")
    
    def refresh_beans(self):
        beans = get_coffee_beans()
    
    def toggle_lock(self):
        self.is_locked = not self.is_locked
        self.update_status()
    
    def toggle_transparency(self):
        self.is_transparent = not self.is_transparent
        if self.is_transparent:
            self.window.wm_attributes('-transparentcolor', '#000001')
            bg_color = '#000001'
        else:
            self.window.wm_attributes('-transparentcolor', '')
            bg_color = '#f5f1e9'
        
        self.window.configure(bg=bg_color)
        self.canvas.configure(bg=bg_color)
        self.timer_canvas.configure(bg=bg_color)
        self.status_label.configure(bg=bg_color)
        self.update_status()
    
    def refresh_pet(self):
        old_drink = self.current_drink
        old_state = self.pet_state
        
        self.load_current_drink()
        self.update_pet_display()
        self.update_status()
        
        if old_drink != self.current_drink:
            messagebox.showinfo("饮品更换", f"已切换到{self.get_drink_name()}")
    
    def get_drink_name(self):
        name_map = {
            "coffee_caramel": "焦糖玛奇朵",
            "coffee_seasonal": "季节限定",
            "coffee_chocolate": "巧克力奶油顶",
            "coffee_diy": "DIY版",
            "coffee_matcha": "抹茶拿铁"
        }
        return name_map.get(self.current_drink, "未知饮品")
    
    def open_shop(self):
        try:
            webbrowser.open("http://localhost:8501")
            self.status_label.config(text="已打开商店...")
            self.window.after(3000, self.update_status)
        except Exception:
            self.status_label.config(text="请手动打开: http://localhost:8501")
            self.window.after(5000, self.update_status)
    
    def restore_floating_window(self, event=None):
        try:
            current_dir = os.path.dirname(os.path.abspath(__file__))
            flag_file = os.path.join(current_dir, "restore_flag.txt")
            with open(flag_file, 'w') as f:
                f.write(f"restore_{int(time.time())}")
            self.window.after(500, self.quit_pet)
        except Exception:
            self.window.deiconify()
            messagebox.showinfo("提示", "恢复失败，请手动启动悬浮窗")
    
    def minimize_to_tray(self):
        try:
            import pystray
            tray_path = self.get_tray_image_path()
            if os.path.exists(tray_path):
                tray_image = Image.open(tray_path).resize((32, 32), Image.Resampling.LANCZOS)
            else:
                tray_image = Image.new('RGB', (32, 32), color='#8B4513')
            
            menu = pystray.Menu(
                pystray.MenuItem("恢复桌宠", self.restore_from_tray),
                pystray.MenuItem("恢复悬浮窗", self.restore_floating_window),
                pystray.MenuItem("刷新", self.refresh_pet),
                pystray.Menu.SEPARATOR,
                pystray.MenuItem("退出", self.quit_all)
            )
            
            self.tray_icon = pystray.Icon("coffee_pet", tray_image, f"咖啡桌宠 - {self.get_drink_name()}", menu)
            self.window.withdraw()
            
            def run_tray():
                self.tray_icon.run()
            
            tray_thread = threading.Thread(target=run_tray, daemon=True)
            tray_thread.start()
            
        except ImportError:
            messagebox.showinfo("提示", "系统托盘功能需要安装pystray库\n运行: pip install pystray")
        except Exception:
            pass
    
    def restore_from_tray(self, icon=None, item=None):
        if hasattr(self, 'tray_icon') and self.tray_icon:
            self.tray_icon.stop()
        self.window.deiconify()
        self.update_status()
    
    def show_hover_info(self, event):
        state_text = {"desk": "满杯", "half": "半杯", "empty": "空杯"}
        beans = get_coffee_beans()
        info = f"{self.get_drink_name()} - {state_text.get(self.pet_state, '未知')}"
        info += f" ({self.session_progress:.1f}%)"
        if self.is_timer_running:
            info += f" | ⏱️ {self.current_timer_display}"
        info += f" | ☕{beans}"
        self.status_label.config(text=info)
    
    def hide_hover_info(self, event):
        self.update_status()
    
    def update_status(self):
        if self.is_locked:
            lock_text = "📌 已固定"
        else:
            lock_text = "🔄 可拖动"
        
        if self.is_transparent:
            trans_text = "透明"
        else:
            trans_text = "背景"
        
        state_map = {
            "desk": ("满杯", "#8B4513"),
            "half": ("半杯", "#CC9966"),
            "empty": ("空杯", "#888888")
        }
        
        state_text, state_color = state_map.get(self.pet_state, ("未知", "#8B4513"))
        beans = get_coffee_beans()
        
        status = f"{lock_text} | {trans_text} | {state_text}"
        if self.is_timer_running:
            status += f" | ⏱️ {self.current_timer_display}"
        status += f" | ☕{beans} | 📊{self.session_progress:.1f}%"
        
        self.status_label.config(text=status, fg=state_color)
    
    def check_for_updates(self):
        old_drink = self.current_drink
        old_beans = self.coffee_beans_count
        
        self.load_current_drink()
        
        if old_drink != self.current_drink:
            self.update_pet_display()
            self.update_status()
            messagebox.showinfo("饮品更换", f"已切换到{self.get_drink_name()}")
        
        if old_beans != self.coffee_beans_count:
            self.update_status()
        
        self.window.after(15000, self.check_for_updates)
    
    def start_communication_server(self):
        def server_thread():
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                sock.bind(('localhost', self.comm_port))
                sock.listen(1)
                sock.settimeout(1)
                
                while not self.stop_comm:
                    try:
                        conn, addr = sock.accept()
                        data = conn.recv(1024)
                        if data == b"RESTORE":
                            self.window.after(0, self.restore_floating_window)
                        conn.close()
                    except socket.timeout:
                        continue
                    except Exception:
                        continue
                sock.close()
            except Exception:
                pass
        
        threading.Thread(target=server_thread, daemon=True).start()
    
    def send_restore_signal(self):
        try:
            if self.floating_window_pid:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(2)
                sock.connect(('localhost', self.comm_port))
                sock.send(b"RESTORE")
                sock.close()
                return True
        except:
            pass
        return False
    
    def quit_pet(self):
        self.stop_comm = True
        if hasattr(self, 'tray_icon') and self.tray_icon:
            self.tray_icon.stop()
        if self.window:
            self.window.quit()
            self.window.destroy()
    
    def quit_all(self, icon=None, item=None):
        self.quit_pet()
    
    def run(self):
        try:
            self.window.mainloop()
        except Exception:
            pass

def start_coffee_pet(floating_window_pid=None, timer_state=None, window_pos=None):
    try:
        Path("data").mkdir(exist_ok=True)
        data = load_shop_data()
        pet = CoffeePet(
            floating_window_pid=floating_window_pid,
            timer_state=timer_state,
            window_pos=window_pos
        )
        pet.run()
    except Exception as e:
        messagebox.showerror("错误", f"启动桌宠失败:\n{str(e)}")

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="咖啡桌宠程序")
    parser.add_argument("--parent-pid", type=int, help="悬浮窗进程ID（可选）")
    parser.add_argument("--timer-state", type=str, help="计时器状态（base64编码）")
    parser.add_argument("--window-pos", type=str, help="窗口位置 x,y")
    
    args = parser.parse_args()
    
    floating_pid = args.parent_pid
    timer_state = None
    window_pos = None
    
    if args.timer_state:
        try:
            timer_state = pickle.loads(base64.b64decode(args.timer_state))
        except:
            pass
    
    if args.window_pos:
        try:
            x, y = map(int, args.window_pos.split(","))
            window_pos = (x, y)
        except:
            pass
    
    start_coffee_pet(
        floating_window_pid=floating_pid,
        timer_state=timer_state,
        window_pos=window_pos
    )
