import streamlit as st
import json
from pathlib import Path

from services.beans_service import get_coffee_beans, add_coffee_beans, deduct_coffee_beans

class ShopManager:
    def __init__(self, user_data_path="data/shop_data.json"):
        self.user_data_path = Path(user_data_path)
        self.user_data = self._load_and_fix_user_data()
        
    def _load_and_fix_user_data(self):
        """加载并修复用户数据"""
        if not self.user_data_path.exists():
            return self._create_default_data()
        
        try:
            with open(self.user_data_path, 'r', encoding='utf-8') as f:
                content = f.read().strip()
                if not content:
                    return self._create_default_data()
                
                data = json.loads(content)
            
            # 修复整数格式的数据
            if isinstance(data, int):
                return self._convert_int_to_dict(data)
            
            if not isinstance(data, dict):
                return self._create_default_data()
            
            return self._fix_data_issues(data)
        except json.JSONDecodeError:
            return self._create_default_data()
        except Exception as e:
            print(f"⚠️ 加载商店数据失败: {e}")
            return self._create_default_data()
    
    def _convert_int_to_dict(self, int_value):
        """将整数转换为字典格式"""
        return {
            "coffee_beans": int(int_value),
            "purchased_items": ["coffee_caramel"],
            "equipped": {
                "background": "bg_none",
                "coffee_pet": "coffee_caramel"
            },
            "achievements": {
                "focus_count": 0,
                "current_barista": "普通顾客",
                "unlocked_baristas": ["普通顾客"]
            }
        }
    
    def _create_default_data(self):
        """创建默认数据"""
        return {
            "coffee_beans": 0,
            "purchased_items": ["coffee_caramel"],
            "equipped": {
                "background": "bg_none",
                "coffee_pet": "coffee_caramel"
            },
            "achievements": {
                "focus_count": 0,
                "current_barista": "普通顾客",
                "unlocked_baristas": ["普通顾客"]
            }
        }
    
    def _fix_data_issues(self, data):
        """修复数据问题"""
        if not isinstance(data, dict):
            return self._convert_int_to_dict(data) if isinstance(data, int) else self._create_default_data()
        
        # 确保 purchased_items 是列表
        if not isinstance(data.get("purchased_items"), list):
            data["purchased_items"] = ["coffee_caramel"]
        
        # 统一豆子字段
        coffee_beans = 0
        coffee_beans_value = data.get("coffee_beans")
        
        if isinstance(coffee_beans_value, (int, float)):
            coffee_beans = int(coffee_beans_value)
        elif "beans" in data:
            beans = data["beans"]
            if isinstance(beans, int):
                coffee_beans = beans
            elif isinstance(beans, dict):
                reading_beans = int(beans.get("reading_beans", 0))
                focus_beans = int(beans.get("focus_beans", 0))
                coffee_beans = reading_beans + focus_beans
        
        data["coffee_beans"] = coffee_beans
        
        # 清理旧的 unlocked 字段
        if "unlocked" in data and isinstance(data["unlocked"], dict):
            for item_type, items in data["unlocked"].items():
                if isinstance(items, list):
                    for item_id in items:
                        if item_id not in data.get("purchased_items", []):
                            data.setdefault("purchased_items", []).append(item_id)
            del data["unlocked"]
        
        # 初始化 equipped
        if not isinstance(data.get("equipped"), dict):
            data["equipped"] = {
                "background": "bg_none",
                "coffee_pet": "coffee_caramel"
            }
        
        # 初始化 achievements
        if not isinstance(data.get("achievements"), dict):
            data["achievements"] = {
                "focus_count": 0,
                "current_barista": "普通顾客",
                "unlocked_baristas": ["普通顾客"]
            }
        
        # 移除 stats 字段
        if "stats" in data:
            del data["stats"]
        
        return data
    
    def get_total_beans(self):
        """获取总咖啡豆数"""
        try:
            beans = self.user_data.get("coffee_beans", 0)
            return int(beans) if beans else 0
        except Exception:
            return 0
    
    def add_beans(self, amount, source=""):
        """增加咖啡豆"""
        try:
            current = self.user_data.get("coffee_beans", 0)
            self.user_data["coffee_beans"] = current + amount
            
            # 调用 service 层的统一函数
            add_coffee_beans(amount, source)
            
            self._save_user_data()
            
            if source:
                print(f"☕ +{amount} 咖啡豆 (来源: {source}) 当前: {self.user_data['coffee_beans']}")
            
            return True
        except Exception as e:
            print(f"❌ 增加咖啡豆失败: {e}")
            return False
    
    def update_focus_count(self, count=1):
        """更新专注次数并检查成就"""
        try:
            if "achievements" not in self.user_data:
                self.user_data["achievements"] = {
                    "focus_count": 0,
                    "current_barista": "普通顾客",
                    "unlocked_baristas": ["普通顾客"]
                }
            
            achievements = self.user_data["achievements"]
            current_count = int(achievements.get("focus_count", 0))
            achievements["focus_count"] = current_count + count
            
            self._check_barista_achievements()
            self._save_user_data()
            return True
        except Exception as e:
            print(f"❌ 更新专注次数失败: {e}")
            return False
    
    def _check_barista_achievements(self):
        """检查咖啡师成就解锁"""
        try:
            achievements = self.user_data.get("achievements", {})
            focus_count = int(achievements.get("focus_count", 0))
            
            if "unlocked_baristas" not in achievements:
                achievements["unlocked_baristas"] = ["普通顾客"]
            
            unlocked = achievements["unlocked_baristas"]
            
            # 成就解锁条件
            achievements_list = [
                (10, "业余爱好者"),
                (30, "资深爱好者"),
                (50, "初级咖啡师"),
                (100, "店长")
            ]
            
            # 解锁新等级
            for count, title in achievements_list:
                if focus_count >= count and title not in unlocked:
                    unlocked.append(title)
            
            # 更新当前等级
            current_title = "普通顾客"
            for count, title in reversed(achievements_list):
                if focus_count >= count:
                    current_title = title
                    break
            
            achievements["current_barista"] = current_title
            return True
            
        except Exception as e:
            print(f"❌ 检查成就失败: {e}")
            return False
    
    def purchase_item(self, item_id, item_type, price):
        """购买商品"""
        try:
            price = int(price)
            
            # 检查是否已拥有
            purchased_items = self.user_data.get("purchased_items", ["coffee_caramel"])
            if item_id in purchased_items:
                return False, "已拥有该商品"
            
            # 检查咖啡豆是否足够
            current_beans = self.get_total_beans()
            if current_beans < price:
                return False, "咖啡豆不足"
            
            # 扣除咖啡豆
            if price > 0:
                success, new_total = deduct_coffee_beans(price, item_id)
                if not success:
                    return False, "扣除咖啡豆失败"
                
                self.user_data["coffee_beans"] = new_total
            
            # 添加购买记录
            if item_id not in purchased_items:
                purchased_items.append(item_id)
            
            # 自动装备免费或首个商品
            if price == 0 or item_id == "coffee_caramel":
                self.equip_item(item_type, item_id)
            
            self._save_user_data()
            return True, f"购买成功！{item_id} 已添加到您的物品栏"
            
        except Exception as e:
            print(f"❌ 购买商品失败: {e}")
            return False, f"购买失败: {str(e)}"
    
    def equip_item(self, item_type, item_id):
        """装备物品"""
        try:
            if item_type not in ["background", "coffee_pet"]:
                return False, f"不支持的类型: {item_type}"
            
            # 检查是否已购买
            purchased_items = self.user_data.get("purchased_items", ["coffee_caramel"])
            if item_id not in purchased_items:
                return False, "请先购买该物品"
            
            # 装备物品
            equipped = self.user_data.get("equipped", {})
            equipped[item_type] = item_id
            self.user_data["equipped"] = equipped
            
            self._save_user_data()
            return True, f"已装备 {item_id}"
            
        except Exception as e:
            print(f"❌ 装备物品失败: {e}")
            return False, f"装备失败: {str(e)}"
    
    def _save_user_data(self):
        """保存用户数据"""
        try:
            self.user_data_path.parent.mkdir(exist_ok=True)
            with open(self.user_data_path, 'w', encoding='utf-8') as f:
                json.dump(self.user_data, f, ensure_ascii=False, indent=2)
            return True
        except Exception as e:
            print(f"❌ 保存数据失败: {e}")
            return False
    
    def repair_data_file(self):
        """修复数据文件"""
        try:
            print(f"🔧 开始修复数据文件: {self.user_data_path}")
            
            # 重新加载并修复数据
            self.user_data = self._load_and_fix_user_data()
            
            # 保存修复后的数据
            success = self._save_user_data()
            
            if success:
                print(f"✅ 数据文件修复完成")
                return True
            else:
                print(f"❌ 数据文件修复失败")
                return False
                
        except Exception as e:
            print(f"❌ 修复过程出错: {e}")
            return False


def show_shop():
    """显示奖励商店"""
    try:
        st.title("🏪 咖啡豆奖励商店")
        
        # 初始化商店管理器
        shop = ShopManager()
        
        # 尝试修复数据
        if st.sidebar.button("🔧 修复数据文件"):
            with st.spinner("正在修复数据文件..."):
                if shop.repair_data_file():
                    st.sidebar.success("数据文件修复成功！")
                    st.rerun()
                else:
                    st.sidebar.error("数据文件修复失败")
        
        # 获取用户数据
        user_data = shop.user_data
        
        coffee_beans = user_data.get("coffee_beans", 0)
        achievements = user_data.get("achievements", {})
        
        if not isinstance(achievements, dict):
            achievements = {
                "focus_count": 0,
                "current_barista": "普通顾客",
                "unlocked_baristas": ["普通顾客"]
            }
        
        # 提取具体数据
        total_beans = int(coffee_beans)
        focus_count = int(achievements.get("focus_count", 0))
        current_barista = achievements.get("current_barista", "普通顾客")
        
        # 主布局
        col_left, col_right = st.columns([2, 1])
        
        with col_left:
            # 第一行：咖啡豆和专注次数
            subcol1, subcol2 = st.columns(2)
            
            with subcol1:
                st.markdown("### 咖啡豆")
                st.markdown(f"<div style='font-size: 32px; font-weight: bold; color: #8B4513; margin-top: -10px;'>{total_beans}</div>", unsafe_allow_html=True)
            
            with subcol2:
                st.markdown("### 专注次数")
                st.markdown(f"<div style='font-size: 32px; font-weight: bold; color: #2E7D32; margin-top: -10px;'>{focus_count}</div>", unsafe_allow_html=True)
            
            # 第二行：当前咖啡师等级
            barista_colors = {
                "普通顾客": "#808080",
                "业余爱好者": "#4CAF50",
                "资深爱好者": "#2196F3",
                "初级咖啡师": "#FF9800",
                "店长": "#000000"
            }
            
            color = barista_colors.get(current_barista, "#808080")
            
            st.markdown(f"""
            <div style='
                background-color: {color}20; 
                padding: 15px; 
                border-radius: 8px; 
                border-left: 6px solid {color};
                margin-top: 15px;
                height: 50px;
                display: flex;
                align-items: center;
            '>
                <div style='display: flex; align-items: center; width: 100%;'>
                    <span style='color: #666; font-size: 16px; margin-right: 10px;'>👨‍🍳 当前咖啡师等级：</span>
                    <strong style='color: {color}; font-size: 20px;'>{current_barista}</strong>
                </div>
            </div>
            """, unsafe_allow_html=True)
        
        with col_right:
            # 装饰图片
            try:
                from pathlib import Path
                project_root = Path(__file__).parent.parent
                
                possible_paths = [
                    project_root / "assets" / "backgrounds" / "shop.png",
                    project_root / "assets" / "shop.png",
                    project_root / "assets" / "shop.jpg",
                    project_root / "assets" / "images" / "shop.png",
                ]
                
                img_found = False
                img_path = None
                
                for path in possible_paths:
                    if path.exists():
                        img_path = path
                        img_found = True
                        break
                
                if img_found and img_path:
                    st.image(str(img_path))
                else:
                    # 没有图片时的占位符
                    st.markdown("""
                    <div style='
                        height: 140px;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        background: linear-gradient(135deg, #f5f5f5, #e0e0e0);
                        border-radius: 10px;
                        border: 2px dashed #ccc;
                        margin-top: 20px;
                    '>
                        <div style='text-align: center;'>
                            <p style='color: #666; font-size: 2em; font-weight: bold;'>🏪</p>
                            <p style='color: #666; font-size: 1em;'>咖啡商店</p>
                        </div>
                    </div>
                    """, unsafe_allow_html=True)
                    
            except Exception:
                # 出错时的占位符
                st.markdown("""
                <div style='
                    height: 140px;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    background: linear-gradient(135deg, #f5f5f5, #e0e0e0);
                    border-radius: 10px;
                    border: 2px dashed #ccc;
                    margin-top: 20px;
                '>
                    <div style='text-align: center;'>
                        <p style='color: #666; font-size: 2em; font-weight: bold;'>🏪</p>
                        <p style='color: #666; font-size: 1em;'>店铺图片</p>
                    </div>
                </div>
                """, unsafe_allow_html=True)
        
        # 分隔线
        st.markdown("""
        <div style='height:2px; background:linear-gradient(90deg, #FF9800, #4CAF50, #2196F3); margin:20px 0; border-radius:1px;'></div>
        """, unsafe_allow_html=True)
        
        # 商店选项卡
        tab1, tab2, tab3 = st.tabs(["🏞️ 背景主题", "☕ 咖啡饮品", "👨‍🍳 咖啡师等级"])
        
        with tab1:
            _show_backgrounds_shop(shop)
        
        with tab2:
            _show_coffee_drinks_shop(shop)
        
        with tab3:
            _show_barista_achievements(shop)
            
    except Exception as e:
        st.error(f"商店加载失败: {str(e)[:100]}")
        st.info("尝试点击侧边栏的'修复数据文件'按钮")


def _show_backgrounds_shop(shop):
    """显示背景主题商店"""
    st.subheader("🏞️ 背景主题（50咖啡豆起）")
    st.caption("使用咖啡豆兑换不同的阅读环境")
    
    backgrounds = [
        {"id": "bg_none", "name": "无背景", "price": 0, "description": "简洁的默认背景"},
        {"id": "bg_bar", "name": "吧台絮语", "price": 50, "description": "温馨的吧台氛围"},
        {"id": "bg_gallery", "name": "画酌小廊", "price": 100, "description": "艺术画廊般的安静环境"},
        {"id": "bg_wood", "name": "晴午木息所", "price": 150, "description": "阳光透过木窗的温暖空间"}
    ]
    
    # 显示当前装备的背景
    current_bg = "bg_none"
    equipped = shop.user_data.get("equipped", {})
    if isinstance(equipped, dict):
        current_bg = equipped.get("background", "bg_none")
    
    for bg in backgrounds:
        if bg["id"] == current_bg:
            st.info(f"✅ 当前装备：**{bg['name']}**")
            break
    
    st.divider()
    
    # 显示所有背景
    cols = st.columns(2)
    for idx, bg in enumerate(backgrounds):
        col = cols[idx % 2]
        
        with col:
            is_current = (current_bg == bg["id"])
            border_color = "#4CAF50" if is_current else "#ddd"
            border_width = "3px" if is_current else "1px"
            
            st.markdown(f"""
            <div style='border:{border_width} solid {border_color}; padding:15px; border-radius:10px; margin-bottom:15px; background-color:#f9f9f9;'>
                <h4 style='margin:0; color:#5d4037;'>{bg['name']}</h4>
                <p style='color:#666; margin:5px 0 10px 0;'>{bg['description']}</p>
            </div>
            """, unsafe_allow_html=True)
            
            st.caption(f"**价格:** {bg['price']} 咖啡豆")
            
            purchased_items = shop.user_data.get("purchased_items", ["coffee_caramel"])
            is_purchased = bg['id'] in purchased_items
            total_beans = shop.get_total_beans()
            
            if is_current:
                st.success("✅ 已装备")
            elif is_purchased:
                if st.button("装备此背景", key=f"equip_bg_{bg['id']}"):
                    success, message = shop.equip_item("background", bg['id'])
                    if success:
                        st.success(message)
                        st.rerun()
                    else:
                        st.error(message)
            else:
                if bg['price'] == 0:
                    if st.button("免费获取", key=f"free_bg_{bg['id']}"):
                        success, message = shop.purchase_item(bg['id'], "background", 0)
                        if success:
                            st.success(message)
                            st.rerun()
                        else:
                            st.error(message)
                else:
                    if total_beans < bg['price']:
                        st.warning(f"❌ 需要 {bg['price']} 咖啡豆")
                    else:
                        if st.button(f"购买 ({bg['price']} 咖啡豆)", key=f"buy_bg_{bg['id']}", type="primary"):
                            success, message = shop.purchase_item(bg['id'], "background", bg['price'])
                            if success:
                                st.success(message)
                                st.rerun()
                            else:
                                st.error(message)


def _show_coffee_drinks_shop(shop):
    """显示咖啡饮品商店"""
    from pathlib import Path
    
    st.subheader("☕ 咖啡饮品桌宠（20咖啡豆起）")
    st.caption("兑换后在悬浮窗缩小为桌宠使用，可无限续杯")

    project_root = Path(__file__).parent.parent
    coffee_dir = project_root / "assets" / "coffee"

    coffee_drinks = [
        {"id": "coffee_caramel", "name": "焦糖玛奇朵", "price": 0, "description": "香甜的焦糖风味，默认饮品", "img": "caramel.png"},
        {"id": "coffee_matcha", "name": "抹茶拿铁", "price": 20, "description": "清新抹茶，提神醒脑", "img": "matcha.png"},
        {"id": "coffee_seasonal", "name": "季节限定", "price": 40, "description": "每季更新的特色饮品", "img": "seasonal.png"},
        {"id": "coffee_chocolate", "name": "巧克力奶油顶", "price": 60, "description": "浓郁巧克力搭配奶油顶", "img": "chocolate.png"},
        {"id": "coffee_diy", "name": "DIY版", "price": 0, "description": "巧克力少奶油版（需先解锁奶油顶版）", "requires": "coffee_chocolate", "img": "diy.png"},
    ]

    equipped = shop.user_data.get("equipped", {})
    current_pet = equipped.get("coffee_pet", "coffee_caramel")

    for d in coffee_drinks:
        if d["id"] == current_pet:
            st.info(f"✅ 当前装备：**{d['name']}**")
            break

    st.divider()

    cols = st.columns([1, 3, 3, 1])

    for idx, drink in enumerate(coffee_drinks):
        col = cols[1 + idx % 2]

        with col:
            can_purchase = True
            if "requires" in drink and drink["requires"] not in shop.user_data.get("purchased_items", []):
                can_purchase = False

            is_current = current_pet == drink["id"]

            card = st.container(border=True)

            with card:
                img_path = coffee_dir / drink["img"]
                if img_path.exists():
                    st.image(str(img_path), width=200)

                st.markdown(f"**{drink['name']}**")
                st.caption(drink["description"])

                purchased_items = shop.user_data.get("purchased_items", [])
                total_beans = shop.get_total_beans()

                if is_current:
                    st.success("已装备")
                elif drink["id"] in purchased_items:
                    if st.button("装备此饮品", key=f"equip_{drink['id']}"):
                        shop.equip_item("coffee_pet", drink["id"])
                        st.rerun()
                else:
                    if not can_purchase:
                        st.warning("需先解锁前置饮品")
                    elif drink["price"] == 0:
                        if st.button("免费获取", key=f"free_{drink['id']}"):
                            shop.purchase_item(drink["id"], "coffee_pet", 0)
                            st.rerun()
                    else:
                        if total_beans < drink["price"]:
                            st.warning(f"需要 {drink['price']} 咖啡豆")
                        else:
                            if st.button(f"购买 ({drink['price']} 咖啡豆)", key=f"buy_{drink['id']}"):
                                shop.purchase_item(drink["id"], "coffee_pet", drink["price"])
                                st.rerun()

            st.markdown("<div style='height:40px;'></div>", unsafe_allow_html=True)


def _show_barista_achievements(shop):
    """显示咖啡师成就系统"""
    st.subheader("👨‍🍳 咖啡师等级系统")
    st.caption("专注次数达到一定数量自动解锁不同等级")
    
    achievements = shop.user_data.get("achievements", {})
    if not isinstance(achievements, dict):
        achievements = {
            "focus_count": 0,
            "current_barista": "普通顾客",
            "unlocked_baristas": ["普通顾客"]
        }
    
    focus_count = int(achievements.get("focus_count", 0))
    current_barista = achievements.get("current_barista", "普通顾客")
    unlocked = achievements.get("unlocked_baristas", ["普通顾客"])
    if not isinstance(unlocked, list):
        unlocked = ["普通顾客"]
    
    levels = [
        {"count": 0, "title": "普通顾客", "description": "刚刚开始阅读之旅", "icon": "👤", "color": "#808080"},
        {"count": 10, "title": "业余爱好者", "description": "开始享受阅读时光的常客", "icon": "👒", "color": "#4CAF50"},
        {"count": 30, "title": "资深爱好者", "description": "对咖啡和阅读都有深入理解的熟客", "icon": "🎓", "color": "#2196F3"},
        {"count": 50, "title": "初级咖啡师", "description": "能够独立制作咖啡的见习咖啡师", "icon": "👨‍🍳", "color": "#FF9800"},
        {"count": 100, "title": "店长", "description": "咖啡馆的主理人，拥有特殊对话权限(开发中)", "icon": "👑", "color": "#000000"}
    ]
    
    # 显示进度条
    next_target = None
    for level in levels:
        if focus_count < level["count"]:
            next_target = level
            break
    
    if next_target:
        progress = min(focus_count / max(next_target["count"], 1), 1.0)
        st.progress(progress)
        st.caption(f"📈 进度: {focus_count}/{next_target['count']} 次 (还需 {next_target['count'] - focus_count} 次)")
    else:
        st.progress(1.0)
        st.success("🎉 已达成所有咖啡师成就！")
    
    st.divider()
    
    # 显示所有等级
    for level in levels:
        col1, col2, col3 = st.columns([1, 3, 2])
        
        with col1:
            if level["title"] in unlocked:
                st.markdown(f"<h1 style='color:{level['color']}; margin:0;'>{level['icon']}</h1>", unsafe_allow_html=True)
            else:
                st.markdown(f"<h1 style='color:#ccc; margin:0;'>{level['icon']}</h1>", unsafe_allow_html=True)
        
        with col2:
            if level["title"] in unlocked:
                if level["title"] == current_barista:
                    st.markdown(f"<h4 style='color:{level['color']}; margin:0;'><strong>{level['title']}</strong> ✅</h4>", unsafe_allow_html=True)
                else:
                    st.markdown(f"<h4 style='color:{level['color']}; margin:0;'><strong>{level['title']}</strong></h4>", unsafe_allow_html=True)
            else:
                st.markdown(f"<h4 style='color:#999; margin:0;'><strong>{level['title']}</strong></h4>", unsafe_allow_html=True)
            
            st.caption(level['description'])
        
        with col3:
            if level["title"] in unlocked:
                if level["title"] == current_barista:
                    st.success("当前身份")
                else:
                    st.info("已解锁")
            else:
                if focus_count >= level["count"]:
                    st.warning("待确认")
                else:
                    st.caption(f"需 {level['count']} 次专注")
        
        st.divider()


# 兼容旧代码的接口函数
def update_beans_from_focus(beans_earned):
    """从专注模式获得豆子"""
    print("⚠️ 警告: update_beans_from_focus() 已废弃，请使用 add_coffee_beans()")
    try:
        shop = ShopManager()
        return shop.add_beans(beans_earned, source="focus")
    except Exception as e:
        print(f"❌ 更新专注豆失败: {e}")
        return False

def update_focus_count(count=1):
    """更新专注次数"""
    try:
        shop = ShopManager()
        shop.update_focus_count(count)
        return True
    except Exception as e:
        print(f"❌ 更新专注次数失败: {e}")
        return False

def update_reading_beans(beans_earned):
    """更新阅读豆"""
    print("⚠️ 警告: update_reading_beans() 已废弃，请使用 add_coffee_beans()")
    try:
        shop = ShopManager()
        return shop.add_beans(beans_earned, source="reading")
    except Exception as e:
        print(f"❌ 更新阅读豆失败: {e}")
        return False

def get_current_equipment():
    """获取当前装备"""
    try:
        shop = ShopManager()
        equipped = shop.user_data.get("equipped", {})
        if isinstance(equipped, dict):
            return equipped
        else:
            return {"background": "bg_none", "coffee_pet": "coffee_caramel"}
    except:
        return {"background": "bg_none", "coffee_pet": "coffee_caramel"}

def get_current_barista():
    """获取当前咖啡师等级"""
    try:
        shop = ShopManager()
        achievements = shop.user_data.get("achievements", {})
        if isinstance(achievements, dict):
            return achievements.get("current_barista", "普通顾客")
        else:
            return "普通顾客"
    except:
        return "普通顾客"
