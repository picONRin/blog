import streamlit as st
import pandas as pd
import time
import plotly.graph_objects as go
from pathlib import Path

FILE_PATH = Path(__file__).parent.parent / "data" / "文献清单.csv"

def progress_sync():
    """进度追踪与同步主函数"""
    st.markdown("## 📊 进度追踪与同步")
    
    from services.data_init import init_data
    from services.beans_service import add_coffee_beans, get_coffee_beans
    
    init_data()
    
    if not FILE_PATH.exists():
        st.warning("📭 文献数据文件不存在！")
        return
    
    try:
        df = pd.read_csv(FILE_PATH, encoding="utf-8-sig")
        
        if df.empty:
            st.info("📭 暂无文献数据，请先添加文献")
            return
        
        valid_df = df[df["文献名称"].notna() & (df["文献名称"].str.strip() != "")]
        
        if valid_df.empty:
            st.info("ℹ️ 暂无有效文献数据")
            return
        
        st.markdown("### 📖 选择要更新进度的文献")
        
        literature_options = valid_df["文献名称"].tolist()
        selected_lit = st.selectbox("选择文献", literature_options, key="progress_select")
        
        if not selected_lit:
            return
        
        lit_info = valid_df[valid_df["文献名称"] == selected_lit].iloc[0]
        total_pages = lit_info["总页数"]
        current_pages = lit_info["当前页数"]
        progress = lit_info["上次进度(%)"]
        lit_coffee_beans = lit_info.get("咖啡豆数量", 0)
        total_coffee_beans = get_coffee_beans()
        
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("📄 总页数", f"{total_pages}页")
        with col2:
            st.metric("📖 已读页数", f"{current_pages}页")
        with col3:
            st.metric("📈 当前进度", f"{progress}%")
        
        filled_symbols = "█" * int(progress / 5)
        empty_symbols = "░" * (20 - int(progress / 5))
        st.markdown(f"""
        <div style="margin: 15px 0; padding: 10px; background: #f9f7f4; border-radius: 8px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
                <span style="font-size: 14px; color: #8d6e63; font-weight: bold;">📊 阅读进度：{progress}%</span>
                <span style="font-size: 14px; color: #8d6e63; font-weight: bold;">☕ 本文献豆子：{lit_coffee_beans}枚</span>
            </div>
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <span style="font-size: 14px; color: #8d6e63;">📋 文献总豆子：{lit_coffee_beans}枚</span>
                <span style="font-size: 14px; color: #5d4037; font-weight: bold;">💰 账户总豆子：{total_coffee_beans}枚</span>
            </div>
            <div style="font-family: monospace; font-size: 16px; letter-spacing: 2px; margin-top: 8px;">
                <span style="color: #8d6e63;">{filled_symbols}</span>
                <span style="color: #e0e0e0;">{empty_symbols}</span>
            </div>
        </div>
        """, unsafe_allow_html=True)
        
        st.markdown("---")
        st.markdown("### ✏️ 更新阅读进度")
        
        max_pages = total_pages - current_pages
        
        col_input, col_info = st.columns([1, 2])
        
        with col_input:
            pages_read = st.number_input(
                "本次阅读页数",
                min_value=1,
                max_value=max_pages if max_pages > 0 else 1,
                value=1,
                key="pages_input",
                help=f"最大可读 {max_pages} 页",
                step=1
            )
        
        with col_info:
            st.markdown(f"""
            <div style="
                background-color: #f8f4f0; 
                padding: 12px; 
                border-radius: 5px; 
                margin-top: 5px;
                font-size: 15px;
                color: #5d4037;
            ">
                <div style="font-weight: bold; margin-bottom: 8px; font-size: 16px;">
                    《{selected_lit[:22]}{'...' if len(selected_lit) > 22 else ''}》
                </div>
                <div style="display: flex; justify-content: space-between;">
                    <span style="color: #8d6e63;">
                        <span style="font-weight: bold;">已读：</span>{current_pages}页
                    </span>
                    <span style="color: #8d6e63;">
                        <span style="font-weight: bold;">剩余：</span>{max_pages}页
                    </span>
                    <span style="color: #8d6e63;">
                        <span style="font-weight: bold;">豆子：</span>{lit_coffee_beans}枚
                    </span>
                </div>
            </div>
            """, unsafe_allow_html=True)
        
        col_update, col_refresh = st.columns(2)
        
        with col_update:
            update_clicked = st.button("📝 更新进度", type="primary", key="update_progress_btn")
        
        with col_refresh:
            refresh_clicked = st.button("🔄 刷新数据", key="refresh_btn")
        
        if update_clicked:
            try:
                new_current = current_pages + pages_read
                if new_current > total_pages:
                    st.error(f"❌ 不能超过总页数！最大可读 {max_pages} 页")
                    return
                
                new_progress = round(new_current / total_pages * 100, 1)
                bean_add = 0
                milestones_achieved = []
                
                milestones = [20, 40, 60, 80, 100]
                for milestone in milestones:
                    if progress < milestone and new_progress >= milestone:
                        bean_add += 1
                        milestones_achieved.append(f"达到{milestone}%进度 +1☕")
                
                current_lit_beans = int(lit_info.get("咖啡豆数量", 0))
                
                if current_lit_beans >= 5:
                    bean_add = 0
                    milestones_achieved = ["本篇文献已达到最大豆子奖励(5枚)"]
                elif current_lit_beans + bean_add > 5:
                    bean_add = 5 - current_lit_beans
                    if bean_add > 0:
                        milestones_achieved = [f"达到100%进度，补足奖励 +{bean_add}☕"]
                
                idx = df[df["文献名称"] == selected_lit].index[0]
                df.loc[idx, "当前页数"] = new_current
                df.loc[idx, "上次进度(%)"] = new_progress
                
                if "咖啡豆数量" not in df.columns:
                    df["咖啡豆数量"] = 0
                
                df.loc[idx, "咖啡豆数量"] = current_lit_beans + bean_add
                df.to_csv(FILE_PATH, index=False, encoding="utf-8-sig")
                
                if bean_add > 0:
                    add_coffee_beans(bean_add, source="reading")
                
                success_message = f"""
                ✅ **进度更新成功！**  
                📖 《{selected_lit[:20]}{'...' if len(selected_lit) > 20 else ''}》  
                📚 本次阅读：{pages_read}页  
                📈 新进度：{new_progress}% ({current_pages}→{new_current}页)  
                """
                
                if bean_add > 0:
                    success_message += f"\n☕ **获得 {bean_add} 枚咖啡豆**"
                    success_message += f"\n💰 **账户总豆子：{total_coffee_beans} → {get_coffee_beans()}枚**\n\n"
                    
                    if milestones_achieved:
                        success_message += "**里程碑达成:**\n"
                        for milestone in milestones_achieved:
                            success_message += f"• {milestone}\n"
                else:
                    if new_progress == 100 and current_lit_beans >= 5:
                        success_message += "\n🎉 **本篇文献已完成并达到最大豆子奖励(5枚)**"
                    elif current_lit_beans >= 5:
                        success_message += f"\n📊 **本篇文献已达到最大豆子奖励(5枚)，进度继续增长**"
                    else:
                        success_message += "\n💪 继续加油，完成20%进度可获得咖啡豆！"
                
                st.success(success_message)
                st.info("📌 点击'刷新数据'按钮查看更新")
                
            except Exception as e:
                st.error(f"❌ 更新失败：{str(e)}")
        
        if refresh_clicked:
            st.rerun()
        
        st.markdown("---")
        
        with st.expander("📈 查看统计与图表", expanded=False):
            total_books = len(valid_df)
            total_pages_sum = valid_df["总页数"].sum()
            total_read_sum = valid_df["当前页数"].sum()
            
            if "咖啡豆数量" in valid_df.columns:
                total_beans_sum = valid_df["咖啡豆数量"].sum()
            else:
                total_beans_sum = 0
                df["咖啡豆数量"] = 0
                df.to_csv(FILE_PATH, index=False, encoding="utf-8-sig")
            
            overall_progress = round(total_read_sum / total_pages_sum * 100, 1) if total_pages_sum > 0 else 0
            current_total_beans = get_coffee_beans()
            
            st.markdown("### 📊 文献统计")
            cols = st.columns(5)
            with cols[0]:
                st.metric("📚 总数", f"{total_books}本")
            with cols[1]:
                st.metric("📄 总页数", f"{total_pages_sum}页")
            with cols[2]:
                st.metric("📈 总进度", f"{overall_progress}%")
            with cols[3]:
                st.metric("☕ 文献豆", f"{total_beans_sum}枚")
            with cols[4]:
                st.metric("💰 账户豆", f"{current_total_beans}枚")
            
            with st.expander("📋 咖啡豆获取规则", expanded=False):
                st.markdown("""
                ### ☕ 阅读咖啡豆获取规则
                
                通过阅读文献获取咖啡豆，用于兑换桌宠和背景：
                
                **1. 进度奖励规则**
                - 每完成20%进度：奖励1枚咖啡豆
                - 20%、40%、60%、80%、100%各奖励1枚
                - **每篇文献最多获得5枚咖啡豆**
                
                **2. 获得方式**
                - 一次性获得，累计获得
                - 举例：从0%直接读到40% → 获得2枚豆子（20%和40%）
                - 举例：从60%读到90% → 获得2枚豆子（80%和100%如果读完）
                
                **3. 注意事项**
                - 每本文献获得的咖啡豆会显示在【文献豆】列
                - 所有咖啡豆会汇总到【账户豆】（在商店中可用）
                - 进度更新后，咖啡豆会自动同步到商店账户
                
                > 💡 **提示**: 咖啡豆可以累积，用于兑换各种奖励！
                """)
            
            with st.expander("🔄 豆子同步状态", expanded=False):
                st.info(f"""
                **同步状态**: ✅ 已启用
                **文献总豆子**: {total_beans_sum}枚
                **账户总豆子**: {current_total_beans}枚
                **同步差值**: {current_total_beans - total_beans_sum}枚
                
                *差值说明*：账户总豆子可能包含来自其他模块（如专注计时）获得的豆子。
                """)
            
            st.markdown("---")
            
            if total_books > 0:
                col_chart1, col_chart2 = st.columns(2)
                
                with col_chart1:
                    st.markdown("#### 📊 各文献进度")
                    if total_books <= 10:
                        chart_df = valid_df.copy()
                        chart_df = chart_df.sort_values("上次进度(%)", ascending=True)
                        
                        fig1 = go.Figure()
                        fig1.add_trace(go.Bar(
                            y=chart_df["文献名称"].apply(lambda x: x[:15] + '...' if len(x) > 15 else x),
                            x=chart_df["上次进度(%)"],
                            orientation='h',
                            marker_color='#8d6e63',
                            text=chart_df["上次进度(%)"].apply(lambda x: f'{x}%'),
                            textposition='outside'
                        ))
                        
                        fig1.update_layout(
                            height=300,
                            margin=dict(l=50, r=20, t=30, b=20),
                            xaxis_title="进度 (%)",
                            yaxis_title="",
                            plot_bgcolor='white',
                            xaxis=dict(range=[0, 100], showgrid=True),
                            yaxis=dict(tickfont=dict(size=10), automargin=True),
                            showlegend=False
                        )
                        
                        st.plotly_chart(fig1, config={'displayModeBar': False, 'responsive': True})
                    else:
                        progress_groups = {
                            "0-20%": len(valid_df[(valid_df["上次进度(%)"] >= 0) & (valid_df["上次进度(%)"] < 20)]),
                            "20-40%": len(valid_df[(valid_df["上次进度(%)"] >= 20) & (valid_df["上次进度(%)"] < 40)]),
                            "40-60%": len(valid_df[(valid_df["上次进度(%)"] >= 40) & (valid_df["上次进度(%)"] < 60)]),
                            "60-80%": len(valid_df[(valid_df["上次进度(%)"] >= 60) & (valid_df["上次进度(%)"] < 80)]),
                            "80-100%": len(valid_df[(valid_df["上次进度(%)"] >= 80) & (valid_df["上次进度(%)"] <= 100)])
                        }
                        
                        progress_groups = {k: v for k, v in progress_groups.items() if v > 0}
                        
                        if progress_groups:
                            fig1 = go.Figure(data=[go.Pie(
                                labels=list(progress_groups.keys()),
                                values=list(progress_groups.values()),
                                hole=.3,
                                marker_colors=['#d7ccc8', '#bcaaa4', '#a1887f', '#8d6e63', '#6d4c41']
                            )])
                            
                            fig1.update_layout(
                                height=300,
                                margin=dict(l=20, r=20, t=40, b=20),
                                title_text="进度分布",
                                title_font=dict(size=14)
                            )
                            
                            st.plotly_chart(fig1, config={'displayModeBar': False, 'responsive': True})
                        else:
                            st.info("暂无进度数据")
                
                with col_chart2:
                    st.markdown("#### 📈 总体进度")
                    fig2 = go.Figure(data=[go.Pie(
                        labels=['已读', '未读'],
                        values=[total_read_sum, total_pages_sum - total_read_sum],
                        hole=.3,
                        marker_colors=['#8d6e63', '#d7ccc8'],
                        textinfo='percent',
                        textposition='inside'
                    )])
                    
                    fig2.update_layout(
                        height=300,
                        margin=dict(l=20, r=20, t=60, b=20),
                        title_text=f"总体进度: {overall_progress}%",
                        title_font=dict(size=14),
                        title_x=0.5,
                        title_y=0.95,
                        annotations=[dict(
                            text=f'{overall_progress}%',
                            x=0.5, 
                            y=0.5, 
                            font_size=20, 
                            showarrow=False,
                            font_color='#5d4037'
                        )],
                        showlegend=True,
                        legend=dict(yanchor="top", y=0.99, xanchor="left", x=1.05)
                    )
                    
                    st.plotly_chart(fig2, config={'displayModeBar': False, 'responsive': True})
                
                st.markdown("#### 📋 详细进度")
                display_df = valid_df.copy()
                display_df["文献名称"] = display_df["文献名称"].apply(lambda x: x[:20] + '...' if len(x) > 20 else x)
                display_df = display_df[["文献名称", "当前页数", "总页数", "上次进度(%)", "咖啡豆数量"]]
                display_df = display_df.sort_values("上次进度(%)", ascending=False)
                
                display_df.columns = ["文献名称", "已读页数", "总页数", "进度(%)", "文献豆"]
                
                st.dataframe(
                    display_df,
                    hide_index=True,
                    column_config={
                        "进度(%)": st.column_config.ProgressColumn(
                            "进度(%)",
                            help="阅读进度百分比",
                            format="%.1f%%",
                            min_value=0,
                            max_value=100
                        ),
                        "文献豆": st.column_config.NumberColumn(
                            "文献豆",
                            help="该文献获得的咖啡豆数量（最多5枚）",
                            format="%d"
                        )
                    },
                    height=min(400, 35 * len(display_df) + 40)
                )
            else:
                st.info("暂无数据可显示图表")
        
    except Exception as e:
        st.error(f"❌ 读取数据失败：{e}")
