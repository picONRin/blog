import streamlit as st
import json
from pathlib import Path
import os
import shutil
from datetime import datetime
import time
import threading

DIALOGUE_HISTORY_PATH = Path(__file__).parent.parent / "data" / "店长对话记录.json"

def safe_save_conversations(conversations_list):
    lock = threading.Lock()
    
    with lock:
        try:
            if os.path.exists(DIALOGUE_HISTORY_PATH):
                timestamp = int(time.time())
                backup_path = DIALOGUE_HISTORY_PATH.with_name(f"店长对话记录_backup_{timestamp}.json")
                shutil.copy2(DIALOGUE_HISTORY_PATH, backup_path)
                
                backup_dir = DIALOGUE_HISTORY_PATH.parent
                backups = []
                for f in backup_dir.iterdir():
                    if f.name.startswith("店长对话记录_backup_"):
                        backups.append(f)
                
                backups.sort(key=os.path.getmtime, reverse=True)
                for old_backup in backups[5:]:
                    try:
                        os.remove(old_backup)
                    except:
                        pass
            
            def clean_conv(conv):
                if not isinstance(conv, dict):
                    return {"message": str(conv), "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
                
                cleaned = {}
                for key, value in conv.items():
                    if hasattr(value, 'item'):
                        try:
                            cleaned[key] = value.item()
                        except:
                            cleaned[key] = str(value)
                    elif isinstance(value, (int, float, str, bool, type(None))):
                        cleaned[key] = value
                    else:
                        cleaned[key] = str(value)
                
                if "timestamp" not in cleaned:
                    cleaned["timestamp"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                if "id" not in cleaned:
                    cleaned["id"] = hash(str(cleaned)) % 1000000
                
                return cleaned
            
            cleaned_list = [clean_conv(c) for c in conversations_list]
            
            if len(cleaned_list) > 200:
                recent = cleaned_list[-50:]
                user_msgs = [c for c in cleaned_list if c.get("sender") == "用户"]
                if len(user_msgs) > 30:
                    user_msgs = user_msgs[-30:]
                
                important = [
                    c for c in cleaned_list 
                    if c.get("context_type") == "ddl_reminder" 
                    and "逾期" in c.get("message", "")
                ]
                
                seen_ids = set()
                final_list = []
                
                for conv in recent + user_msgs + important:
                    conv_id = conv.get("id")
                    if conv_id not in seen_ids:
                        seen_ids.add(conv_id)
                        final_list.append(conv)
                
                if len(final_list) > 200:
                    try:
                        final_list.sort(key=lambda x: x.get("timestamp", ""), reverse=True)
                        final_list = final_list[:200]
                    except:
                        final_list = final_list[-200:]
                
                cleaned_list = final_list
            
            temp_path = DIALOGUE_HISTORY_PATH.with_suffix('.tmp')
            with open(temp_path, "w", encoding="utf-8") as f:
                json.dump(cleaned_list, f, ensure_ascii=False, indent=2)
            
            os.replace(temp_path, DIALOGUE_HISTORY_PATH)
            return True
            
        except Exception:
            try:
                simple_list = []
                for conv in conversations_list[-20:]:
                    if isinstance(conv, dict):
                        simple_conv = {
                            "sender": str(conv.get("sender", "")),
                            "message": str(conv.get("message", "")),
                            "timestamp": str(conv.get("timestamp", datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
                        }
                        simple_list.append(simple_conv)
                
                with open(DIALOGUE_HISTORY_PATH, "w", encoding="utf-8") as f:
                    json.dump(simple_list, f, ensure_ascii=False)
                
                return True
            except:
                return False

def safe_load_conversations():
    if not os.path.exists(DIALOGUE_HISTORY_PATH):
        return []
    
    try:
        with open(DIALOGUE_HISTORY_PATH, "r", encoding="utf-8") as f:
            content = f.read().strip()
            
            if not content:
                return []
            
            data = json.loads(content)
            
            if isinstance(data, list):
                return data
            elif isinstance(data, dict) and "conversations" in data:
                return data.get("conversations", [])
            elif isinstance(data, dict):
                for key, value in data.items():
                    if isinstance(value, list) and value and isinstance(value[0], dict):
                        if any(k in value[0] for k in ["sender", "message", "timestamp"]):
                            return value
                return []
            else:
                return []
    
    except json.JSONDecodeError:
        try:
            backup_dir = DIALOGUE_HISTORY_PATH.parent
            backups = []
            for f in backup_dir.iterdir():
                if f.name.startswith("店长对话记录_backup_"):
                    backups.append(f)
            
            backups.sort(key=os.path.getmtime, reverse=True)
            
            for backup in backups[:3]:
                try:
                    with open(backup, "r", encoding="utf-8") as f:
                        content = f.read().strip()
                        if content:
                            data = json.loads(content)
                            if isinstance(data, list):
                                safe_save_conversations(data)
                                return data
                except:
                    continue
            
            return []
            
        except:
            return []
    
    except Exception:
        return []

def shopkeeper_dialogue_history():
    st.markdown("## 💬 店长对话记录")
    
    col1, col2 = st.columns([3, 1])
    
    with col1:
        st.markdown("""
        <div style="background-color: #f8f4f0; border: 1px solid #e3ded9; border-radius: 6px; padding: 10px 12px; margin-bottom: 10px;">
            <p style="margin: 0; font-size: 13px; color: #5d4037; font-weight: 500;">
                💬 悬浮窗对话会自动同步到这里
            </p>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        if st.button("🔄 刷新", type="secondary"):
            st.rerun()
    
    try:
        conversations = safe_load_conversations()
        
        if not conversations:
            st.markdown("""
            <div style="background-color: #f8f4f0; border: 1px solid #e3ded9; border-radius: 8px; padding: 30px 20px; text-align: center; margin: 15px 0;">
                <p style="color: #8c7b72; font-size: 14px; margin: 0;">
                    📭 <strong>还没有对话记录</strong><br>
                    <small>在悬浮窗计时器中与店长对话后，记录会显示在这里</small>
                </p>
            </div>
            """, unsafe_allow_html=True)
            return
        
        total_conversations = len(conversations)
        recent_conversations = conversations[-20:]
        
        user_count = sum(1 for c in conversations if c.get("sender") == "用户")
        shopkeeper_count = sum(1 for c in conversations if c.get("sender") == "店长")
        ddl_count = sum(1 for c in conversations if c.get("context_type") == "ddl_reminder")
        
        st.markdown(f"""
        <div style="background-color: #f5f0eb; border-radius: 8px; padding: 12px; margin-bottom: 15px;">
            <div style="display: flex; justify-content: space-between; font-size: 13px; color: #5d4037;">
                <span>📊 共 <strong>{total_conversations}</strong> 条对话</span>
                <span>👤 你: {user_count} 条</span>
                <span>👨‍🍳 店长: {shopkeeper_count} 条</span>
                <span>⏰ DDL提醒: {ddl_count} 条</span>
            </div>
        </div>
        """, unsafe_allow_html=True)
        
        for conv in recent_conversations:
            sender = conv.get("sender", "")
            msg = conv.get("message", "")
            timestamp = conv.get("timestamp", "")
            
            if sender == "用户":
                st.markdown(f"""
                <div class="chat-bubble-user">
                    <div class="chat-sender">你</div>
                    <div class="chat-message">{msg}</div>
                    <div class="chat-time">{timestamp}</div>
                </div>
                """, unsafe_allow_html=True)
            else:
                st.markdown(f"""
                <div class="chat-bubble-shopkeeper">
                    <div class="chat-sender">店长</div>
                    <div class="chat-message">{msg}</div>
                    <div class="chat-time">{timestamp}</div>
                </div>
                """, unsafe_allow_html=True)
        
        st.markdown("---")
        
        col1, col2 = st.columns(2)
        
        with col1:
            if st.button("🔄 重新加载"):
                st.rerun()
        
        with col2:
            if st.button("🗑️ 清空记录", type="primary"):
                if not st.session_state.get("confirm_clear", False):
                    st.session_state.confirm_clear = True
                    st.markdown("""
                    <div style="background-color: #fff8e1; border: 1px solid #ffecb3; border-radius: 6px; padding: 12px; margin: 10px 0;">
                        <p style="color: #8d6e63; font-size: 13px; margin: 0;">
                            ⚠️ <strong>确定要清空所有对话记录吗？再次点击确认。</strong>
                        </p>
                    </div>
                    """, unsafe_allow_html=True)
                    st.stop()
                
                try:
                    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                    backup_path = DIALOGUE_HISTORY_PATH.with_name(f"店长对话记录_清空备份_{timestamp}.json")
                    if os.path.exists(DIALOGUE_HISTORY_PATH):
                        shutil.copy2(DIALOGUE_HISTORY_PATH, backup_path)
                    
                    with open(DIALOGUE_HISTORY_PATH, "w", encoding="utf-8") as f:
                        json.dump([], f, ensure_ascii=False, indent=2)
                    
                    st.markdown("""
                    <div style="background-color: #e8f5e9; border: 1px solid #c8e6c9; border-radius: 6px; padding: 12px; margin: 10px 0;">
                        <p style="color: #2e7d32; font-size: 13px; margin: 0;">
                            ✅ <strong>对话记录已清空！已创建备份。</strong>
                        </p>
                    </div>
                    """, unsafe_allow_html=True)
                    st.session_state.confirm_clear = False
                    st.rerun()
                except Exception as e:
                    st.markdown(f"""
                    <div style="background-color: #ffebee; border: 1px solid #ffcdd2; border-radius: 6px; padding: 12px; margin: 10px 0;">
                        <p style="color: #d32f2f; font-size: 13px; margin: 0;">
                            ❌ <strong>清空失败：{e}</strong>
                        </p>
                    </div>
                    """, unsafe_allow_html=True)
                    st.session_state.confirm_clear = False
    
    except Exception as e:
        st.markdown(f"""
        <div style="background-color: #ffebee; border: 1px solid #ffcdd2; border-radius: 8px; padding: 15px; margin: 15px 0;">
            <p style="color: #d32f2f; font-size: 14px; margin: 0;">
                ❌ <strong>加载对话记录失败：{str(e)}</strong>
            </p>
        </div>
        """, unsafe_allow_html=True)
    
    st.markdown("---")
    with st.expander("ℹ️ 店长回答风格说明"):
        st.markdown("""
        ### 店长回答风格
        
        注：店长无法知道你的页码对应的具体内容，提问时要明确问题的范围。
        
        **🎯 学术问题优先准确回答**
        - 优先保证学术问题的准确性
        - 减少模糊表述，提供清晰解释
        
        **☕ 减少咖啡专业术语**
        - 不再过度依赖咖啡相关比喻
        - 改用更直接的日常语言
        
        **💡 比喻简单易懂**
        - 使用简单的日常比喻帮助理解
        - 比喻服务于概念的理解
        
        **🎓 针对ADHD学生的特点**
        - 理解注意力分散的特点
        - 鼓励小步前进
        
        **📚 上下文感知增强**
        - 店长会记住你当前阅读的文献
        - 回答时会结合文献内容
        """)
