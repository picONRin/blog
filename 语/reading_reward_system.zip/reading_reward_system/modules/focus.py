import json
import threading
from pathlib import Path

# 检查是否在 Streamlit 环境中
try:
    import streamlit as st
    IN_STREAMLIT = True
except ImportError:
    IN_STREAMLIT = False
    # 创建伪 st 对象用于命令行环境
    class FakeStreamlit:
        def markdown(self, text, unsafe_allow_html=False):
            print(f"📄 Markdown: {text[:50]}...")
        
        def button(self, label, **kwargs):
            print(f"🔘 Button: {label}")
            return False
        
        def rerun(self):
            print("🔄 Rerun called")
        
        def caption(self, text):
            print(f"📝 Caption: {text}")
        
        def warning(self, text):
            print(f"⚠️ Warning: {text}")
        
        def success(self, text):
            print(f"✅ Success: {text}")
        
        def error(self, text):
            print(f"❌ Error: {text}")
        
        def info(self, text):
            print(f"ℹ️ Info: {text}")
        
        def columns(self, spec):
            return [self for _ in range(len(spec))]
        
        def expander(self, label, expanded=False):
            print(f"📦 Expander: {label}")
            return self
        
        def write(self, text):
            print(f"✍️ Write: {text}")
    
    st = FakeStreamlit()

TIMER_RECORD_PATH = Path(__file__).parent.parent / "data" / "timer_records.json"
file_lock = threading.Lock()

def focus_records():
    """显示专注记录"""
    st.markdown("## ⏱ 专注记录")
    
    with st.expander("📚 专注咖啡豆获得方式说明", expanded=False):
        st.markdown("""
        <div style="background-color: #fff8e1; padding: 15px; border-radius: 8px; border-left: 4px solid #ffb300;">
        <p style="color: #5d4037; margin: 0 0 10px 0;">
        <strong>☕ 在咖啡馆，每一次专注都能获得咖啡豆奖励：</strong>
        </p>
        <ul style="color: #5d4037; margin: 0; padding-left: 20px;">
        <li><strong>5分钟快速启动</strong>：专注5分钟，获得 <strong>1枚</strong> 咖啡豆</li>
        <li><strong>短时专注 (6-15分钟)</strong>：获得 <strong>2枚</strong> 咖啡豆</li>
        <li><strong>中等专注 (16-30分钟)</strong>：获得 <strong>3枚</strong> 咖啡豆</li>
        <li><strong>深度专注 (31-60分钟)</strong>：获得 <strong>5枚</strong> 咖啡豆</li>
        <li><strong>超长专注 (60+分钟)</strong>：获得 <strong>7枚</strong> 咖啡豆</li>
        <li><strong>连续专注奖励</strong>：连续专注3次，额外获得 <strong>2枚</strong> 咖啡豆</li>
        </ul>
        <p style="color: #5d4037; margin: 10px 0 0 0; font-size: 13px;">
        💡 温馨提示：每完成一次专注计时，系统会自动计算并发放咖啡豆到您的账户
        </p>
        </div>
        """, unsafe_allow_html=True)
    
    st.markdown("---")
    col1, col2 = st.columns([4, 1])
    with col1:
        st.caption("专注记录保存在本地文件中，悬浮窗的专注完成会自动更新")
    with col2:
        if st.button("🔄 刷新记录", key="refresh_focus_records", type="secondary"):
            st.rerun()

    st.markdown("<div style='height: 8px;'></div>", unsafe_allow_html=True)

    try:
        with file_lock:
            if not TIMER_RECORD_PATH.exists():
                data = {"focus_records": [], "total_focus_time": 0}
            else:
                with open(TIMER_RECORD_PATH, "r", encoding="utf-8") as f:
                    file_content = f.read()
                    if not file_content:
                        data = {"focus_records": [], "total_focus_time": 0}
                    else:
                        data = json.loads(file_content)
                        
                        # 修复整数格式的数据损坏
                        if isinstance(data, int):
                            if IN_STREAMLIT:
                                st.warning("⚠️ 检测到损坏的计时记录文件，正在修复...")
                            print(f"🚨 timer_records.json 损坏，是整数: {data}")
                            
                            data = {
                                "focus_records": [],
                                "total_focus_time": data
                            }
                            
                            # 立即修复文件
                            with open(TIMER_RECORD_PATH, "w", encoding="utf-8") as f_write:
                                json.dump(data, f_write, ensure_ascii=False, indent=2)
                            
                            if IN_STREAMLIT:
                                st.success("✅ 计时记录文件已自动修复")
                        
                        if not isinstance(data, dict):
                            data = {"focus_records": [], "total_focus_time": 0}

        records = data.get("focus_records", [])
        records.sort(key=lambda x: x.get('timestamp', ''), reverse=True)

    except json.JSONDecodeError:
        if IN_STREAMLIT:
            st.markdown(
                """
                <div class="card" style="text-align:center;color:#f44336;">
                    <p>⚠️ 专注记录文件格式错误</p>
                    <p style="font-size:13px;">记录数据已损坏，请检查文件完整性</p>
                </div>
                """,
                unsafe_allow_html=True
            )
            
            # 尝试修复文件
            try:
                with open(TIMER_RECORD_PATH, "w", encoding="utf-8") as f:
                    json.dump({"focus_records": [], "total_focus_time": 0}, f, ensure_ascii=False, indent=2)
                st.info("已尝试修复文件，请刷新页面")
            except:
                pass
        else:
            print("❌ JSON解码错误")
        return
    except Exception as e:
        if IN_STREAMLIT:
            error_msg = str(e)[:30]
            st.markdown(
                f"""
                <div class="card" style="text-align:center;color:#f44336;">
                    <p>⚠️ 读取专注记录失败</p>
                    <p style="font-size:13px;">{error_msg}...</p>
                </div>
                """,
                unsafe_allow_html=True
            )
            
            if "'int' object has no attribute 'get'" in str(e):
                st.error("检测到文件损坏（被保存为整数）")
                if st.button("🔧 立即修复文件", type="primary"):
                    try:
                        with open(TIMER_RECORD_PATH, "w", encoding="utf-8") as f:
                            json.dump({"focus_records": [], "total_focus_time": 0}, f, ensure_ascii=False, indent=2)
                        st.success("✅ 文件已修复！请刷新页面")
                    except Exception as repair_error:
                        st.error(f"修复失败: {repair_error}")
        else:
            print(f"❌ 错误: {e}")
        return

    if not records:
        if IN_STREAMLIT:
            st.markdown(
                """
                <div class="card" style="text-align:center;color:#9e9e9e;">
                    <p>☕ 暂无专注记录</p>
                    <p style="font-size:13px;">开始一次专注，咖啡馆会记住你的努力</p>
                </div>
                """,
                unsafe_allow_html=True
            )
        else:
            print("📭 暂无专注记录")
        return

    # 显示记录
    display_records = records[:50]
    
    if IN_STREAMLIT:
        records_html = []
        for r in display_records:
            timestamp = r.get('timestamp', '未知时间')
            literature = r.get('literature', '未选择文献')
            beans_earned = r.get('beans_earned', 0)
            
            record_html = f"""
                <div class="card">
                    <div style="font-size:13px;color:#757575;">
                        {timestamp}
                    </div>
                    <div>
                        {literature} · +{beans_earned} ☕
                    </div>
                </div>
                """
            records_html.append(record_html)
        
        st.markdown(''.join(records_html), unsafe_allow_html=True)
        
        if len(records) > 50:
            st.markdown(
                f"""
                <div style="text-align:center;color:#9e9e9e;font-size:12px;margin-top:10px;">
                    仅显示最近50条记录（共{len(records)}条）
                </div>
                """,
                unsafe_allow_html=True
            )
    else:
        # 命令行模式显示
        print(f"📊 专注记录（共{len(records)}条，显示前{min(50, len(records))}条）:")
        print("=" * 60)
        for i, r in enumerate(display_records[:10], 1):
            timestamp = r.get('timestamp', '未知时间')
            literature = r.get('literature', '未选择文献')
            beans_earned = r.get('beans_earned', 0)
            print(f"{i:2d}. {timestamp} - {literature} (+{beans_earned}☕)")
        if len(records) > 10:
            print(f"... 还有 {len(records)-10} 条记录")


if __name__ == "__main__":
    print("🔍 检查 timer_records.json 文件状态")
    print(f"📁 文件路径: {TIMER_RECORD_PATH}")
    
    if TIMER_RECORD_PATH.exists():
        try:
            with open(TIMER_RECORD_PATH, "r", encoding="utf-8") as f:
                content = f.read().strip()
                print(f"📄 文件内容: {content}")
                
                if content:
                    data = json.loads(content)
                    print(f"📊 数据类型: {type(data)}")
                    if isinstance(data, dict):
                        print(f"📝 专注记录数: {len(data.get('focus_records', []))}")
                        print(f"⏱️ 总专注时间: {data.get('total_focus_time', 0)}")
                    elif isinstance(data, int):
                        print(f"🚨 文件损坏！内容是整数: {data}")
                        print("🔧 正在修复文件...")
                        fixed_data = {
                            "focus_records": [],
                            "total_focus_time": data
                        }
                        with open(TIMER_RECORD_PATH, "w", encoding="utf-8") as f:
                            json.dump(fixed_data, f, ensure_ascii=False, indent=2)
                        print("✅ 文件已修复")
        except Exception as e:
            print(f"❌ 读取文件失败: {e}")
    else:
        print("📭 文件不存在")
