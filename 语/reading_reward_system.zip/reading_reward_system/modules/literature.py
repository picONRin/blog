import streamlit as st
import pandas as pd
import time
from pathlib import Path
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings('ignore')

FILE_PATH = Path(__file__).parent.parent / "data" / "文献清单.csv"

def literature_manager():
    """文献管理主函数"""
    st.markdown("## 📚 文献管理")
    
    init_data()
    
    st.markdown("### ⏰ DDL状态管理")
    with st.expander("管理过期和即将到期的文献", expanded=True):
        manage_ddl_status()
    
    success_placeholder = st.empty()
    
    st.markdown("### 📝 添加文献")
    
    with st.form(key="add_form"):
        title = st.text_input("文献名称 *", placeholder="输入文献名称")
        
        col1, col2 = st.columns(2)
        with col1:
            author = st.text_input("作者", placeholder="作者姓名（可留空）")
        with col2:
            literature_type = st.text_input("文献类型", placeholder="如：专著、期刊、论文等")
        
        col3, col4 = st.columns(2)
        with col3:
            total_pages = st.number_input("总页数 *", min_value=1, value=100)
            
            # 计算阅读时间
            if total_pages > 0:
                reading_time_hours = total_pages // 40
                reading_time_minutes = (total_pages % 40) * 1.5
                total_minutes = reading_time_hours * 60 + reading_time_minutes
                hours = int(total_minutes // 60)
                minutes = int(total_minutes % 60)
                
                time_text = "⏱️ 预计阅读时间: "
                if hours > 0:
                    time_text += f"{hours}小时"
                if minutes > 0:
                    if hours > 0:
                        time_text += f"{minutes}分钟"
                    else:
                        time_text += f"{minutes}分钟"
                if hours == 0 and minutes == 0:
                    time_text += "约1分钟"
                
                st.caption(f"""
                <div style="font-size: 0.85em; color: #8d6e63; margin-top: -8px; padding: 4px 0;">
                {time_text} (按40页/小时估算)
                </div>
                """, unsafe_allow_html=True)
        
        with col4:
            current_pages = st.number_input("已读页数", min_value=0, max_value=total_pages, value=0)
        
        # DDL设置
        col_ddl1, col_ddl2 = st.columns([3, 1])
        with col_ddl1:
            ddl_date = st.date_input(
                "DDL截止日期",
                value=datetime.now() + timedelta(days=30),
                min_value=datetime.now(),
                help="设置完成阅读的截止日期"
            )
        
        with col_ddl2:
            no_ddl = st.checkbox("不设DDL", value=False, help="如果不设置截止日期")
        
        # ADHD时间提示
        if not no_ddl:
            days_until_ddl = max(1, (ddl_date - datetime.now().date()).days)
            pages_per_day = max(1, total_pages // days_until_ddl)
            estimated_time_per_day = min(30, int(pages_per_day * 1.5))
            
            st.markdown(f"""
            <div style="margin: 12px 0 20px 0; padding: 14px 16px; background-color: #f8f4f0; border-radius: 10px; border-left: 4px solid #a1887f; box-shadow: 0 2px 4px rgba(139, 107, 94, 0.1);">
            <p style="margin: 0; font-size: 0.95em; color: #5d4037; line-height: 1.6;">
            ☕ <strong style="color: #795548;">ADHD时间观念小提示：</strong><br>
            如果每天读 <strong style="color: #795548; font-size: 1.1em;">{pages_per_day}</strong> 页，可以在DDL前完成！<br>
            记得拆分成 <strong style="color: #5d4037; font-size: 1.1em;">{estimated_time_per_day}</strong> 分钟的小任务，更容易开始哦～
            </p>
            </div>
            """, unsafe_allow_html=True)
        
        col_submit, col_reset = st.columns(2)
        with col_submit:
            submitted = st.form_submit_button("✅ 添加文献", type="primary")
        with col_reset:
            if st.form_submit_button("🔄 估算阅读时间"):
                st.session_state.clear()
                st.rerun()
        
        if submitted:
            st.session_state.add_form_data = {
                "title": title,
                "author": author,
                "literature_type": literature_type,
                "total_pages": total_pages,
                "current_pages": current_pages,
                "ddl_date": None if no_ddl else ddl_date
            }
    
    if "add_form_data" in st.session_state:
        data = st.session_state.add_form_data
        
        result = add_literature(
            data["title"], 
            data["author"], 
            data["literature_type"], 
            data["total_pages"], 
            data["current_pages"], 
            data["ddl_date"]
        )
        
        if result:
            success_placeholder.success(f"✅ 已添加：《{data['title']}》")
            time.sleep(2)
        
        del st.session_state.add_form_data
        st.rerun()
    
    st.markdown("### 📚 批量导入")
    with st.expander("点击展开", expanded=False):
        st.markdown("""
        <div style="background-color: #F9F5EB; padding: 12px 15px; border-radius: 8px; border: 1px dashed #8d6e63; margin-bottom: 20px;">
        <p style="margin: 0; color: #5d4037; font-size: 0.9em; line-height: 1.5;">
        请使用英文逗号分隔字段，每行一篇文献。<br>
        格式：文献名称,作者,文献类型,总页数,已读页数,DDL截止日期<br>
        <span style="color: #795548;">💡 选填：如果不设作者、DDL，可留空，但逗号必须有</span>
        </p>
        </div>
        """, unsafe_allow_html=True)
        
        st.markdown('<p style="color: #5d4037; margin-bottom: 8px; font-size: 0.9em;">粘贴文献数据（每行一篇）：</p>', unsafe_allow_html=True)

        batch_text = st.text_area(
           "batch_import_text",
           height=120,
           label_visibility="collapsed",
           placeholder="在这里粘贴或输入文献数据..."
        )

        import_clicked = st.button("📥 批量导入", 
                                  type="primary" if batch_text.strip() else "secondary",
                                  key="import_button")

        if import_clicked and batch_text.strip():
            batch_import(batch_text)
    
    show_literature_list_with_actions()

def manage_ddl_status():
    """管理DDL状态"""
    try:
        df = pd.read_csv(FILE_PATH, encoding="utf-8-sig")
        
        if df.empty:
            st.markdown("""
            <div style="background-color: #f8f4f0; border: 1px solid #e3ded9; border-radius: 8px; padding: 20px; text-align: center; margin: 15px 0;">
                <p style="color: #8d6e63; font-size: 0.9em; margin: 0;">
                    📭 <strong>暂无文献数据</strong>
                </p>
            </div>
            """, unsafe_allow_html=True)
            return
        
        today = datetime.now().date()
        overdue_list = []
        due_today_list = []
        due_soon_list = []
        completed_on_time = []
        
        for _, row in df.iterrows():
            ddl_str = ""
            if "DDL截止日期" in df.columns and not pd.isna(row.get("DDL截止日期")):
                ddl_str = str(row["DDL截止日期"]).strip()
            
            if not ddl_str or ddl_str.lower() in ["nan", "none", "null", ""]:
                continue
            
            ddl_date = parse_date(ddl_str)
            if not ddl_date:
                continue
            
            days_left = (ddl_date - today).days
            current_pages = int(row.get("当前页数", 0) or 0)
            total_pages = int(row.get("总页数", 0) or 0)
            completed = total_pages > 0 and current_pages >= total_pages
            
            if days_left < 0:
                if completed:
                    completed_on_time.append({
                        "title": row["文献名称"],
                        "ddl": ddl_date.strftime("%Y-%m-%d"),
                        "days_overdue": abs(days_left)
                    })
                else:
                    overdue_list.append({
                        "title": row["文献名称"],
                        "ddl": ddl_date.strftime("%Y-%m-%d"),
                        "days_overdue": abs(days_left),
                        "progress": f"{current_pages}/{total_pages}页",
                        "progress_percent": round(current_pages/total_pages*100, 1) if total_pages > 0 else 0
                    })
            elif days_left == 0:
                due_today_list.append({
                    "title": row["文献名称"],
                    "ddl": ddl_date.strftime("%Y-%m-%d"),
                    "progress": f"{current_pages}/{total_pages}页",
                    "progress_percent": round(current_pages/total_pages*100, 1) if total_pages > 0 else 0,
                    "completed": completed
                })
            elif days_left <= 3:
                due_soon_list.append({
                    "title": row["文献名称"],
                    "ddl": ddl_date.strftime("%Y-%m-%d"),
                    "days_left": days_left,
                    "progress": f"{current_pages}/{total_pages}页",
                    "progress_percent": round(current_pages/total_pages*100, 1) if total_pages > 0 else 0,
                    "completed": completed
                })
            elif completed:
                completed_on_time.append({
                    "title": row["文献名称"],
                    "ddl": ddl_date.strftime("%Y-%m-%d"),
                    "days_left_at_completion": "按时完成"
                })
        
        # 显示统计卡片
        st.markdown("#### 📊 DDL状态概览")
        
        cols = st.columns(4)
        metric_config = [
            {"title": "⏰ 即将到期", "value": len(due_soon_list), "delta": f"+{len(due_soon_list)}篇" if due_soon_list else None, "color": "inverse"},
            {"title": "⚠️ 今天到期", "value": len(due_today_list), "delta": "需关注" if due_today_list else None, "color": "inverse"},
            {"title": "✅ 按时完成", "value": len(completed_on_time), "delta": None, "color": "normal"},
            {"title": "⏳ 已过期", "value": len(overdue_list), "delta": "需处理" if overdue_list else None, "color": "inverse"}
        ]
        
        for i, col in enumerate(cols):
            with col:
                config = metric_config[i]
                if config["delta"]:
                    st.metric(config["title"], f"{config['value']}篇", delta=config["delta"], delta_color=config["color"])
                else:
                    st.metric(config["title"], f"{config['value']}篇")
        
        # 显示详细信息
        if due_today_list:
            st.markdown("""
            <div style="margin: 15px 0 5px 0; padding: 8px 12px; background: #ffefef; border-radius: 6px; border-left: 3px solid #e74c3c;">
                <h4 style="color: #c0392b; margin: 0; font-size: 0.9em; font-weight: 600;">🔴 今天到期 - 紧急处理</h4>
            </div>
            """, unsafe_allow_html=True)
            
            for item in due_today_list:
                status_color = "#27ae60" if item['completed'] else "#e74c3c"
                status_icon = "✅" if item['completed'] else "⏰"
                status_text = "已完成" if item['completed'] else "进行中"
                
                st.markdown(f"""
                <div style="margin: 8px 0; padding: 12px; background-color: white; border-radius: 6px; border: 1px solid #f0e6e6; box-shadow: 0 1px 2px rgba(0,0,0,0.03);">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
                        <span style="font-size: 0.9em; color: #5d4037; font-weight: 600;">《{item['title']}》</span>
                        <span style="font-size: 0.85em; color: {status_color}; font-weight: bold;">{status_icon} {status_text}</span>
                    </div>
                    <div style="display: flex; justify-content: space-between; align-items: center; font-size: 0.8em;">
                        <span style="color: #8d6e63;">进度: {item['progress']} ({item['progress_percent']}%)</span>
                        <span style="color: #e74c3c; font-weight: bold;">⏰ 今天到期</span>
                    </div>
                </div>
                """, unsafe_allow_html=True)
        
        if due_soon_list:
            st.markdown("""
            <div style="margin: 15px 0 5px 0; padding: 8px 12px; background: #fff8e1; border-radius: 6px; border-left: 3px solid #f39c12;">
                <h4 style="color: #e67e22; margin: 0; font-size: 0.9em; font-weight: 600;">🟡 即将到期 - 1-3天内</h4>
            </div>
            """, unsafe_allow_html=True)
            
            for item in due_soon_list:
                status_color = "#27ae60" if item['completed'] else "#e67e22"
                status_icon = "✅" if item['completed'] else "📖"
                status_text = "已完成" if item['completed'] else "进行中"
                
                st.markdown(f"""
                <div style="margin: 8px 0; padding: 12px; background-color: white; border-radius: 6px; border: 1px solid #f5e9d3; box-shadow: 0 1px 2px rgba(0,0,0,0.03);">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
                        <span style="font-size: 0.9em; color: #5d4037; font-weight: 600;">《{item['title']}》</span>
                        <span style="font-size: 0.85em; color: {status_color}; font-weight: bold;">{status_icon} {status_text}</span>
                    </div>
                    <div style="display: flex; justify-content: space-between; align-items: center; font-size: 0.8em;">
                        <span style="color: #8d6e63;">进度: {item['progress']} ({item['progress_percent']}%)</span>
                        <span style="color: #e67e22; font-weight: bold;">⏰ {item['days_left']}天后到期</span>
                    </div>
                </div>
                """, unsafe_allow_html=True)
        
        if overdue_list:
            st.markdown("""
            <div style="margin: 15px 0 5px 0; padding: 8px 12px; background: #ffeaea; border-radius: 6px; border-left: 3px solid #c0392b;">
                <h4 style="color: #a93226; margin: 0; font-size: 0.9em; font-weight: 600;">🔴 已过期文献 - 急需处理</h4>
            </div>
            """, unsafe_allow_html=True)
            
            for item in overdue_list:
                st.markdown(f"""
                <div style="margin: 8px 0; padding: 12px; background-color: white; border-radius: 6px; border: 1px solid #f0d9d9; box-shadow: 0 1px 2px rgba(0,0,0,0.03);">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
                        <span style="font-size: 0.9em; color: #5d4037; font-weight: 600;">《{item['title']}》</span>
                        <span style="font-size: 0.85em; color: #c0392b; font-weight: bold;">⚠️ 已过期</span>
                    </div>
                    <div style="display: flex; justify-content: space-between; align-items: center; font-size: 0.8em;">
                        <span style="color: #8d6e63;">进度: {item['progress']} ({item['progress_percent']}%)</span>
                        <span style="color: #c0392b; font-weight: bold;">⏳ 已过期{item['days_overdue']}天</span>
                    </div>
                </div>
                """, unsafe_allow_html=True)
        
        if not any([due_today_list, due_soon_list, overdue_list]):
            st.markdown("""
            <div style="margin: 20px 0; padding: 20px; background: #e8f5e9; border-radius: 8px; border-left: 3px solid #4caf50; text-align: center;">
                <h4 style="color: #388e3c; margin: 0 0 8px 0; font-size: 0.95em; font-weight: 600;">🎉 文献DDL状态良好</h4>
                <p style="color: #5d4037; margin: 0; font-size: 0.85em;">当前没有即将到期或已过期的文献，继续保持！</p>
            </div>
            """, unsafe_allow_html=True)
            
    except Exception as e:
        st.error(f"读取DDL状态失败: {str(e)}")

def parse_date(date_str):
    """解析日期字符串"""
    if pd.isna(date_str) or not date_str or str(date_str).strip() == "":
        return None
    
    date_str = str(date_str).strip()
    for fmt in ["%Y/%m/%d", "%Y-%m-%d", "%Y年%m月%d日", "%m/%d/%Y", "%d/%m/%Y"]:
        try:
            return datetime.strptime(date_str, fmt).date()
        except ValueError:
            continue
    return None

def init_data():
    """初始化数据文件"""
    data_dir = FILE_PATH.parent
    data_dir.mkdir(exist_ok=True)
    
    if not FILE_PATH.exists():
        columns = ["文献名称", "作者", "文献类型", "总页数", "当前页数", "上次进度(%)", "咖啡豆数量", "添加日期", "DDL截止日期"]
        df = pd.DataFrame(columns=columns)
        df.to_csv(FILE_PATH, index=False, encoding="utf-8-sig")

def add_literature(title, author, literature_type, total_pages, current_pages, ddl_date):
    """添加单篇文献"""
    if not title.strip():
        st.error("❌ 文献名称不能为空")
        return False
    
    try:
        df = pd.read_csv(FILE_PATH, encoding="utf-8-sig")
        
        if title in df["文献名称"].values:
            st.warning(f"⚠️ 《{title}》已存在")
            return False
        
        initial_progress = round(current_pages / total_pages * 100, 1) if total_pages > 0 else 0
        
        new_record = {
            "文献名称": title,
            "作者": author,
            "文献类型": literature_type,
            "总页数": int(total_pages),
            "当前页数": int(current_pages),
            "上次进度(%)": initial_progress,
            "咖啡豆数量": 0,
            "添加日期": datetime.now().strftime("%Y-%m-%d %H:%M"),
            "DDL截止日期": ddl_date.strftime("%Y-%m-%d") if ddl_date else ""
        }
        
        df = pd.concat([df, pd.DataFrame([new_record])], ignore_index=True)
        df.to_csv(FILE_PATH, index=False, encoding="utf-8-sig")
        
        return True
        
    except Exception as e:
        st.error(f"❌ 添加失败：{e}")
        return False

def batch_import(batch_text):
    """批量导入文献"""
    if not batch_text.strip():
        st.error("❌ 请输入数据")
        return

    if '，' in batch_text:
        st.error("❌ 检测到中文逗号，请使用<strong>英文逗号</strong>（,）分隔字段")
        st.info("💡 小提示：请将中文逗号替换为英文逗号")
        return
    
    lines = batch_text.strip().split('\n')
    new_records = []
    error_lines = []
    
    for i, line in enumerate(lines, 1):
        line = line.strip()
        if not line:
            continue
        
        parts = [p.strip() for p in line.split(',')]
        
        if len(parts) < 5:
            error_lines.append(f"第{i}行：字段不足（至少需要5个字段，当前只有{len(parts)}个）")
            continue
        
        if len(parts) == 5:
            parts.append("")
        
        try:
            title = parts[0]
            if not title:
                error_lines.append(f"第{i}行：文献名称不能为空")
                continue
                
            author = parts[1]
            literature_type = parts[2]
            
            # 检查页数
            try:
                total_pages = int(parts[3])
                if total_pages <= 0:
                    error_lines.append(f"第{i}行：总页数必须大于0")
                    continue
            except ValueError:
                error_lines.append(f"第{i}行：总页数必须是数字（'{parts[3]}' 不是有效数字）")
                continue
            
            try:
                current_pages = int(parts[4])
                if current_pages < 0:
                    error_lines.append(f"第{i}行：已读页数不能为负数")
                    continue
                if current_pages > total_pages:
                    error_lines.append(f"第{i}行：已读页数({current_pages})不能超过总页数({total_pages})")
                    continue
            except ValueError:
                error_lines.append(f"第{i}行：已读页数必须是数字（'{parts[4]}' 不是有效数字）")
                continue
            
            ddl_str = parts[5].strip()
            if ddl_str:
                try:
                    datetime.strptime(ddl_str, "%Y-%m-%d")
                except ValueError:
                    error_lines.append(f"第{i}行：日期格式错误 '{ddl_str}'，请使用 YYYY-MM-DD 格式")
                    continue
            
            progress = round(current_pages / total_pages * 100, 1) if total_pages > 0 else 0
            
            new_records.append({
                "文献名称": title,
                "作者": author,
                "文献类型": literature_type,
                "总页数": total_pages,
                "当前页数": current_pages,
                "上次进度(%)": progress,
                "咖啡豆数量": 0,
                "添加日期": datetime.now().strftime("%Y-%m-%d %H:%M"),
                "DDL截止日期": ddl_str
            })
            
        except Exception as e:
            error_lines.append(f"第{i}行：格式错误 - {str(e)[:50]}...")
    
    if error_lines:
        st.markdown("""
        <div style="background-color: #FFF0F0; padding: 12px 15px; border-radius: 8px; border: 1px solid #FF6B6B; margin: 15px 0;">
        <p style="margin: 0; color: #8B0000; font-size: 0.85em; font-weight: bold;">⚠️ 导入失败，发现以下错误：</p>
        </div>
        """, unsafe_allow_html=True)
        
        for err in error_lines[:5]:
            st.markdown(f'<p style="margin: 5px 0; color: #8B0000; font-size: 0.8em;">• {err}</p>', unsafe_allow_html=True)
        
        if len(error_lines) > 5:
            st.markdown(f'<p style="margin: 5px 0; color: #8B0000; font-size: 0.8em;">... 还有 {len(error_lines)-5} 个错误未显示</p>', unsafe_allow_html=True)
        
        return
    
    if new_records:
        try:
            df = pd.read_csv(FILE_PATH, encoding="utf-8-sig")
            import_df = pd.DataFrame(new_records)
            
            # 检查重复
            existing_titles = set(df["文献名称"].astype(str).str.strip().tolist())
            new_titles = set(import_df["文献名称"].astype(str).str.strip().tolist())
            duplicates = existing_titles.intersection(new_titles)
            
            if duplicates:
                st.warning(f"⚠️ 发现 {len(duplicates)} 篇文献已存在，将跳过重复项")
                import_df = import_df[~import_df["文献名称"].astype(str).str.strip().isin(duplicates)]
            
            df = pd.concat([df, import_df], ignore_index=True)
            df.to_csv(FILE_PATH, index=False, encoding="utf-8-sig")
            
            st.success(f"✅ 成功导入 {len(new_records)} 篇文献")
            time.sleep(2)
            st.rerun()
            
        except Exception as e:
            st.error(f"❌ 导入失败：{str(e)}")
    else:
        st.info("📭 没有可导入的有效数据")

def show_literature_list_with_actions():
    """显示文献列表和操作"""
    st.markdown("---")
    st.markdown("### 📋 文献列表")
    
    # 初始化编辑状态
    if 'editing_mode' not in st.session_state:
        st.session_state.editing_mode = False
    
    try:
        df = pd.read_csv(FILE_PATH, encoding="utf-8-sig", dtype={
            "文献名称": str,
            "作者": str,
            "文献类型": str,
            "总页数": "Int64",
            "当前页数": "Int64",
            "上次进度(%)": float,
            "DDL截止日期": str,
            "咖啡豆数量": "Int64"
        })
        
        df["作者"] = df["作者"].fillna("").astype(str)
        df["文献类型"] = df["文献类型"].fillna("").astype(str)
        df["DDL截止日期"] = df["DDL截止日期"].fillna("").astype(str)
        
        if df.empty or "文献名称" not in df.columns:
            st.markdown("""
            <div style="background-color: #f8f4f0; border: 1px solid #e3ded9; border-radius: 8px; padding: 20px; text-align: center; margin: 20px 0;">
            <p style="margin: 0; color: #8d6e63; font-size: 0.9em;">📭 暂无文献数据</p>
            </div>
            """, unsafe_allow_html=True)
            return
        
        df = df[df["文献名称"].notna() & (df["文献名称"].str.strip() != "")]
        
        if df.empty:
            st.markdown("""
            <div style="background-color: #f8f4f0; border: 1px solid #e3ded9; border-radius:8px; padding: 20px; text-align: center; margin: 20px 0;">
            <p style="margin: 0; color: #8d6e63; font-size: 0.9em;">📭 暂无有效文献</p>
            </div>
            """, unsafe_allow_html=True)
            return
        
        today = datetime.now().date()
        
        def get_ddl_status(row):
            ddl_str = str(row.get("DDL截止日期", "")).strip()
            
            if not ddl_str or ddl_str.lower() in ["nan", "none", "null", ""]:
                return "无DDL"
            
            ddl_date = parse_date(ddl_str)
            if not ddl_date:
                return "日期错误"
            
            days_left = (ddl_date - today).days
            current_pages = int(row.get("当前页数", 0) or 0)
            total_pages = int(row.get("总页数", 0) or 0)
            completed = total_pages > 0 and current_pages >= total_pages
            
            if days_left < 0:
                if completed:
                    return "✅ 超时完成"
                else:
                    return f"⚠️ 已过期{abs(days_left)}天"
            elif days_left == 0:
                return "⏰ 今天到期"
            elif days_left <= 3:
                return f"⏰ {days_left}天后"
            elif days_left <= 7:
                return f"📅 {days_left}天后"
            else:
                return f"{days_left}天后"
        
        df["DDL状态"] = df.apply(get_ddl_status, axis=1)
        
        # 准备显示的列
        display_cols = ["文献名称", "作者", "文献类型", "总页数", "当前页数", "上次进度(%)", "DDL截止日期", "DDL状态"]
        available_cols = [col for col in display_cols if col in df.columns]
        if st.session_state.editing_mode:
           # 编辑模式下才加原始索引和删除列
           final_df = df[available_cols].copy().reset_index().rename(columns={"index": "原始索引"})
           final_df["删除"] = False
        else:
            # 查看模式下干净显示
            final_df = df[available_cols].copy()

        
        # 排序
        status_order = {}
        for idx, status in enumerate(final_df["DDL状态"].unique()):
            if "已过期" in status:
                status_order[status] = 0
            elif "今天到期" in status:
                status_order[status] = 1
            elif "天后" in status and "⏰" in status:
                try:
                    days = int(status.replace("⏰ ", "").replace("天后", ""))
                    status_order[status] = 2 + days
                except:
                    status_order[status] = 10
            elif "天后" in status and "📅" in status:
                try:
                    days = int(status.replace("📅 ", "").replace("天后", ""))
                    status_order[status] = 5 + days
                except:
                    status_order[status] = 15
            elif "✅" in status:
                status_order[status] = 20
            elif "无DDL" in status:
                status_order[status] = 30
            else:
                status_order[status] = 99
        
        final_df["状态排序"] = final_df["DDL状态"].apply(lambda x: status_order.get(x, 99))
        final_df = final_df.sort_values("状态排序")
        final_df = final_df.drop(columns=["状态排序"])
        
        # 操作按钮
        col_edit, col_space, col_delete_all = st.columns([1, 4, 1])
        
        with col_edit:
            if st.button("📝 编辑表格", type="primary" if not st.session_state.editing_mode else "secondary"):
                st.session_state.editing_mode = not st.session_state.editing_mode
                st.rerun()
        
        with col_delete_all:
            if st.button("🗑️ 清空文献", type="secondary"):
                if st.session_state.get('confirm_delete_all', False):
                    df = pd.DataFrame(columns=df.columns)
                    df.to_csv(FILE_PATH, index=False, encoding="utf-8-sig")
                    st.success("✅ 所有文献已删除")
                    time.sleep(1)
                    st.session_state.confirm_delete_all = False
                    st.rerun()
                else:
                    st.session_state.confirm_delete_all = True
                    st.warning("⚠️ 再次点击确认删除全部文献")
                    time.sleep(2)
                    st.session_state.confirm_delete_all = False
        
        if st.session_state.editing_mode:
            # 编辑模式
            final_df["删除"] = False
            st.markdown("""
            <div style="background-color: #fff8e1; padding: 12px 15px; border-radius: 8px; margin: 10px 0; border-left: 4px solid #ffb74d;">
            <p style="margin: 0; color: #5d4037; font-size: 0.85em;">
            ✏️ <strong>编辑模式：</strong>勾选要删除的行，或直接修改数据，完成后点击保存
            </p>
            </div>
            """, unsafe_allow_html=True)
            
            # 在数据编辑器中添加"删除"复选框列
            edited_df = st.data_editor(
                final_df,
                hide_index=True,
                num_rows="dynamic",
                column_config={
                    "删除": st.column_config.CheckboxColumn(
                        "删除",
                        default=False,
                        width="small"
                    ),
                    "文献名称": st.column_config.TextColumn("文献名称", width="large", required=True),
                    "作者": st.column_config.TextColumn("作者", default="", help="作者姓名"),
                    "文献类型": st.column_config.TextColumn("文献类型"),
                    "总页数": st.column_config.NumberColumn("总页数", min_value=1, required=True),
                    "当前页数": st.column_config.NumberColumn("当前页数", min_value=0),
                    "上次进度(%)": st.column_config.ProgressColumn("进度(%)", help="阅读进度", format="%.1f%%", min_value=0, max_value=100),
                    "DDL截止日期": st.column_config.TextColumn("DDL截止日期", help="格式：YYYY-MM-DD（如2024-12-31）")
                },
                # 将"删除"列放在最前面
                column_order=["删除"] + [col for col in final_df.columns if col != "删除"]
            )
            
            col_save, col_delete_selected, col_cancel = st.columns(3)
            
            with col_save:
                if st.button("💾 保存修改", type="primary"):
                    
                    # 处理勾选删除的行
                    rows_to_delete_positions = []
                    for i, row in edited_df.iterrows():
                        if row.get("删除", False):
                            rows_to_delete_positions.append(i)
                    
                    if rows_to_delete_positions:
                        # 获取原始索引
                        original_indices = df.index.tolist()
                        indices_to_delete = []
                        for pos in rows_to_delete_positions:
                            if pos < len(original_indices):
                                indices_to_delete.append(original_indices[pos])
                        
                        if indices_to_delete:
                            df = df.drop(indices_to_delete)
                            st.info(f"✅ 已删除 {len(indices_to_delete)} 篇文献")
                    
                    # 重置索引
                    df = df.reset_index(drop=True)
                    
                    # 更新剩余行的数据
                    current_original_idx = 0
                    for i, row in edited_df.iterrows():
                        if row.get("删除", False):
                            continue
                        
                        if current_original_idx < len(df):
                            df.loc[current_original_idx, "文献名称"] = row.get("文献名称", "")
                            df.loc[current_original_idx, "作者"] = row.get("作者", "")
                            df.loc[current_original_idx, "文献类型"] = row.get("文献类型", "")
                            
                            total_pages = int(row.get("总页数", 0))
                            current_pages = int(row.get("当前页数", 0))
                            df.loc[current_original_idx, "总页数"] = total_pages
                            df.loc[current_original_idx, "当前页数"] = current_pages
                            
                            if total_pages > 0:
                                progress = round(current_pages / total_pages * 100, 1)
                            else:
                                progress = 0
                            df.loc[current_original_idx, "上次进度(%)"] = progress
                            
                            ddl_date = row.get("DDL截止日期")
                            if pd.notna(ddl_date):
                                if isinstance(ddl_date, str):
                                    df.loc[current_original_idx, "DDL截止日期"] = ddl_date
                                else:
                                    df.loc[current_original_idx, "DDL截止日期"] = ddl_date.strftime("%Y-%m-%d")
                            else:
                                df.loc[current_original_idx, "DDL截止日期"] = ""
                            
                            current_original_idx += 1
                    
                    df.to_csv(FILE_PATH, index=False, encoding="utf-8-sig")
                    st.session_state.editing_mode = False
                    st.success("✅ 修改已保存")
                    time.sleep(1)
                    st.rerun()
            
            with col_delete_selected:
                selected_rows = edited_df[edited_df["删除"] == True]
                if not selected_rows.empty:
                    if st.button(f"🗑️ 删除选中 ({len(selected_rows)})"):
                       df = pd.read_csv(FILE_PATH, encoding="utf-8-sig")
                       indices_to_delete = selected_rows["原始索引"].tolist()
                       df = df.drop(indices_to_delete).reset_index(drop=True)
                       df.to_csv(FILE_PATH, index=False, encoding="utf-8-sig")
                       st.success(f"✅ 已删除 {len(indices_to_delete)} 篇文献")
                       st.session_state.editing_mode = False
                       st.rerun()
                else:
                    st.button("🗑️ 删除选中", type="secondary", disabled=True)
            with col_cancel:
                if st.button("❌ 取消编辑"):
                    st.session_state.editing_mode = False
                    st.rerun()
        
        else:
            # 查看模式
            st.data_editor(
                final_df,
                hide_index=True,
                disabled=True,
                column_config={
                    "上次进度(%)": st.column_config.ProgressColumn("进度(%)", help="阅读进度", format="%.1f%%", min_value=0, max_value=100),
                    "DDL状态": st.column_config.TextColumn("DDL状态", help="截止日期状态", disabled=True)
                }
            )
        
    except Exception as e:
        st.error(f"❌ 读取失败：{e}")
