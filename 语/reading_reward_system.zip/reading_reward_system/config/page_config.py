import streamlit as st

def setup_page():
    """设置Streamlit页面配置"""
    st.set_page_config(
        page_title='汉语言文学ADHD文献阅读激励系统',
        page_icon='☕',
        layout='wide',
        initial_sidebar_state='collapsed',
        menu_items={
            'Get Help': None,
            'Report a bug': None,
            'About': None
        }
    )
    
    st.markdown("""
        <style>
            [title*="keyboard"], 
            [aria-label*="keyboard"],
            div[data-testid="stToolbar"] {
                display: none !important;
            }
        </style>
    """, unsafe_allow_html=True)
