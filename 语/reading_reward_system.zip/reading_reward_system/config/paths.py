from pathlib import Path

BASE_DIR = Path(__file__).parent.parent
DATA_DIR = BASE_DIR / 'data'
ASSETS_DIR = BASE_DIR / 'assets'

# 主要路径
FILE_PATH = DATA_DIR / '文献清单.csv'
SHOP_DATA_PATH = DATA_DIR / 'shop_data.json'
TIMER_RECORDS_PATH = DATA_DIR / 'timer_records.json'
DIALOGUE_RECORDS_PATH = DATA_DIR / '店长对话记录.json'

# 资源路径
BACKGROUNDS_DIR = ASSETS_DIR / 'backgrounds'
COFFEE_DIR = ASSETS_DIR / 'coffee'
PETS_DIR = ASSETS_DIR / 'pets'
TRAY_DIR = ASSETS_DIR / 'tray'

# 创建目录
for directory in [DATA_DIR, ASSETS_DIR, BACKGROUNDS_DIR, COFFEE_DIR, PETS_DIR, TRAY_DIR]:
    directory.mkdir(parents=True, exist_ok=True)

def get_coffee_image_path(coffee_id):
    """获取咖啡图片路径"""
    coffee_images = {
        'coffee_caramel': 'caramel.png',
        'coffee_matcha': 'matcha.png',
        'coffee_seasonal': 'seasonal.png',
        'coffee_chocolate': 'chocolate.png',
        'coffee_diy': 'diy.png'
    }
    
    filename = coffee_images.get(coffee_id)
    if filename:
        path = COFFEE_DIR / filename
        if path.exists():
            return str(path)
    return None
