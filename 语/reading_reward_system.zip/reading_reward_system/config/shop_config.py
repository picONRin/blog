# 背景主题配置
BACKGROUNDS = {
    'none': {'name': '无背景', 'price': 0, 'description': '默认简约背景'},
    'bar': {'name': '吧台絮语', 'price': 50, 'description': '温馨的咖啡吧台'},
    'gallery': {'name': '画酌小廊', 'price': 100, 'description': '艺术画廊风格'},
    'wood': {'name': '晴午木息所', 'price': 150, 'description': '阳光木屋'}
}

# 咖啡饮品配置
COFFEES = {
    'caramel': {'name': '焦糖玛奇朵', 'price': 0, 'description': '经典焦糖风味'},
    'matcha': {'name': '抹茶拿铁', 'price': 20, 'description': '清新抹茶，提神醒脑'},
    'seasonal': {'name': '季节限定', 'price': 40, 'description': '每季更新的特色饮品'},
    'chocolate': {'name': '巧克力奶油顶', 'price': 60, 'description': '浓郁巧克力搭配奶油顶'},
    'diy': {'name': 'DIY版', 'price': 0, 'description': '巧克力少奶油的自定义版本'}
}

# 咖啡师等级
BARISTA_LEVELS = [
    {'name': '普通顾客', 'focus_required': 0, 'description': '刚刚开始阅读之旅'},
    {'name': '业余爱好者', 'focus_required': 10, 'description': '绿围裙咖啡师'},
    {'name': '资深爱好者', 'focus_required': 30, 'description': '蓝围裙咖啡师'},
    {'name': '初级咖啡师', 'focus_required': 50, 'description': '专业咖啡师形象'},
    {'name': '店长', 'focus_required': 100, 'description': '黑围裙+特殊对话权限'}
]

def get_current_level(focus_count):
    """根据专注次数获取当前等级"""
    for level in reversed(BARISTA_LEVELS):
        if focus_count >= level['focus_required']:
            return level['name']
    return '普通顾客'

def get_unlocked_items(focus_count):
    """获取解锁物品列表"""
    unlocked = {'backgrounds': ['none'], 'coffees': ['caramel']}
    
    if focus_count >= 10:
        unlocked['coffees'].append('matcha')
        unlocked['backgrounds'].append('bar')
    if focus_count >= 30:
        unlocked['coffees'].append('seasonal')
        unlocked['backgrounds'].append('gallery')
    if focus_count >= 50:
        unlocked['coffees'].append('chocolate')
        unlocked['backgrounds'].append('wood')
    if focus_count >= 100:
        unlocked['coffees'].append('diy')
    
    return unlocked
