import streamlit as st
import json
import os
from pathlib import Path

from config.page_config import setup_page
from styles.global_css import load_global_css, load_top_background
from modules.literature import literature_manager
from modules.progress import progress_sync
from modules.dialogue import shopkeeper_dialogue_history
from modules.focus import focus_records
from modules.shop import show_shop, ShopManager

# 把 setup_page() 调用移到最前面
setup_page()

def repair_timer_records_file():
    try:
        from config.paths import DATA_DIR
        timer_record_path = os.path.join(DATA_DIR, "timer_records.json")
        
        if os.path.exists(timer_record_path):
            with open(timer_record_path, 'r', encoding='utf-8') as f:
                content = f.read().strip()
            
            if content.isdigit() or (content.startswith('-') and content[1:].isdigit()):
                fixed_data = {
                    "focus_records": [],
                    "total_focus_time": int(content) if content.lstrip('-').isdigit() else 0
                }
                
                with open(timer_record_path, 'w', encoding='utf-8') as f:
                    json.dump(fixed_data, f, ensure_ascii=False, indent=2)
                
                return True
                
        return False
        
    except json.JSONDecodeError:
        fixed_data = {
            "focus_records": [],
            "total_focus_time": 0
        }
        
        with open(timer_record_path, 'w', encoding='utf-8') as f:
            json.dump(fixed_data, f, ensure_ascii=False, indent=2)
        
        return True
    except Exception:
        return False

try:
    from services.beans_service import get_coffee_beans
    BEANS_SERVICE_AVAILABLE = True
except ImportError:
    BEANS_SERVICE_AVAILABLE = False
    def get_coffee_beans():
        try:
            shop = ShopManager()
            return shop.get_total_beans()
        except:
            return 0

def init_shop_data():
    DATA_DIR = Path(__file__).parent / "data"
    SHOP_DATA_PATH = DATA_DIR / "shop_data.json"
    
    try:
        shop = ShopManager()
        user_data = shop.user_data
        
        if not isinstance(user_data, dict):
            return {
                "equipped": {
                    "background": "bg_none",
                    "coffee": "coffee_caramel"
                },
                "unlocked": {
                    "backgrounds": ["bg_none"],
                    "coffees": ["coffee_caramel"],
                    "barista_level": "普通顾客"
                },
                "beans": shop.get_total_beans(),
                "focus_count": user_data.get("achievements", {}).get("focus_count", 0) if isinstance(user_data, dict) else 0
            }
        
        return {
            "equipped": user_data.get("equipped", {"background": "bg_none", "coffee_pet": "coffee_caramel"}),
            "unlocked": {
                "backgrounds": ["bg_none"],
                "coffees": ["coffee_caramel"],
                "barista_level": user_data.get("achievements", {}).get("current_barista", "普通顾客")
            },
            "beans": shop.get_total_beans(),
            "focus_count": user_data.get("achievements", {}).get("focus_count", 0)
        }
        
    except Exception:
        return {
            "equipped": {
                "background": "bg_none",
                "coffee": "coffee_caramel"
            },
            "unlocked": {
                "backgrounds": ["bg_none"],
                "coffees": ["coffee_caramel"],
                "barista_level": "普通顾客"
            },
            "beans": 0,
            "focus_count": 0
        }

def update_focus_data():
    try:
        from config.paths import DATA_DIR
        
        timer_record_path = os.path.join(DATA_DIR, "timer_records.json")
        if not os.path.exists(timer_record_path):
            default_timer_data = {
                "focus_records": [],
                "total_focus_time": 0
            }
            with open(timer_record_path, 'w', encoding='utf-8') as f:
                json.dump(default_timer_data, f, ensure_ascii=False, indent=2)
            timer_data = default_timer_data
        else:
            with open(timer_record_path, 'r', encoding='utf-8') as f:
                timer_data = json.load(f)
        
        if not isinstance(timer_data, dict):
            timer_data = {
                "focus_records": [],
                "total_focus_time": 0
            }
            with open(timer_record_path, 'w', encoding='utf-8') as f:
                json.dump(timer_data, f, ensure_ascii=False, indent=2)
        
        if "focus_records" not in timer_data:
            timer_data["focus_records"] = []
        if not isinstance(timer_data["focus_records"], list):
            timer_data["focus_records"] = []
        
        if "total_focus_time" not in timer_data:
            timer_data["total_focus_time"] = 0
        
        focus_count = len(timer_data.get('focus_records', []))
        coffee_beans = get_coffee_beans()
        
        shop = ShopManager()
        achievements = shop.user_data.get("achievements", {})
        if isinstance(achievements, dict):
            achievements["focus_count"] = focus_count
            
            if focus_count >= 100:
                achievements["current_barista"] = "店长"
            elif focus_count >= 50:
                achievements["current_barista"] = "初级咖啡师"
            elif focus_count >= 30:
                achievements["current_barista"] = "资深爱好者"
            elif focus_count >= 10:
                achievements["current_barista"] = "业余爱好者"
            else:
                achievements["current_barista"] = "普通顾客"
            
            shop._save_user_data()
            
        return focus_count, coffee_beans
        
    except Exception:
        return 0, 0

def main():
    repair_timer_records_file()
    
    load_global_css()
    
    shop_data = init_shop_data()
    if shop_data and 'equipped' in shop_data and 'background' in shop_data['equipped']:
        current_bg = shop_data['equipped']['background']
        
        bg_mapping = {
            "bg_none": "none",
            "bg_bar": "bar.png",
            "bg_gallery": "gallery.png",
            "bg_wood": "wood.png"
        }
        
        bg_image = bg_mapping.get(current_bg, "none")
        if bg_image != "none":
            try:
                load_top_background(bg_image, height=180)
            except Exception:
                pass
    else:
        pass
    
    hide_streamlit_keyboard_shortcuts()
    
    shop_data = init_shop_data()
    focus_count, coffee_beans = update_focus_data()

    st.markdown("""
        <style>
        .stApp > header {
            display: none !important;
            visibility: hidden !important;
            height: 0 !important;
            min-height: 0 !important;
            padding: 0 !important;
            margin: 0 !important;
        }
        
        .main .block-container {
            padding-top: 0.1rem !important;
            padding-bottom: 1rem !important;
        }
        
        .main-container {
            margin-top: 0 !important;
            padding-top: 5px !important;
        }
        
        div[data-testid="stVerticalBlock"] > div:first-child {
            padding-top: 0 !important;
            margin-top: 0 !important;
        }
        
        .top-status-bar {
            background: linear-gradient(135deg, #f5f1e9 0%, #fff8e1 100%);
            border-bottom: 2px solid #d7ccc8;
            padding: 10px 20px;
            margin-bottom: 15px;
            border-radius: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        .status-item {
            display: flex;
            align-items: center;
            font-size: 14px;
            font-weight: 500;
            color: #5d4037;
        }
        
        .status-item span {
            margin-left: 5px;
            font-weight: bold;
        }
        
        .status-divider {
            width: 1px;
            height: 20px;
            background: #bcaaa4;
            margin: 0 15px;
        }
        </style>
    """, unsafe_allow_html=True)

    st.markdown('<div class="main-container">', unsafe_allow_html=True)
    
    st.markdown(f"""
        <div class="top-status-bar">
            <div class="status-item">
                ☕ 咖啡豆: <span>{coffee_beans}枚</span>
            </div>
            <div class="status-divider"></div>
            <div class="status-item">
                ⏱️ 专注次数: <span>{focus_count}次</span>
            </div>
            <div class="status-divider"></div>
            <div class="status-item">
                🏆 咖啡师等级: <span>{shop_data.get('unlocked', {}).get('barista_level', '普通顾客')}</span>
            </div>
        </div>
    """, unsafe_allow_html=True)

    st.markdown("""
        <div style="margin-bottom: 5px; padding-top: 0;">
            <h1>📚 汉语言文学ADHD文献阅读激励系统</h1>
            <p class="caption">专为ADHD群体设计的简洁文献阅读管理系统</p>
        </div>
    """, unsafe_allow_html=True)

    tab1, tab2, tab3, tab4, tab5 = st.tabs([
        "📖 文献管理",
        "📊 进度追踪", 
        "💬 对话历史",
        "🏪 奖励商店",
        "⏱️ 专注记录"
    ])

    with tab1:
        literature_manager()

    with tab2:
        progress_sync()

    with tab3:
        shopkeeper_dialogue_history()

    with tab4:
        show_shop()

    with tab5:
        focus_records()

    st.markdown("---")
    st.markdown(
        '<div class="footer">'
        '☕ 汉语言文学ADHD群体文献阅读激励系统 · 智能店长陪伴您的阅读之旅<br>'
        '<small>💡 提示：在桌面计时器中与店长对话，然后在此页面查看历史记录</small><br>'
        '<small>🐾 提示：点击悬浮窗的"缩小为桌宠"按钮，可获得桌面宠物陪伴</small>'
        '</div>',
        unsafe_allow_html=True
    )

    st.markdown('</div>', unsafe_allow_html=True)


def hide_streamlit_keyboard_shortcuts():
    hide_streamlit_style = """
        <style>
        div[data-testid="stToolbar"] {
            display: none !important;
        }
        
        button[kind="secondaryIcon"] {
            display: none !important;
        }
        
        div[data-testid="stDecoration"] {
            display: none !important;
        }
        
        button[kind="header"] {
            display: none !important;
        }
        
        footer[data-testid="stFooter"] {
            display: none !important;
        }
        
        .stTooltipIcon {
            display: none !important;
        }
        
        [title*="keyboard"], 
        [aria-label*="keyboard"],
        [data-testid*="keyboard"],
        [class*="shortcut"] {
            display: none !important;
        }
        </style>
    """
    st.markdown(hide_streamlit_style, unsafe_allow_html=True)


if __name__ == "__main__":
    main()
