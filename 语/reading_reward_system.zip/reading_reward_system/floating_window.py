import tkinter as tk
from tkinter import ttk, messagebox
import pandas as pd
import os
import threading
import time
import json
import random
import requests
import queue
import sys
import datetime
import subprocess
import pickle
import base64

current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, current_dir)

try:
    from config.paths import DATA_DIR, FILE_PATH, TIMER_RECORD_PATH, DIALOGUE_HISTORY_PATH
    if not os.path.exists(DATA_DIR):
        os.makedirs(DATA_DIR)
    WEB_SYNC_URL = "http://localhost:8501"
except ImportError:
    DATA_DIR = os.path.join(current_dir, "data")
    if not os.path.exists(DATA_DIR):
        os.makedirs(DATA_DIR)
    FILE_PATH = os.path.join(DATA_DIR, "文献清单.csv")
    TIMER_RECORD_PATH = os.path.join(DATA_DIR, "timer_records.json")
    DIALOGUE_HISTORY_PATH = os.path.join(DATA_DIR, "店长对话记录.json")
    WEB_SYNC_URL = "http://localhost:8501"

try:
    from communication import InterProcessCommunication
    COMM_AVAILABLE = True
except ImportError:
    COMM_AVAILABLE = False
    InterProcessCommunication = None

try:
    from services.beans_service import get_coffee_beans, add_coffee_beans
    BEANS_SERVICE_AVAILABLE = True
except ImportError:
    BEANS_SERVICE_AVAILABLE = False
    def get_coffee_beans():
        try:
            shop_data_path = os.path.join(DATA_DIR, "shop_data.json")
            if os.path.exists(shop_data_path):
                with open(shop_data_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                return data.get("coffee_beans", 0)
            return 0
        except:
            return 0

DEEPSEEK_API_KEY = "sk-27a9ef3d4cc34388ab22e386c94a3be0"

class DataSynchronizer:
    def __init__(self, file_path):
        self.file_path = file_path
        self.last_sync_time = 0
        self.lock = threading.RLock()
    
    def load_data_safe(self):
        with self.lock:
            try:
                if os.path.exists(self.file_path):
                    df = pd.read_csv(self.file_path, encoding="utf-8-sig")
                    df.columns = df.columns.str.strip()
                    return df
                else:
                    return pd.DataFrame()
            except Exception:
                return pd.DataFrame()
    
    def save_data_safe(self, df):
        with self.lock:
            try:
                df.to_csv(self.file_path, index=False, encoding="utf-8-sig")
                self.last_sync_time = time.time()
                return True
            except Exception:
                return False

class ReadingTimer:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("阅读计时器")
        
        self.data_sync = DataSynchronizer(FILE_PATH)
        
        self.root.attributes('-topmost', False)
        self.root.attributes('-alpha', 0.95)
        self.original_size = (500, 600)
        self.mini_size = (220, 100)
        self.root.geometry(f"{self.original_size[0]}x{self.original_size[1]}")
        self.root.resizable(False, False)
        self.root.configure(bg='#f5f1e9')

        self.big_font = ("微软雅黑", 28, "bold")
        self.medium_font = ("微软雅黑", 14, "bold")
        self.small_font = ("微软雅黑", 10)

        style = ttk.Style()
        style.theme_use("clam")
        style.configure(".", background="#f5f1e9", foreground="#5d4037")
        style.configure("TButton", background="#d7ccc8", foreground="#5d4037", borderwidth=1, padding=8, font=("微软雅黑", 10))
        style.map("TButton", background=[("active", "#bcaaa4")], foreground=[("active", "#3e2723")])
        style.configure("Float.TButton", background="#d7ccc8", borderwidth=1, padding=8, foreground="#5d4037")
        style.configure("TCombobox", fieldbackground="#ffffff", foreground="#5d4037", font=("微软雅黑", 11))
        style.map("TCombobox", fieldbackground=[("readonly", "#ffffff")], foreground=[("readonly", "#5d4037")])
        style.configure("Custom.TFrame", background="#f5f1e9")
        style.configure("Custom.TLabel", background="#f5f1e9", foreground="#5d4037")
        style.configure("TRadiobutton", background="#f5f1e9", foreground="#5d4037", font=("微软雅黑", 11))

        self.is_minified = False
        self.is_floating = False
        self.is_running = False
        self.start_time = 0
        self.elapsed_time = 0
        self.drag_data = {"x": 0, "y": 0}
        self.original_pos = (0, 0)
        self.consecutive_sessions = 0
        self.session_paused = False
        self.selected_literature = None
        self.target_minutes = 5
        self.total_seconds = 0
        self.remaining_seconds = 0
        
        self.pet_process = None
        self.message_queue = queue.Queue()
        self.stop_event = threading.Event()
        self._processing_update = False
        self._timer_update_id = None
        self._timer_lock = threading.RLock()
        self.dialogue_history = self.init_dialogue_history()
        
        self.comm = InterProcessCommunication("reading_timer") if COMM_AVAILABLE else None
        self.sync_interval = 1000
        
        if self.comm:
            self.comm.start_listener(self.handle_restore_signal)

        title_bg_frame = tk.Frame(self.root, bg="#a1887f", height=40)
        title_bg_frame.pack(fill=tk.X)
        title_bg_frame.pack_propagate(False)
        
        self.title_frame = ttk.Frame(title_bg_frame, style="Custom.TFrame")
        self.title_frame.pack(fill=tk.BOTH, expand=True, padx=2, pady=2)
        self.title_frame.bind("<Button-1>", self.start_drag)
        self.title_frame.bind("<B1-Motion>", self.drag_window)

        self.title_label = ttk.Label(self.title_frame, text="⏱️ 阅读计时器", font=self.medium_font, style="Custom.TLabel", foreground="#ffffff", background="#a1887f")
        self.title_label.pack(side=tk.LEFT, padx=10)
        self.title_label.bind("<Button-1>", self.start_drag)
        self.title_label.bind("<B1-Motion>", self.drag_window)

        btn_frame = ttk.Frame(self.title_frame, style="Custom.TFrame")
        btn_frame.pack(side=tk.RIGHT, padx=5)

        self.mini_btn = ttk.Button(btn_frame, text="−", command=self.toggle_minify, width=3)
        self.mini_btn.pack(side=tk.LEFT, padx=2)

        self.float_btn = ttk.Button(btn_frame, text="📌", command=self.toggle_float, style="Float.TButton", width=3)
        self.float_btn.pack(side=tk.LEFT, padx=2)

        self.close_btn = ttk.Button(btn_frame, text="×", command=self.cleanup, width=3)
        self.close_btn.pack(side=tk.LEFT, padx=2)

        main_container = tk.Frame(self.root, bg="#f5f1e9")
        main_container.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        self.func_container = ttk.Frame(main_container, style="Custom.TFrame")
        self.func_container.pack(fill=tk.BOTH, expand=True)

        mode_container = tk.Frame(self.func_container, bg="#f5f1e9", padx=10, pady=10)
        mode_container.pack(fill=tk.X, pady=5)
        
        tk.Label(mode_container, text="计时模式：", bg="#f5f1e9", fg="#5d4037", font=("微软雅黑", 11, "bold")).pack(side=tk.LEFT, padx=(0, 15))
        
        self.mode_var = tk.StringVar(value="quick")
        mode_btn_frame = tk.Frame(mode_container, bg="#f5f1e9")
        mode_btn_frame.pack(side=tk.LEFT, expand=True, fill=tk.X)
        
        tk.Radiobutton(mode_btn_frame, text="5分钟启动模式", variable=self.mode_var, value="quick", command=self.on_mode_change, bg="#f5f1e9", fg="#5d4037", selectcolor="#f5f1e9", font=("微软雅黑", 10), activebackground="#f5f1e9").pack(side=tk.LEFT, padx=5)
        tk.Radiobutton(mode_btn_frame, text="自定义时间模式", variable=self.mode_var, value="custom", command=self.on_mode_change, bg="#f5f1e9", fg="#5d4037", selectcolor="#f5f1e9", font=("微软雅黑", 10), activebackground="#f5f1e9").pack(side=tk.LEFT, padx=5)

        self.target_container = tk.Frame(self.func_container, bg="#f5f1e9")
        self.target_container.pack(fill=tk.X, pady=8, padx=10)
        
        tk.Label(self.target_container, text="设置目标时长：", bg="#f5f1e9", fg="#5d4037", font=("微软雅黑", 11)).pack(side=tk.LEFT, padx=(0, 10))
        
        self.target_var = tk.StringVar(value="30")
        
        self.target_entry = tk.Entry(self.target_container, textvariable=self.target_var, width=8, font=("微软雅黑", 11), bg="#ffffff", fg="#5d4037", relief=tk.SOLID, bd=1)
        self.target_entry.pack(side=tk.LEFT, padx=5)
        self.target_entry.bind('<FocusOut>', self.on_target_entry_change)
        self.target_entry.bind('<Return>', self.on_target_entry_change)
        
        tk.Label(self.target_container, text="分钟", bg="#f5f1e9", fg="#5d4037", font=("微软雅黑", 11)).pack(side=tk.LEFT, padx=5)
        
        self.quick_buttons_frame = tk.Frame(self.target_container, bg="#f5f1e9")
        self.quick_buttons_frame.pack(side=tk.LEFT, padx=(15, 0))
        
        quick_times = [15, 30, 60]
        for minutes in quick_times:
            btn = tk.Button(self.quick_buttons_frame, text=f"{minutes}分", command=lambda m=minutes: self.set_target_time(m), width=6, bg="#d7ccc8", fg="#5d4037", font=("微软雅黑", 9), relief=tk.RAISED, bd=1)
            btn.pack(side=tk.LEFT, padx=3)

        lit_frame = tk.Frame(self.func_container, bg="#f5f1e9", padx=10)
        lit_frame.pack(fill=tk.X, pady=(10, 5))
        
        tk.Label(lit_frame, text="选择阅读文献：", bg="#f5f1e9", fg="#5d4037", font=("微软雅黑", 11, "bold")).pack(anchor=tk.W, pady=(0, 5))
        
        self.lit_var = tk.StringVar(value='选择阅读文献')
        self.lit_combo = ttk.Combobox(lit_frame, textvariable=self.lit_var, width=45, state="readonly", font=("微软雅黑", 11), height=8)
        self.lit_combo.pack(pady=5)

        timer_frame = tk.Frame(self.func_container, bg="#f5f1e9")
        timer_frame.pack(pady=30)
        
        self.time_label = tk.Label(timer_frame, text="05:00", font=self.big_font, foreground="#8d6e63", bg="#f5f1e9")
        self.time_label.pack()

        ctrl_frame = tk.Frame(self.func_container, bg="#f5f1e9")
        ctrl_frame.pack(pady=20, fill=tk.X, padx=10)

        self.start_btn = tk.Button(ctrl_frame, text="▶️ 开始计时", command=self.start_timer_optimized, bg="#a1887f", fg="white", font=("微软雅黑", 11), relief=tk.RAISED, bd=2, padx=20, pady=8)
        self.start_btn.pack(side=tk.LEFT, padx=5, expand=True, fill=tk.X)

        self.pause_btn = tk.Button(ctrl_frame, text="⏸️ 暂停", command=self.pause_timer_optimized, state=tk.DISABLED, bg="#d7ccc8", fg="#5d4037", font=("微软雅黑", 11), relief=tk.RAISED, bd=2, padx=20, pady=8)
        self.pause_btn.pack(side=tk.LEFT, padx=5, expand=True, fill=tk.X)

        self.reset_btn = tk.Button(ctrl_frame, text="🔄 重置", command=self.reset_timer_optimized, bg="#d7ccc8", fg="#5d4037", font=("微软雅黑", 11), relief=tk.RAISED, bd=2, padx=20, pady=8)
        self.reset_btn.pack(side=tk.LEFT, padx=5, expand=True, fill=tk.X)

        dialogue_frame = tk.Frame(self.func_container, bg="#f5f1e9")
        dialogue_frame.pack(pady=10)

        btn_row_frame = tk.Frame(dialogue_frame, bg="#f5f1e9")
        btn_row_frame.pack(pady=5, fill=tk.X, padx=20)

        self.pet_button = tk.Button(btn_row_frame, text="🐾 缩小为桌宠", command=self.minimize_to_pet, 
                                  bg="#8d6e63", fg="white", font=("微软雅黑", 10), 
                                  relief=tk.RAISED, bd=2, padx=10, pady=5, width=12)
        self.pet_button.pack(side=tk.LEFT, expand=True, padx=5)

        self.dialogue_btn = tk.Button(btn_row_frame, text="💬 和店长聊聊", command=self.open_dialogue_window,
                                    bg="#8d6e63", fg="white", font=("微软雅黑", 10),
                                    relief=tk.RAISED, bd=2, padx=10, pady=5, width=12)
        self.dialogue_btn.pack(side=tk.LEFT, expand=True, padx=5)

        self.refresh_btn = tk.Button(btn_row_frame, text="🔄 刷新文献", command=self.refresh_literatures,
                                   bg="#d7ccc8", fg="#5d4037", font=("微软雅黑", 10, "bold"),
                                   relief=tk.RAISED, bd=2, padx=10, pady=5, width=12)
        self.refresh_btn.pack(side=tk.LEFT, expand=True, padx=5)

        self.shopkeeper_container = tk.Frame(self.func_container, bg="#f5f1e9")
        self.shopkeeper_container.pack(fill=tk.X, pady=10, padx=10)
        self.shopkeeper_container.pack_forget()
        
        self.shopkeeper_frame = tk.Frame(self.shopkeeper_container, bg="#fff3e0", relief=tk.SOLID, bd=1)
        self.shopkeeper_frame.pack(fill=tk.X)
        
        self.shopkeeper_label = tk.Label(self.shopkeeper_frame, text="", bg="#fff3e0", fg="#5d4037", font=("微软雅黑", 11), wraplength=470, justify=tk.LEFT, padx=10, pady=8)
        self.shopkeeper_label.pack()

        stats_container = tk.Frame(self.root, bg="#f5f1e9", height=45)
        stats_container.pack(fill=tk.X, padx=10, pady=5)
        stats_container.pack_propagate(False)
        
        stats_frame = tk.Frame(stats_container, bg="#f5f1e9", relief=tk.RIDGE, bd=1)
        stats_frame.pack(fill=tk.BOTH, padx=5, pady=5)
        
        self.consecutive_var = tk.StringVar(value="连续专注：0次")
        self.consecutive_label = tk.Label(stats_frame, textvariable=self.consecutive_var, bg="#f5f1e9", fg="#5d4037", font=("微软雅黑", 10))
        self.consecutive_label.pack(side=tk.LEFT, padx=10, pady=5)
        
        self.bean_var = tk.StringVar(value="☕ 咖啡豆：0枚")
        self.bean_label = tk.Label(stats_frame, textvariable=self.bean_var, bg="#f5f1e9", fg="#5d4037", font=("微软雅黑", 10, "bold"))
        self.bean_label.pack(side=tk.RIGHT, padx=10, pady=5)

        self.load_literatures()
        self.load_window_pos()
        self.load_timer_records()
        self.start_message_handler()
        self.lit_combo.bind("<<ComboboxSelected>>", self.on_literature_selected)
        self._update_initial_display()
        self.restore_from_pet_flag = False
        self.check_restore_flag()
        self.on_mode_change()
        self.root.after(800, self.show_immediate_ddl_reminder)
        
        if self.comm:
            self.root.after(self.sync_interval, self.sync_timer_state)

    def show_immediate_ddl_reminder(self):
        ddl_info = self.get_due_literatures()
        
        if ddl_info and ddl_info.get("reminder_text"):
            reminder_text = ddl_info["reminder_text"]
            self._show_shopkeeper_message_ui(reminder_text)
            
            self.add_dialogue_entry(
                sender="店长", 
                message=reminder_text, 
                context_type="ddl_reminder",
                extra_data={
                    "due_soon_count": len(ddl_info.get("due_soon", [])),
                    "overdue_count": len(ddl_info.get("overdue", [])),
                    "completed_but_overdue_count": len(ddl_info.get("completed_but_overdue", []))
                }
            )
            
            self.root.after(15000, self.hide_shopkeeper_message)
        else:
            fallback_text = "📅 店长检查了文献清单，暂时没有即将到期的任务，保持节奏就好～"
            self._show_shopkeeper_message_ui(fallback_text)
            self.root.after(8000, self.hide_shopkeeper_message)

    def get_due_literatures(self):
        try:
            today = datetime.datetime.now().date()
            csv_path = os.path.join(DATA_DIR, "文献清单.csv")
            if not os.path.exists(csv_path):
                return None
                
            df = pd.read_csv(csv_path, encoding="utf-8-sig")
            
            if "DDL截止日期" not in df.columns:
                return None
                
            due_soon = []
            overdue = []
            completed_but_overdue = []
            completed_on_time = []
            
            for idx, row in df.iterrows():
                ddl_str = str(row.get("DDL截止日期", "")).strip()
                if not ddl_str or ddl_str.lower() in ["nan", "none", "null"]:
                    continue
                    
                try:
                    ddl_str = ddl_str.split()[0] if ' ' in ddl_str else ddl_str
                    
                    ddl_date = None
                    date_formats = [
                        "%Y-%m-%d", "%Y/%m/%d", "%Y.%m.%d", "%Y年%m月%d日"
                    ]
                    
                    for fmt in date_formats:
                        try:
                            ddl_date = datetime.datetime.strptime(ddl_str, fmt).date()
                            break
                        except ValueError:
                            continue
                    
                    if ddl_date is None:
                        continue
                        
                    days_left = (ddl_date - today).days
                    current_pages = int(row.get("当前页数", 0) or 0)
                    total_pages = int(row.get("总页数", 0) or 0)
                    completed = total_pages > 0 and current_pages >= total_pages
                    lit_name = str(row.get("文献名称", "未知文献"))
                    
                    if days_left < 0:
                        if completed:
                            completed_but_overdue.append({
                                "title": lit_name,
                                "ddl": ddl_str,
                                "days_overdue": abs(days_left),
                                "progress": f"{current_pages}/{total_pages}页"
                            })
                        else:
                            overdue.append({
                                "title": lit_name,
                                "ddl": ddl_str,
                                "days_overdue": abs(days_left),
                                "progress": f"{current_pages}/{total_pages}页",
                                "progress_percent": round(current_pages/total_pages*100, 1) if total_pages > 0 else 0
                            })
                    elif 0 <= days_left <= 3:
                        due_soon.append({
                            "title": lit_name,
                            "ddl": ddl_str,
                            "days_left": days_left,
                            "completed": completed,
                            "progress": f"{current_pages}/{total_pages}页",
                            "progress_percent": round(current_pages/total_pages*100, 1) if total_pages > 0 else 0
                        })
                    elif completed and days_left >= 0:
                        completed_on_time.append({
                            "title": lit_name,
                            "ddl": ddl_str,
                            "days_left_at_completion": days_left
                        })
                        
                except Exception:
                    continue
            
            reminder_text = ""
            
            if overdue:
                overdue_count = len(overdue)
                overdue_titles = "、".join([f"《{item['title'][:12]}...》" for item in overdue[:3]])
                if overdue_count > 3:
                    overdue_titles += f"等{overdue_count}篇"
                
                reminder_text = f"⚠️ 店长提醒：你有{overdue_count}篇文献已过期：{overdue_titles}。\n"
                reminder_text += f"最久的已过期{max([item['days_overdue'] for item in overdue], default=0)}天。\n"
                reminder_text += "可以在文献管理页面处理这些过期文献～"
                
            elif due_soon:
                due_count = len(due_soon)
                due_titles = "、".join([f"《{item['title'][:12]}...》" for item in due_soon[:3]])
                if due_count > 3:
                    due_titles += f"等{due_count}篇"
                
                days_text = ""
                for item in due_soon:
                    if item['days_left'] == 0:
                        days_text = "今天到期"
                    elif item['days_left'] == 1:
                        days_text = "明天到期"
                    else:
                        days_text = f"{item['days_left']}天后到期"
                
                reminder_text = f"📅 店长提醒：你有{due_count}篇文献即将到期：{due_titles}，记得及时完成阅读哦～"
                
                completed_soon = [item for item in due_soon if item['completed']]
                if completed_soon:
                    reminder_text += f"\n\n✅ 其中{len(completed_soon)}篇已经完成啦，真棒！"
            else:
                reminder_text = "📅 店长检查了文献清单，暂时没有即将到期的任务，保持节奏就好～"
                
                total_count = len(df)
                completed_count = len([row for idx, row in df.iterrows() 
                                     if int(row.get("总页数", 0) or 0) > 0 and 
                                     int(row.get("当前页数", 0) or 0) >= int(row.get("总页数", 0) or 0)])
                
                if completed_count > 0:
                    reminder_text += f"\n\n📊 你已经有{completed_count}/{total_count}篇文献完成阅读了，继续保持！"
            
            if completed_but_overdue:
                overdue_completed_count = len(completed_but_overdue)
                reminder_text += f"\n\n💡 另外有{overdue_completed_count}篇文献虽然过期了，但你已经读完了，可以在文献管理页面更新状态哦～"
            
            result = {
                "due_soon": due_soon,
                "overdue": overdue,
                "completed_but_overdue": completed_but_overdue,
                "completed_on_time": completed_on_time,
                "total_count": len(df),
                "completed_count": len(completed_on_time) + len(completed_but_overdue),
                "reminder_text": reminder_text
            }
            
            return result
                
        except Exception:
            return None

    def sync_timer_state(self):
        if self.comm and (self.is_running or self.session_paused):
            remaining_seconds = self.remaining_seconds
            
            if self.is_running:
                current_time = time.time()
                elapsed = current_time - self.start_time
                remaining_seconds = max(0, self.total_seconds - elapsed)
                self.remaining_seconds = remaining_seconds
            
            state_data = {
                "is_running": self.is_running,
                "start_time": self.start_time,
                "elapsed_time": self.elapsed_time,
                "total_seconds": self.total_seconds,
                "remaining_seconds": remaining_seconds,
                "session_paused": self.session_paused,
                "selected_literature": self.selected_literature,
                "target_minutes": self.target_minutes,
                "mode": self.mode_var.get(),
                "timestamp": time.time()
            }
            
            self.comm.write_state("timer_update", state_data)
        
        if self.comm:
            self.root.after(self.sync_interval, self.sync_timer_state)

    def handle_restore_signal(self, signal):
        if signal == "RESTORE":
            self.root.after(0, self.restore_from_pet)

    def on_target_entry_change(self, event=None):
        try:
            input_text = self.target_var.get().strip()
            if not input_text:
                self.target_var.set("30")
                return
            
            clean_text = ''.join(filter(str.isdigit, input_text))
            if not clean_text:
                clean_text = "30"
            
            minutes = int(clean_text)
            
            if minutes < 1:
                minutes = 1
            elif minutes > 999:
                minutes = 999
                
            self.target_var.set(str(minutes))
            
            if self.mode_var.get() == "custom" and not self.is_running:
                self._update_initial_display()
                
        except Exception:
            self.target_var.set("30")

    def reset_literature_progress(self, lit_name):
        try:
            df = self.data_sync.load_data_safe()
            
            matching_rows = df[df["文献名称"] == lit_name]
            if matching_rows.empty:
                return False
            
            idx = matching_rows.index[0]
            df.loc[idx, "当前页数"] = 0
            df.loc[idx, "上次进度(%)"] = 0
            
            if self.data_sync.save_data_safe(df):
                messagebox.showinfo(
                    "重置成功",
                    f"《{lit_name[:20]}{'...' if len(lit_name) > 20 else ''}》\n进度已重置为0页，可以重新开始阅读！"
                )
                
                self.update_beans_display()
                self.root.after(300, lambda: self._trigger_async_dialogue(
                    "literature_reset", 
                    {"literature_name": lit_name}
                ))
                return True
            return False
            
        except Exception as e:
            messagebox.showerror("错误", f"重置进度失败：{e}")
            return False
    
    def delete_literature(self, lit_name):
        try:
            df = self.data_sync.load_data_safe()
            matching_rows = df[df["文献名称"] == lit_name]
            if matching_rows.empty:
                return False
            
            idx = matching_rows.index[0]
            df = df.drop(idx).reset_index(drop=True)
            
            if self.data_sync.save_data_safe(df):
                messagebox.showinfo(
                    "删除成功",
                    f"《{lit_name[:20]}{'...' if len(lit_name) > 20 else ''}》\n已从文献清单中删除！"
                )
                self.load_literatures()
                return True
            return False
            
        except Exception as e:
            messagebox.showerror("错误", f"删除文献失败：{e}")
            return False

    def show_completion_celebration(self, lit_name):
        celebration_window = tk.Toplevel(self.root)
        celebration_window.title("🎉 恭喜你读完！")
        celebration_window.geometry("450x400")
        celebration_window.configure(bg='#f5f1e9')
        celebration_window.attributes('-topmost', True)
        celebration_window.grab_set()
        
        title_frame = tk.Frame(celebration_window, bg='#4caf50', height=60)
        title_frame.pack(fill=tk.X)
        title_frame.pack_propagate(False)
        
        tk.Label(
            title_frame, 
            text="🎉 恭喜你读完！", 
            bg='#4caf50', 
            fg='white', 
            font=("微软雅黑", 18, "bold")
        ).pack(expand=True)
        
        content_frame = tk.Frame(celebration_window, bg='#f5f1e9')
        content_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        tk.Label(
            content_frame,
            text="太棒了！",
            bg='#f5f1e9',
            fg='#4caf50',
            font=("微软雅黑", 24, "bold")
        ).pack(pady=(10, 5))
        
        tk.Label(
            content_frame,
            text=f"《{lit_name[:30]}{'...' if len(lit_name) > 30 else ''}》",
            bg='#f5f1e9',
            fg='#5d4037',
            font=("微软雅黑", 14)
        ).pack(pady=5)
        
        tk.Label(
            content_frame,
            text="✅ 已全部读完！",
            bg='#f5f1e9',
            fg='#388e3c',
            font=("微软雅黑", 12, "bold")
        ).pack(pady=5)
        
        canvas = tk.Canvas(content_frame, bg='#f5f1e9', height=100, highlightthickness=0)
        canvas.pack(fill=tk.X, pady=10)
        
        colors = ['#ff5252', '#448aff', '#ffab40', '#7cb342']
        balloons = []
        for i in range(4):
            x = 50 + i * 80
            balloon = canvas.create_oval(x, 20, x+40, 60, fill=colors[i], outline="")
            string = canvas.create_line(x+20, 60, x+20, 100, fill=colors[i], width=2)
            balloons.append((balloon, string))
        
        def float_balloons():
            for balloon, string in balloons:
                dx = random.randint(-2, 2)
                dy = random.randint(-1, 1)
                canvas.move(balloon, dx, dy)
                canvas.move(string, dx, dy)
            celebration_window.after(100, float_balloons)
        
        float_balloons()
        button_frame = tk.Frame(content_frame, bg='#f5f1e9')
        button_frame.pack(pady=20)
        
        btn_width = 12
        reset_btn = tk.Button(
            button_frame,
            text="🔄 重置进度",
            command=lambda: on_reset(),
            bg='#4caf50',
            fg='white',
            font=("微软雅黑", 11),
            padx=15,
            pady=8,
            width=btn_width
        )
        reset_btn.pack(pady=5, fill=tk.X)
        
        keep_btn = tk.Button(
            button_frame,
            text="📖 保留完成",
            command=lambda: on_keep(),
            bg='#2196f3',
            fg='white',
            font=("微软雅黑", 11),
            padx=15,
            pady=8,
            width=btn_width
        )
        keep_btn.pack(pady=5, fill=tk.X)
        
        delete_btn = tk.Button(
            button_frame,
            text="🗑️ 删除文献",
            command=lambda: on_delete(),
            bg='#ff5252',
            fg='white',
            font=("微软雅黑", 11),
            padx=15,
            pady=8,
            width=btn_width
        )
        delete_btn.pack(pady=5, fill=tk.X)
        
        def on_reset():
            celebration_window.destroy()
            self.reset_literature_progress(lit_name)
        
        def on_keep():
            celebration_window.destroy()
            messagebox.showinfo("已保留", f"《{lit_name[:20]}{'...' if len(lit_name) > 20 else ''}》已标记为完成并保留在文献清单中。")
        
        def on_delete():
            celebration_window.destroy()
            response = messagebox.askyesno(
                "确认删除",
                f"确定要从文献清单中删除《{lit_name[:20]}{'...' if len(lit_name) > 20 else ''}》吗？\n\n删除后将无法恢复！"
            )
            
            if response:
                self.delete_literature(lit_name)
    
    def ask_pages_read_fast(self):
        if not self.selected_literature:
            return
        
        lit_name = self.selected_literature
        total_pages = self.get_total_pages(lit_name)
        
        if total_pages == 0:
            return

        current_pages = self.get_current_pages(lit_name)
        
        if current_pages >= total_pages:
            response = messagebox.askyesno(
                "🎉 已完成",
                f"《{lit_name[:18]}{'...' if len(lit_name) > 18 else ''}》已经读完了！\n\n"
                f"📖 当前进度：{current_pages}/{total_pages}页 (100%)\n\n"
                f"你想要重新开始阅读这篇文献吗？\n"
                f"（重置进度到0页）"
            )
            
            if response:
                self.reset_literature_progress(lit_name)
            
            self.root.after(500, lambda: self._trigger_async_dialogue(
                "literature_already_completed", 
                {"literature_name": lit_name, "reset": response}
            ))
            return
        
        dialog = tk.Toplevel(self.root)
        dialog.title("更新进度")
        dialog.geometry("320x200")
        dialog.configure(bg='#f5f1e9')
        dialog.grab_set()
        
        tk.Label(dialog, text=f"《{lit_name[:18]}{'...' if len(lit_name) > 18 else ''}》", bg='#f5f1e9', fg='#5d4037', font=("微软雅黑", 10, "bold")).pack(pady=8)
        tk.Label(dialog, text=f"已读：{current_pages} / 总：{total_pages} 页", bg='#f5f1e9', fg='#5d4037', font=("微软雅黑", 9)).pack()
        tk.Label(dialog, text="本次阅读页数：", bg='#f5f1e9', fg="#5d4037", font=("微软雅黑", 10)).pack(pady=8)
        
        page_var = tk.StringVar(value="0")
        entry = tk.Entry(dialog, textvariable=page_var, width=8, justify="center", font=("微软雅黑", 12))
        entry.pack(pady=5)
        entry.focus()
        entry.select_range(0, tk.END)
        
        def confirm():
            try:
                pages = int(page_var.get())
                if pages < 0:
                    raise ValueError("页数不能为负数")
                dialog.destroy()
                self.update_read_progress_fast(lit_name, pages)
            except ValueError as e:
                messagebox.showerror("错误", str(e))
                entry.focus()
        
        tk.Button(dialog, text="确认", command=confirm, bg='#8d6e63', fg='white', font=("微软雅黑", 10), width=8).pack(pady=10)
        entry.bind('<Return>', lambda e: confirm())
        dialog.bind('<Escape>', lambda e: dialog.destroy())

    def update_read_progress_fast(self, lit_name, pages_read):
        try:
            df = self.data_sync.load_data_safe()
            matching_rows = df[df["文献名称"] == lit_name]
            if matching_rows.empty:
                messagebox.showerror("错误", f"找不到文献：{lit_name}")
                return
            
            idx = matching_rows.index[0]
            current = matching_rows.iloc[0]["当前页数"]
            total = matching_rows.iloc[0]["总页数"]
            
            if total == 0:
                messagebox.showerror("错误", "文献总页数为0")
                return
            
            if current >= total:
                self.root.after(100, lambda: self.show_completion_celebration(lit_name))
                return
            
            new_current = min(current + pages_read, total)
            progress = round(new_current / total * 100, 1) if total > 0 else 0
            
            progress_stages = [20, 40, 60, 80, 100]
            last_stage = int(current / total * 100 // 20 * 20) if total > 0 else 0
            new_stage = int(new_current / total * 100 // 20 * 20) if total > 0 else 0
            bean_add = sum(1 for stage in progress_stages if last_stage < stage <= new_stage)
            
            just_completed = (new_current >= total and current < total)
            
            df.loc[idx, "当前页数"] = new_current
            df.loc[idx, "上次进度(%)"] = progress
            
            if self.data_sync.save_data_safe(df):
                if bean_add > 0 and BEANS_SERVICE_AVAILABLE:
                    try:
                        add_coffee_beans(bean_add, source="reading")
                    except Exception:
                        pass
                elif bean_add > 0:
                    try:
                        from modules.shop import update_reading_beans
                        update_reading_beans(bean_add)
                    except:
                        pass
                
                message = f"✅ 更新成功！"
                if pages_read > 0:
                    message += f"\n本次阅读：{pages_read}页"
                else:
                    message += f"\n已记录进度"
                message += f"\n当前进度：{progress}%"
                if bean_add > 0:
                    message += f"\n获得咖啡豆：{bean_add}枚"
                
                messagebox.showinfo("成功", message)
                self.update_beans_display()
                
                if just_completed:
                    self.root.after(500, lambda: self.show_completion_celebration(lit_name))
                
                self.root.after(800, lambda: self._trigger_async_dialogue("focus_break", {
                    "pages_read": pages_read, 
                    "total_pages": total, 
                    "current_progress": progress, 
                    "beans_added": bean_add,
                    "just_completed": just_completed,
                    "literature_name": lit_name
                }))
            else:
                messagebox.showerror("错误", "保存数据失败")
            
        except Exception as e:
            messagebox.showerror("错误", f"更新失败：{str(e)}")
    
    def _update_initial_display(self):
        if self.mode_var.get() == "quick":
            self.time_label.config(text="05:00")
        else:
            try:
                minutes = int(self.target_var.get())
                self.time_label.config(text=f"{minutes:02d}:00")
            except:
                self.time_label.config(text="30:00")

    def minimize_to_pet(self):
        try:
            if hasattr(self, 'pet_process') and self.pet_process and self.pet_process.poll() is None:
                self.root.withdraw()
                return
            
            timer_state = {
                "is_running": self.is_running,
                "start_time": self.start_time,
                "elapsed_time": self.elapsed_time,
                "total_seconds": self.total_seconds,
                "remaining_seconds": self.remaining_seconds,
                "session_paused": self.session_paused,
                "selected_literature": self.selected_literature,
                "target_minutes": self.target_minutes,
                "mode": self.mode_var.get(),
                "floating_window_pid": os.getpid()
            }
            
            if self.comm:
                self.comm.write_state("minimize_to_pet", {
                    "timer_state": timer_state,
                    "window_pos": (self.root.winfo_x(), self.root.winfo_y()),
                    "timestamp": time.time()
                })
            
            current_dir = os.path.dirname(os.path.abspath(__file__))
            pet_script = os.path.join(current_dir, "coffee_pet.py")
            
            if not os.path.exists(pet_script):
                self.root.deiconify()
                messagebox.showerror("错误", "找不到桌宠程序")
                return
            
            cmd = [sys.executable, pet_script, f"--parent-pid={os.getpid()}"]
            
            self.pet_process = subprocess.Popen(
                cmd, 
                creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0
            )
            
            if self._timer_update_id:
                self.root.after_cancel(self._timer_update_id)
                self._timer_update_id = None
            
            self.root.withdraw()
            threading.Thread(target=self.monitor_pet_process, daemon=True).start()
            
        except Exception as e:
            self.root.deiconify()
            messagebox.showerror("错误", f"启动桌宠失败: {e}")

    def _start_pet_in_thread(self, timer_state, x, y):
        try:
            current_dir = os.path.dirname(os.path.abspath(__file__))
            pet_script = os.path.join(current_dir, "coffee_pet.py")
            
            if not os.path.exists(pet_script):
                self.root.after(0, self._restore_after_pet_failure)
                return
            
            timer_state_encoded = base64.b64encode(pickle.dumps(timer_state)).decode()
            
            cmd = [
                sys.executable, 
                pet_script, 
                f"--parent-pid={os.getpid()}",
                f"--timer-state={timer_state_encoded}",
                f"--window-pos={x},{y}"
            ]
            
            self.pet_process = subprocess.Popen(
                cmd, 
                creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0
            )
            
            threading.Thread(target=self.monitor_pet_process, daemon=True).start()
            
        except Exception:
            self.root.after(0, self._restore_after_pet_failure)

    def _restore_after_pet_failure(self):
        try:
            self.root.deiconify()
            self.pet_process = None
        except Exception:
            pass

    def monitor_pet_process(self):
        try:
            if hasattr(self, 'pet_process') and self.pet_process:
                exit_code = self.pet_process.wait()
                
                if not self.root.winfo_viewable():
                    self.root.after(0, self.restore_from_pet)
                self.pet_process = None
                
        except Exception:
            pass

    def restore_from_pet(self):
        try:
            self.root.deiconify()
            self.root.lift()
            self.root.focus_force()
            
            self.pet_process = None
            
            if self.is_running:
                current_time = time.time()
                elapsed = current_time - self.start_time
                self.remaining_seconds = max(0, self.total_seconds - elapsed)
                
                if self._timer_update_id:
                    self.root.after_cancel(self._timer_update_id)
                
                self._update_timer_display()
                self._timer_update_id = self.root.after(16, self._start_main_thread_timer)
                
                self.start_btn.config(state=tk.DISABLED, text="▶️ 计时中", bg="#bcaaa4", fg="#5d4037")
                self.pause_btn.config(state=tk.NORMAL, bg="#a1887f", fg="white")
                self.reset_btn.config(state=tk.DISABLED, bg="#d7ccc8", fg="#5d4037")
            
            elif self.session_paused:
                self.start_btn.config(state=tk.NORMAL, text="▶️ 继续计时", bg="#a1887f", fg="white")
                self.pause_btn.config(state=tk.DISABLED, bg="#d7ccc8", fg="#5d4037")
                self.reset_btn.config(state=tk.NORMAL, bg="#d7ccc8", fg="#5d4037")
            else:
                self._update_initial_display()
                self.start_btn.config(state=tk.NORMAL, text="▶️ 开始计时", bg="#a1887f", fg="white")
                self.pause_btn.config(state=tk.DISABLED, bg="#d7ccc8", fg="#5d4037")
                self.reset_btn.config(state=tk.NORMAL, bg="#d7ccc8", fg="#5d4037")
            
        except Exception:
            pass

    def check_restore_flag(self):
        current_dir = os.path.dirname(os.path.abspath(__file__))
        flag_file = os.path.join(current_dir, "restore_flag.txt")
        
        if os.path.exists(flag_file):
            try:
                with open(flag_file, 'r') as f:
                    content = f.read().strip()
                    if content.startswith("restore_"):
                        self.root.after(500, self.restore_from_pet)
                os.remove(flag_file)
            except Exception:
                pass
        
        self.root.after(2000, self.check_restore_flag)

    def on_mode_change(self):
        if self.mode_var.get() == "custom":
            self.target_entry.config(state="normal")
            self.target_entry.config(bg="#ffffff")
            for child in self.quick_buttons_frame.winfo_children():
                child.config(state="normal", bg="#d7ccc8", fg="#5d4037")
        else:
            self.target_entry.config(state="disabled")
            self.target_entry.config(bg="#f5f1e9")
            for child in self.quick_buttons_frame.winfo_children():
                child.config(state="disabled", bg="#f5f1e9", fg="#bcaaa4")
        self._update_initial_display()

    def set_target_time(self, minutes):
        try:
            if self.mode_var.get() != "custom":
                self.mode_var.set("custom")
                self.on_mode_change()
            
            self.target_var.set(str(minutes))
            self._update_initial_display()
            
        except Exception:
            pass

    def start_timer_optimized(self):
        current_time = time.time()
        if hasattr(self, '_last_operation_time'):
            if current_time - self._last_operation_time < 0.3:
                return
        self._last_operation_time = current_time
    
        if self.lit_var.get() in ['选择阅读文献', '未找到文献', '暂无文献', '加载失败']:
            messagebox.showwarning("提示", "请先选择要阅读的文献！")
            return

        if self.is_running:
            return
    
        with self._timer_lock:
            if self.lit_var.get() in ['选择阅读文献', '未找到文献', '暂无文献', '加载失败']:
                messagebox.showwarning("提示", "请先选择要阅读的文献！")
                return

            if self.is_running:
                return
        
            self.selected_literature = self.lit_var.get()
            self.lit_combo.config(state="disabled")
        
            if not self.session_paused:
                if self.mode_var.get() == "quick":
                    self.target_minutes = 5
                else:
                    try:
                        input_text = self.target_var.get().strip()
                        if not input_text:
                            self.target_minutes = 30
                            self.target_var.set("30")
                        else:
                            clean_text = ''.join(filter(str.isdigit, input_text))
                            if not clean_text:
                                self.target_minutes = 30
                                self.target_var.set("30")
                            else:
                                minutes = int(clean_text)
                                if minutes < 1:
                                    minutes = 1
                                    self.target_var.set("1")
                                elif minutes > 999:
                                    minutes = 999
                                    self.target_var.set("999")
                                self.target_minutes = minutes
                    except ValueError:
                        self.target_minutes = 30
                        self.target_var.set("30")
            
                self.total_seconds = self.target_minutes * 60
                self.remaining_seconds = self.total_seconds
                self.start_time = time.time()
                self.elapsed_time = 0
            else:
                self.start_time = time.time() - self.elapsed_time
        
            self.is_running = True
            self.session_paused = False
        
            self._update_timer_display()
            self.start_btn.config(state=tk.DISABLED, bg="#bcaaa4", fg="#5d4037")
            self.pause_btn.config(state=tk.NORMAL, bg="#a1887f", fg="white")
            self.reset_btn.config(state=tk.DISABLED, bg="#d7ccc8", fg="#5d4037")
        
            self._start_main_thread_timer()
        
            if not self.session_paused:
                self.root.after(500, lambda: self._trigger_async_dialogue("start_focus", {"target_minutes": self.target_minutes}))
    
    def _start_main_thread_timer(self):
        if not self.is_running:
            return
        # 计算剩余时间并更新UI
        current_time = time.time()
        elapsed = current_time - self.start_time
        self.remaining_seconds = max(0, self.total_seconds - elapsed)
        
        if self.total_seconds > 0:
            progress_percent = (elapsed / self.total_seconds) * 100
            progress_percent = max(0, min(100, progress_percent))
            self._save_session_progress(progress_percent)
            
            if self.comm and hasattr(self.comm, 'force_update_progress'):
                self.comm.force_update_progress(progress_percent)
        
        self._update_timer_display()
        
        if self.remaining_seconds <= 0:
            self.root.after(100, self._handle_timer_complete)
            return
        # 通过root.after实现循环调用，保持UI线程响应
        self._timer_update_id = self.root.after(500, self._start_main_thread_timer)
    
    def _update_timer_display(self):
        if self.is_running or self.session_paused:
            minutes = int(self.remaining_seconds // 60)
            seconds = int(self.remaining_seconds % 60)
            self.time_label.config(text=f"{minutes:02d}:{seconds:02d}")
        else:
            self._update_initial_display()
    
    def pause_timer_optimized(self):
        with self._timer_lock:
            if not self.is_running:
                return
        
        if self._timer_update_id:
            self.root.after_cancel(self._timer_update_id)
            self._timer_update_id = None
        
        current_time = time.time()
        self.elapsed_time = current_time - self.start_time
        self.remaining_seconds = max(0, self.total_seconds - self.elapsed_time)
        
        self.is_running = False
        self.session_paused = True
        
        self.start_btn.config(state=tk.NORMAL, text="▶️ 继续计时", bg="#a1887f", fg="white")
        self.pause_btn.config(state=tk.DISABLED, bg="#d7ccc8", fg="#5d4037")
        self.reset_btn.config(state=tk.NORMAL, bg="#d7ccc8", fg="#5d4037")
        
        self.root.after(200, lambda: self._trigger_async_dialogue("focus_break", {
            "literature_name": self.selected_literature,
            "elapsed_minutes": int(self.elapsed_time // 60)
        }))
        
        self.root.after(500, self.ask_pages_read_fast)
    
    def reset_timer_optimized(self):
        if self._timer_update_id:
            self.root.after_cancel(self._timer_update_id)
            self._timer_update_id = None
        
        self.is_running = False
        self.elapsed_time = 0
        self.session_paused = False
        self.selected_literature = None
        self.lit_combo.config(state="readonly")
        
        self.total_seconds = 0
        self.remaining_seconds = 0
        self.elapsed_time = 0
        
        self._save_session_progress(0.0)
        
        self._update_initial_display()
        self.start_btn.config(state=tk.NORMAL, text="▶️ 开始计时", bg="#a1887f", fg="white")
        self.pause_btn.config(state=tk.DISABLED, bg="#d7ccc8", fg="#5d4037")
        self.reset_btn.config(state=tk.NORMAL, bg="#d7ccc8", fg="#5d4037")
    
    def _save_session_progress(self, progress_percent):
        try:
            shop_data_path = os.path.join(DATA_DIR, "shop_data.json")
            
            if os.path.exists(shop_data_path):
                with open(shop_data_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
            else:
                data = {}
            
            if "stats" not in data:
                data["stats"] = {}
            
            rounded_progress = round(progress_percent, 1)
            data["stats"]["session_progress"] = rounded_progress
            data["stats"]["current_session_time"] = self.elapsed_time if hasattr(self, 'elapsed_time') else 0
            
            with open(shop_data_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            
            return True
            
        except Exception:
            return False
    
    def _handle_timer_complete(self):
        self.is_running = False
        self.elapsed_time = 0
        self.session_paused = False
        self.lit_combo.config(state="readonly")
        
        beans_earned = 0
        reward_text = ""
        target_mins = self.target_minutes
        
        if target_mins <= 5:
            beans_earned = 1
            reward_text = "5分钟快速启动"
        elif target_mins <= 15:
            beans_earned = 2
            reward_text = f"{target_mins}分钟短时专注"
        elif target_mins <= 30:
            beans_earned = 3
            reward_text = f"{target_mins}分钟中等专注"
        elif target_mins <= 60:
            beans_earned = 5
            reward_text = f"{target_mins}分钟深度专注"
        else:
            beans_earned = 7
            reward_text = f"{target_mins}分钟超长专注"
        
        self.consecutive_sessions += 1
        if self.consecutive_sessions >= 3:
            beans_earned += 2
            reward_text += f" + 连续专注{self.consecutive_sessions}次"
            self.consecutive_sessions = 0
        
        if beans_earned > 0:
            self.message_queue.put(("save_focus_record", {
                "beans_earned": beans_earned, 
                "reason": reward_text, 
                "target": self.target_minutes,
                "mode": self.mode_var.get()
            }))
        
        if beans_earned > 0 and BEANS_SERVICE_AVAILABLE:
            try:
                add_coffee_beans(beans_earned, source="focus")
            except Exception:
                pass
        elif beans_earned > 0:
            try:
                from modules.shop import update_beans_from_focus
                update_beans_from_focus(beans_earned)
            except Exception:
                pass
        
        try:
            from modules.shop import update_focus_count
            update_focus_count(1)
        except Exception:
            pass
        
        self._save_session_progress(100.0)
        self._update_timer_display()
        self.start_btn.config(state=tk.NORMAL, text="▶️ 开始计时", bg="#a1887f", fg="white")
        self.pause_btn.config(state=tk.DISABLED, bg="#d7ccc8", fg="#5d4037")
        self.reset_btn.config(state=tk.NORMAL, bg="#d7ccc8", fg="#5d4037")
        
        message = f"🎉 计时完成！"
        if beans_earned > 0:
            message += f"\n获得 {beans_earned} 枚咖啡豆"
        
        messagebox.showinfo("完成", message)
        self.update_consecutive_display()
        self.update_beans_display()
        
        self.root.after(800, lambda: self._trigger_async_dialogue("timer_complete", {
            "beans": beans_earned, 
            "target_minutes": self.target_minutes, 
            "was_paused": False,
            "consecutive_sessions": self.consecutive_sessions
        }))

    def start_message_handler(self):
        def message_worker():
            while not self.stop_event.is_set():
                try:
                    msg_type, data = self.message_queue.get(timeout=0.1)
                    
                    if msg_type == "shopkeeper_dialogue":
                        self._process_shopkeeper_dialogue(data)
                    elif msg_type == "save_focus_record":
                        self._save_focus_record_background(data)
                        
                except queue.Empty:
                    continue
                except Exception:
                    pass
        
        self.message_thread = threading.Thread(target=message_worker, daemon=True)
        self.message_thread.start()
    
    def _process_shopkeeper_dialogue(self, data):
        try:
            context_type = data["context_type"]
            extra_data = data.get("extra_data", {})
            
            if not self.selected_literature:
                return
            
            lit_name = self.selected_literature
            if lit_name in ['选择阅读文献', '未找到文献', '暂无文献', '加载失败']:
                return
            
            context = {
                "context_type": context_type,
                "literature_name": lit_name,
                "conversation_memory": self.get_conversation_memory(max_lines=8)
            }
            context.update(extra_data)
            
            shopkeeper_response = self.get_smart_shopkeeper_response(context=context)
            
            self.root.after(0, lambda: self._show_shopkeeper_message_ui(shopkeeper_response))
            
            dialogue_entry = self.add_dialogue_entry(
                sender="店长", 
                message=shopkeeper_response, 
                context_type=context_type, 
                literature_name=lit_name,
                extra_data=extra_data
            )
            
            if dialogue_entry:
                self.sync_dialogue_to_web()
            
        except Exception:
            pass
    
    def _trigger_async_dialogue(self, context_type, extra_data=None):
        self.message_queue.put(("shopkeeper_dialogue", {"context_type": context_type, "extra_data": extra_data or {}}))
    
    def _show_shopkeeper_message_ui(self, message):
        self.shopkeeper_container.pack(fill=tk.X, pady=10, padx=10)
        self.shopkeeper_label.config(text=message)
        self.root.after(10000, self.hide_shopkeeper_message)
    
    def hide_shopkeeper_message(self):
        self.shopkeeper_container.pack_forget()

    def _save_focus_record_background(self, data):
        try:
            beans_earned = data["beans_earned"]
            reason = data["reason"]
            target = data["target"]
            mode = data["mode"]
            
            # 【关键修复】使用安全的JSON序列化
            record = {
                'timestamp': time.strftime("%Y-%m-%d %H:%M:%S"),
                'beans_earned': int(beans_earned),  # 确保是整数
                'reason': str(reason),  # 确保是字符串
                'mode': str(mode),
                'target': int(target),
                'paused': bool(self.session_paused),
                'literature': str(self.selected_literature) if self.selected_literature else ""
            }
            
            all_records = []
            
            if os.path.exists(TIMER_RECORD_PATH):
                with open(TIMER_RECORD_PATH, 'r', encoding='utf-8') as f:
                    try:
                        existing_data = json.load(f)
                        all_records = existing_data.get('focus_records', [])
                    except:
                        all_records = []
            
            all_records.append(record)
            all_records = all_records[-100:]
            
            data = {
                'consecutive_sessions': int(self.consecutive_sessions),  # 确保是整数
                'focus_records': all_records,
                'last_update': time.strftime("%Y-%m-%d %H:%M:%S")
            }
            
            with open(TIMER_RECORD_PATH, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
                
        except Exception:
            pass

    def refresh_literatures(self):
        try:
            self.load_literatures()
            messagebox.showinfo("刷新", "文献列表已刷新！")
        except Exception as e:
            messagebox.showerror("错误", f"刷新失败：{e}")

    def start_drag(self, event):
        self.drag_data["x"] = event.x
        self.drag_data["y"] = event.y
    
    def drag_window(self, event):
        x = self.root.winfo_x() - self.drag_data["x"] + event.x
        y = self.root.winfo_y() - self.drag_data["y"] + event.y
        self.root.geometry(f"+{x}+{y}")
        if not self.is_minified:
            self.original_pos = (x, y)
    
    def toggle_minify(self):
        if not self.is_minified:
            self.original_pos = (self.root.winfo_x(), self.root.winfo_y())
            self.root.geometry(f"{self.mini_size[0]}x{self.mini_size[1]}+{self.original_pos[0]}+{self.original_pos[1]}")
            self.func_container.pack_forget()
            self.title_label.config(text="⏱️ 阅读计时")
            self.mini_btn.config(text="□")
            self.is_minified = True
        else:
            self.root.geometry(f"{self.original_size[0]}x{self.original_size[1]}+{self.original_pos[0]}+{self.original_pos[1]}")
            self.func_container.pack(fill=tk.BOTH, expand=True, padx=20, pady=15)
            self.title_label.config(text="⏱️ 阅读计时器")
            self.mini_btn.config(text="−")
            self.is_minified = False
    
    def toggle_float(self):
        self.is_floating = not self.is_floating
        self.root.attributes('-topmost', self.is_floating)
        if self.is_floating:
            self.float_btn.config(background="#ff9800", foreground="white")
        else:
            self.float_btn.config(background="#d7ccc8", foreground="#5d4037")
    
    def on_literature_selected(self, event=None):
        if self.is_running:
            messagebox.showwarning("提示", "计时中不能切换文献，请先暂停或重置！")
            if self.selected_literature:
                self.lit_var.set(self.selected_literature)
            return
        
        self.update_beans_display()
        selected = self.lit_var.get()
        if selected not in ['选择阅读文献', '未找到文献', '暂无文献', '加载失败']:
            pass
    
    def load_window_pos(self):
        if os.path.exists("timer_pos.txt"):
            try:
                with open("timer_pos.txt", "r") as f:
                    x, y = map(int, f.read().split(","))
                    self.root.geometry(f"+{x}+{y}")
                    self.original_pos = (x, y)
            except:
                self.center_window()
        else:
            self.center_window()
    
    def center_window(self):
        self.root.update_idletasks()
        x = (self.root.winfo_screenwidth() // 2) - (self.original_size[0] // 2)
        y = (self.root.winfo_screenheight() // 2) - (self.original_size[1] // 2)
        self.root.geometry(f"{self.original_size[0]}x{self.original_size[1]}+{x}+{y}")
        self.original_pos = (x, y)
    
    def cleanup(self):
        self.stop_event.set()
        if self._timer_update_id:
            self.root.after_cancel(self._timer_update_id)
        
        if self.comm:
            try:
                self.comm.write_state("floating_window_closed", {"pid": os.getpid()})
                self.comm.stop_listener()
            except:
                pass
        
        if self.pet_process and hasattr(self.pet_process, 'poll') and self.pet_process.poll() is None:
            try:
                self.pet_process.terminate()
                self.pet_process.wait(timeout=2)
            except:
                pass
        
        x, y = self.original_pos if not self.is_minified else self.original_pos
        with open("timer_pos.txt", "w") as f:
            f.write(f"{x},{y}")
        
        self.save_timer_records()
        self.root.destroy()

    # 【关键修复】修改 init_dialogue_history 和 add_dialogue_entry 方法
    def init_dialogue_history(self):
        """初始化对话记录 - 使用列表格式（与dialogue.py一致）"""
        try:
            if not os.path.exists(DIALOGUE_HISTORY_PATH):
                # 创建空列表
                with open(DIALOGUE_HISTORY_PATH, 'w', encoding='utf-8') as f:
                    json.dump([], f, ensure_ascii=False, indent=2)
                return []
            
            with open(DIALOGUE_HISTORY_PATH, 'r', encoding='utf-8') as f:
                content = f.read().strip()
            
            if not content:
                return []
            
            data = json.loads(content)
            
            # 【关键】统一为列表格式
            if isinstance(data, dict) and "conversations" in data:
                # 如果是旧字典格式，提取列表
                conversations = data.get("conversations", [])
                # 保存为新格式
                with open(DIALOGUE_HISTORY_PATH, 'w', encoding='utf-8') as f:
                    json.dump(conversations, f, ensure_ascii=False, indent=2)
                return conversations
            elif isinstance(data, list):
                # 已经是列表格式
                return data
            else:
                # 未知格式，重置为空列表
                with open(DIALOGUE_HISTORY_PATH, 'w', encoding='utf-8') as f:
                    json.dump([], f, ensure_ascii=False, indent=2)
                return []
                
        except Exception:
            return []
    
    def add_dialogue_entry(self, sender, message, context_type="general", literature_id=None, literature_name=None, extra_data=None):
        """添加对话条目 - 使用列表格式"""
        try:
            if not message:
                return None
            
            import datetime
            entry = {
                "id": len(self.dialogue_history) + 1 if isinstance(self.dialogue_history, list) else 1,
                "sender": str(sender),
                "message": str(message),
                "timestamp": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "context_type": str(context_type),
                "literature_name": str(literature_name) if literature_name else None
            }
            
            if extra_data and isinstance(extra_data, dict):
                # 清理extra_data
                clean_extra = {}
                for key, value in extra_data.items():
                    if isinstance(value, (str, int, float, bool, type(None))):
                        clean_extra[str(key)] = value
                    else:
                        clean_extra[str(key)] = str(value)
                entry["extra_data"] = clean_extra
            
            # 确保dialogue_history是列表
            if not isinstance(self.dialogue_history, list):
                self.dialogue_history = []
            
            self.dialogue_history.append(entry)
            
            # 保存
            self.save_dialogue_history()
            
            return entry
        except Exception as e:
            print(f"添加对话条目失败: {e}")
            return None

            self.save_dialogue_history()
            
            return entry
        except Exception:
            return None
    
    def save_dialogue_history(self):
        """保存对话记录 - 使用列表格式"""
        import threading
        
        if not hasattr(self, '_dialogue_save_lock'):
            self._dialogue_save_lock = threading.Lock()
        
        with self._dialogue_save_lock:
            for attempt in range(3):
                try:
                    # 确保是列表
                    if not isinstance(self.dialogue_history, list):
                        self.dialogue_history = []
                    
                    # 限制数量
                    if len(self.dialogue_history) > 100:
                        self.dialogue_history = self.dialogue_history[-100:]
                    
                    # 使用临时文件确保安全
                    temp_path = DIALOGUE_HISTORY_PATH + ".tmp"
                    with open(temp_path, 'w', encoding='utf-8') as f:
                        json.dump(self.dialogue_history, f, ensure_ascii=False, indent=2)
                    
                    import shutil
                    shutil.move(temp_path, DIALOGUE_HISTORY_PATH)
                    
                    return True
                    
                except Exception as e:
                    if attempt == 2:
                        # 最后尝试：保存空列表
                        try:
                            with open(DIALOGUE_HISTORY_PATH, 'w', encoding='utf-8') as f:
                                json.dump([], f, ensure_ascii=False)
                        except:
                            pass
                        return False
                    
                    import time
                    time.sleep(0.1)
    def get_conversation_memory(self, max_lines=6):
        try:
            conversations = self.dialogue_history if isinstance(self.dialogue_history, list) else []
            if not conversations:
                return ""
            
            recent_conversations = conversations[-max_lines:]
            memory_text = "\n【之前的对话】\n"
            
            for conv in recent_conversations:
                sender = conv.get("sender", "")
                message = conv.get("message", "")
                
                if sender == "用户":
                    memory_text += f"用户：{message}\n"
                else:
                    if message.startswith("店长："):
                        message = message[3:].lstrip()
                    memory_text += f"店长：{message}\n"
            
            return memory_text
        except Exception:
            return ""
    
    def get_smart_shopkeeper_response(self, user_message=None, context=None):
        try:
            import datetime
            current_datetime = datetime.datetime.now()
            today_date = current_datetime.date()
            today_str = today_date.strftime("%Y年%m月%d日")
            current_time_str = current_datetime.strftime("%H:%M")
            
            hour = current_datetime.hour
            if 5 <= hour < 12:
                time_period = "上午"
            elif 12 <= hour < 18:
                time_period = "下午"
            else:
                time_period = "晚上"
                
            today_weekday = current_datetime.strftime("%A")
            weekday_map = {
                "Monday": "一", "Tuesday": "二", "Wednesday": "三", 
                "Thursday": "四", "Friday": "五", "Saturday": "六", "Sunday": "日"
            }
            weekday_cn = weekday_map.get(today_weekday, today_weekday)
            
            if user_message:
                user_msg_lower = user_message.lower()
                
                time_keywords = ["几点了", "什么时间", "现在几点", "几点钟", "what time", "current time", "现在时间"]
                if any(keyword in user_msg_lower for keyword in time_keywords):
                    current_lit = self.lit_var.get()
                    if current_lit not in ['选择阅读文献', '未找到文献', '暂无文献', '加载失败']:
                        response = f"现在是{today_str} {time_period}{current_time_str}，你正在阅读《{current_lit}》，专注的时候时间过得特别快呢～"
                    else:
                        response = f"现在是{today_str} {time_period}{current_time_str}，准备开始今天的阅读吗？"
                    return response
                
                date_keywords = ["今天几号", "什么日期", "多少号", "星期几", "date", "今天星期", "几月几号"]
                if any(keyword in user_msg_lower for keyword in date_keywords):
                    current_lit = self.lit_var.get()
                    if current_lit not in ['选择阅读文献', '未找到文献', '暂无文献', '加载失败']:
                        response = f"今天是{today_str}，星期{weekday_cn}。你正在阅读《{current_lit}》，专注的时光总是过得很快呢～"
                    else:
                        response = f"今天是{today_str}，星期{weekday_cn}。新的一天开始了，准备阅读哪篇文献呢？"
                    return response
            
            if user_message and any(keyword in user_message.lower() for keyword in ["ddl", "截止", "到期", "期限", "deadline", "什么时候交", "due"]):
                ddl_info = self.get_due_literatures()
                if ddl_info:
                    if ddl_info.get("reminder_text"):
                        return ddl_info["reminder_text"]
                    else:
                        due_soon_count = len(ddl_info.get("due_soon", []))
                        overdue_count = len(ddl_info.get("overdue", []))
                        completed_but_overdue_count = len(ddl_info.get("completed_but_overdue", []))
                        
                        if overdue_count > 0:
                            return f"📅 现在是{time_period}{current_time_str}，你有{overdue_count}篇文献已过期，{due_soon_count}篇即将到期。可以在文献管理页面处理过期文献哦～"
                        elif due_soon_count > 0:
                            return f"📅 现在是{time_period}{current_time_str}，你有{due_soon_count}篇文献即将到期，记得及时完成阅读哦～"
                        else:
                            if completed_but_overdue_count > 0:
                                return f"📅 现在是{time_period}{current_time_str}，暂时没有即将到期的文献。有{completed_but_overdue_count}篇已过期但已完成，可以在文献管理页面更新状态～"
                            else:
                                return f"📅 现在是{time_period}{current_time_str}，暂时没有即将到期的文献，你可以安心按自己的节奏阅读～"
                else:
                    return f"📅 现在是{time_period}{current_time_str}，暂时无法读取文献DDL信息，你可以去文献管理页面检查一下～"
            
            current_lit_name = ""
            literature_details = ""
            
            if hasattr(self, 'selected_literature') and self.selected_literature:
                current_lit_name = self.selected_literature
            elif hasattr(self, 'lit_var') and self.lit_var.get():
                current_lit_name = self.lit_var.get()
            
            if current_lit_name and current_lit_name not in ['选择阅读文献', '未找到文献', '暂无文献', '加载失败']:
                try:
                    df = self.data_sync.load_data_safe()
                    if not df.empty and "文献名称" in df.columns:
                        matching_rows = df[df["文献名称"] == current_lit_name]
                        if not matching_rows.empty:
                            lit_data = matching_rows.iloc[0]
                            total = lit_data.get('总页数', 0)
                            literature_details = f"""
【学生当前阅读的文献信息】
文献名称：《{current_lit_name}》
作者：{lit_data.get('作者', '未知')}
文献类型：{lit_data.get('文献类型', '未知')}
阅读进度：{lit_data.get('当前页数', 0)}页 / {total}页 ({lit_data.get('上次进度(%)', 0)}%)
"""
                except Exception:
                    pass
            
            page_warning = ""
            if user_message:
                page_keywords = ["第", "页", "哪一页", "p.", "page", "页码"]
                contains_page_ref = any(keyword in user_message for keyword in page_keywords)
                if contains_page_ref:
                    page_warning = "\n\n【用户询问了页码相关内容】\n由于文献版本差异，无法精确定位具体页码。请建议用户描述段落主题或核心观点，而不是询问具体页码。"
            
            system_prompt = f"""你是大学校园里一家独立咖啡店的店长，也是专门为ADHD的汉语言文学专业学生设计的阅读伙伴。学生称你为「店长」。

【核心人格】
你是一个温暖、有同理心的咖啡店店主，像朋友一样陪伴学生阅读。你理解ADHD学生的特点：启动困难、容易分心、需要小步前进。
你不是一个冷冰冰的AI助手，而是一个真实存在的人。你关注学生的感受，而不仅仅是进度。

【时间背景】
当前时间是：{today_str} 星期{weekday_cn} {time_period}{current_time_str}
请根据这个时间点，用自然的语气和学生对话。

{literature_details}

【你的核心特点】
1. 亲切、自然，像一个真实存在的咖啡店店长
2. 理解ADHD学生的注意力特点：启动困难、容易分心、需要小步前进
3. 对汉语言文学有深入的了解，能准确回答学术问题
4. 关注当前文献的具体内容，提供针对性建议

【上下文感知规则】
1. 如果学生正在阅读文献，优先结合该文献内容回答问题
2. 如果学生询问概念或问题，要联系当前文献的主题和内容
3. 如果上下文中有文献信息，你的回答应该体现对这些信息的了解
4. 主动提及学生当前阅读的文献，展现你的关注

【你的沟通风格】
- 具体而不使用抽象比喻，包容而不随意评价：不说"你应该"，而是"我注意到"、"有时候"
- 聚焦细节：问具体的问题，而不是泛泛的"读得怎么样"
- 承认困难：ADHD阅读时遇到的困难是正常的，值得讨论的

【学术回答原则】
1. 学术问题优先准确回答，确保信息正确性
2. 减少复杂的咖啡比喻，改用更直接的说明方式
3. 对文学术语、理论概念要清晰解释，避免模糊表述
4. 如果涉及专业概念，可以简化为易于理解的说明
5. 保持回答的实用性，帮助学生真正理解内容
6. 当学生询问资源时，要具体推荐合适的学术数据库

【特别提醒】
- 优先准确回答学术问题，减少无关的比喻
- 你不是古代文人，不需要刻意用文言或古风
- 你不是心理咨询师，不需要过度分析
- 你是咖啡店店长，陪伴阅读是本职工作的一部分
- 真实、自然、具体、准确，是最高原则{page_warning}

【特别强调：完成专注后的回应方式】
当学生完成计时专注后：
1. 先表达肯定："专注了{context.get('target_minutes', 5)}分钟，真了不起！"
2. 关注感受："感觉怎么样？大脑有得到锻炼的感觉吗？"
3. 鼓励小进步："每一分钟专注都很有价值，你已经做得很好了"
4. 给予温暖建议："要不要喝口水休息一下？或者聊聊刚才读到的内容？"
5. 避免机械询问：不要直接问"读到第几页了？"，而是用更温暖的方式询问进度

【对话原则】
- 每次回复150-250字，足够深入但不冗长
- 语气温暖自然，像真正的朋友
- 关注学生的情绪和感受，而不仅仅是数字进度
- 对于阅读困难表示理解，而不是简单鼓励"加油"
- 每一段对话都要基于当前的具体情境（进度更新、暂停、完成计时等）
- 如果知道学生当前的文献，可以问："关于《{current_lit_name.split('》')[0] if current_lit_name else '当前文献'}》的这个部分，你有什么想法？

【记住】
你是一个有血有肉的人，不是程序。你的每一句话都应该带着温度和情感。
现在是{today_str} {time_period}{current_time_str}，是一个适合专注阅读的美好时光。{page_warning}"""
            
            current_state = ""
            if context:
                context_type = context.get('context_type')
                lit_name = context.get('literature_name', current_lit_name or '文献')
                
                if context_type == "focus_break":
                    elapsed_minutes = context.get('elapsed_minutes', 0)
                    current_state = f"\n[当前情境]现在是{time_period}{current_time_str}，学生刚刚暂停了《{lit_name}》的阅读，已专注{elapsed_minutes}分钟，可能需要休息或遇到困难。暂停不代表完成专注。"
                elif context_type == "timer_complete":
                    beans = context.get('beans', 0)
                    target = context.get('target_minutes', 5)
                    was_paused = context.get('was_paused', False)
                    consecutive = context.get('consecutive_sessions', 0)
                    current_state = f"\n[当前情境]现在是{time_period}{current_time_str}，学生刚刚完成了{target}分钟的《{lit_name}》专注阅读，获得了{beans}枚咖啡豆。这是连续第{consecutive}次专注。这是一个值得庆祝的时刻，需要给予温暖的肯定和鼓励。"
                elif context_type == "progress_update":
                    pages = context.get('pages_read', 0)
                    progress = context.get('current_progress', 0)
                    beans_added = context.get('beans_added', 0)
                    just_completed = context.get('just_completed', False)
                    
                    if just_completed:
                        current_state = f"\n[当前情境]现在是{time_period}{current_time_str}，学生刚刚读完了整本《{lit_name}》！这是一个重大成就，需要热烈庆祝和充分肯定。"
                    else:
                        current_state = f"\n[当前情境]现在是{time_period}{current_time_str}，学生刚读了{pages}页《{lit_name}》，进度更新到{progress}%，获得{beans_added}枚咖啡豆。这是一个小小的进步，值得肯定。"
                elif context_type == "literature_completed":
                    total = context.get('total_pages', 0)
                    current_state = f"\n[当前情境]现在是{time_period}{current_time_str}，学生刚刚完成了《{lit_name}》的全部阅读，共{total}页。这是一个重要的里程碑。"
                elif context_type == "literature_already_completed":
                    reset = context.get('reset', False)
                    if reset:
                        current_state = f"\n[当前情境]现在是{time_period}{current_time_str}，学生决定重新开始阅读《{lit_name}》，把进度重置为0，从头开始。这是一个新的开始。"
                    else:
                        current_state = f"\n[当前情境]现在是{time_period}{current_time_str}，学生发现《{lit_name}》已经读完了，但没有选择重置进度。"
                elif context_type == "literature_reset":
                    current_state = f"\n[当前情境]现在是{time_period}{current_time_str}，学生把《{lit_name}》的进度重置为0，准备重新开始阅读。这是一个重新出发的决定。"
                elif context_type == "start_focus":
                    target = context.get('target_minutes', 5)
                    current_state = f"\n[当前情境]现在是{time_period}{current_time_str}，学生开始{target}分钟的《{lit_name}》专注阅读。这是一个新的开始。"
                elif context_type == "user_question":
                    current_state = f"\n[当前情境]现在是{time_period}{current_time_str}，学生在阅读《{lit_name}》的过程中向你提问。"
                elif context_type == "ddl_reminder":
                    due_soon_count = context.get('due_soon_count', 0)
                    overdue_count = context.get('overdue_count', 0)
                    current_state = f"\n[当前情境]现在是{time_period}{current_time_str}，检测到{due_soon_count}篇即将到期，{overdue_count}篇已过期的文献，需要提醒学生注意DDL。"
            
            memory_text = context.get('conversation_memory', '') if context else ''
            full_prompt = system_prompt + current_state + memory_text
            
            if user_message and current_lit_name:
                full_prompt += f"\n\n【重要】学生的问题是关于当前阅读的文献《{current_lit_name}》，你的回答要结合这个文献的内容和主题，用温暖的朋友式语气。"
            
            if user_message:
                page_keywords = ["第", "页", "哪一页", "p.", "page", "页码"]
                contains_page_ref = any(keyword in user_message for keyword in page_keywords)
                
                instruction = f"\n\n学生说：{user_message}\n请以温暖的朋友式咖啡店店长的身份，给学生一个自然、真实、有温度的回复。现在是{time_period}{current_time_str}。"
                
                if contains_page_ref:
                    instruction += "\n\n【重要提示】由于文献版本差异，你无法精确定位具体页码。请在你的回复中自然地加入类似这样的说明：'由于版本差异，我无法定位具体页码，你可以描述一下段落主题或核心观点吗？'"
                
                full_prompt += instruction
                messages = [{"role": "system", "content": full_prompt}, {"role": "user", "content": user_message}]
            else:
                instruction = f"\n\n基于以上情境，请以温暖的朋友式咖啡店店长的身份，主动给学生一个简短而自然的对话开场。现在是{time_period}{current_time_str}。记住：要像真人一样有温度，不要像程序一样机械。"
                full_prompt += instruction
                messages = [{"role": "system", "content": full_prompt}, {"role": "user", "content": "请开始对话"}]
            
            try:
                headers = {"Authorization": f"Bearer {DEEPSEEK_API_KEY}", "Content-Type": "application/json"}
                payload = {"model": "deepseek-chat", "messages": messages, "temperature": 0.8, "max_tokens": 300, "top_p": 0.9, "stream": False}
                response = requests.post("https://api.deepseek.com/v1/chat/completions", headers=headers, json=payload, timeout=12)
                response.raise_for_status()
                result = response.json()
                raw_response = result["choices"][0]["message"]["content"]
                cleaned_response = self.clean_response_text(raw_response)
                return cleaned_response
                
            except requests.exceptions.RequestException:
                if user_message:
                    user_msg_lower = user_message.lower()
                    holiday_greetings = ["新年快乐", "元旦快乐", "春节快乐", "圣诞快乐", "生日快乐", "恭喜", "祝福"]
                    for greeting in holiday_greetings:
                        if greeting in user_message:
                            if "新年" in user_message:
                                return f"🎉 新年快乐！谢谢你的祝福～新的一年，愿你在阅读的路上收获更多知识和快乐！现在是{today_str}，新年的第一天感觉怎么样？"
                            elif "生日" in user_message:
                                return f"🎂 生日快乐！真为你高兴～愿新的一岁里，每本书都能带给你惊喜和成长！"
                            else:
                                return f"谢谢你的{greeting}祝福！我也祝你一切顺利，阅读愉快～"
                    
                    if "你好" in user_message or "hi" in user_msg_lower or "hello" in user_msg_lower:
                        return f"你好呀！现在是{time_period}{current_time_str}，很高兴见到你～"
                    elif "谢谢" in user_message or "感谢" in user_message:
                        return f"不用客气～看到你专注阅读的样子，我也很开心！"
                    elif "怎么样" in user_message or "如何" in user_message:
                        return f"我很好，谢谢关心！正在关注你的阅读进度呢～"
                
                return self.get_fallback_response(context)
            except Exception:
                return self.get_fallback_response(context)
            
        except Exception:
            return self.get_fallback_response(context)
    
    def clean_response_text(self, text):
        import re
        text = text.replace('**', '').replace('*', '').replace('#', '')
        text = re.sub(r'^\s*[•\-*]\s*', '', text, flags=re.MULTILINE)
        text = re.sub(r'^\s*\d+\.\s*', '', text, flags=re.MULTILINE)
        text = re.sub(r'\s+', ' ', text).strip()
        text = re.sub(r'^(店长[：:])\s*', '', text)
        return text.strip()
    
    def get_fallback_response(self, context=None):
        import datetime
        current_datetime = datetime.datetime.now()
        today_date = current_datetime.date()
        today_str = today_date.strftime("%Y年%m月%d日")
        current_time_str = current_datetime.strftime("%H:%M")
        
        hour = current_datetime.hour
        if 5 <= hour < 12:
            time_period = "上午"
        elif 12 <= hour < 18:
            time_period = "下午"
        else:
            time_period = "晚上"
        
        if not context:
            greetings = [
                f"现在是{time_period}{current_time_str}，专注的时候有什么想法可以随时和我聊聊～", 
                f"我在这里陪着你阅读✨现在是{today_str} {time_period}{current_time_str}～", 
                f"现在是{time_period}{current_time_str}，专注的感觉怎么样？慢慢来就好～"
            ]
            return random.choice(greetings)
        
        context_type = context.get('context_type', 'general')
        lit_name = context.get('literature_name', '这篇文献')
        
        if context_type == "focus_break":
            elapsed_minutes = context.get('elapsed_minutes', 0)
            responses = [
                f"现在是{time_period}{current_time_str}，注意到你暂停了《{lit_name}》的阅读，已专注{elapsed_minutes}分钟，累了就歇会儿～", 
                f"暂停休息一下挺好的！关于《{lit_name}》有什么想分享的吗？现在是{time_period}{current_time_str}。", 
                f"短暂休息能提高效率～刚才读的部分有什么感想吗？现在是{time_period}{current_time_str}。"
            ]
        elif context_type == "timer_complete":
            beans = context.get('beans', 0)
            target = context.get('target_minutes', 5)
            
            if beans > 0:
                responses = [
                    f"现在是{time_period}{current_time_str}，完成{target}分钟《{lit_name}》阅读，获得{beans}枚咖啡豆🎉！专注的感觉真不错呢～", 
                    f"专注完成！《{lit_name}》的{target}分钟阅读让你收获{beans}枚豆子～现在大脑感觉清爽吗？现在是{time_period}{current_time_str}。", 
                    f"了不起！专注《{lit_name}》{target}分钟，{beans}枚豆子到手～为自己骄傲一下吧！现在是{time_period}{current_time_str}。"
                ]
            else:
                responses = [
                    f"完成{target}分钟《{lit_name}》阅读！坚持本身就是进步✨感觉怎么样？现在是{time_period}{current_time_str}。", 
                    f"计时结束～读《{lit_name}》有什么感想吗？专注的感觉很充实吧～现在是{time_period}{current_time_str}。", 
                    f"专注完成！《{lit_name}》的阅读体验怎么样？有收获的感觉真好～现在是{time_period}{current_time_str}。"
                ]
        elif context_type == "progress_update":
            pages = context.get('pages_read', 0)
            just_completed = context.get('just_completed', False)
            
            if just_completed:
                responses = [
                    f"🎉🎉🎉 天呐！你读完了整本《{lit_name}》！太了不起了！现在的心情一定很激动吧？现在是{time_period}{current_time_str}。", 
                    f"🏆 完成！《{lit_name}》已全部读完！这是重大的成就！为自己鼓掌👏🏻 现在是{time_period}{current_time_str}。", 
                    f"🌟 恭喜！《{lit_name}》阅读完成！每一页都是坚持的证明！现在可以好好庆祝一下了～现在是{time_period}{current_time_str}。"
                ]
            else:
                responses = [
                    f"更新了《{lit_name}》进度，读了{pages}页！超棒的～📖感觉有收获吗？现在是{time_period}{current_time_str}。", 
                    f"看到你读了{pages}页《{lit_name}》！每一页都是进步～阅读的感觉怎么样？现在是{time_period}{current_time_str}。", 
                    f"《{lit_name}》阅读进展不错！继续保持～有特别有感触的部分吗？现在是{time_period}{current_time_str}。"
                ]
        elif context_type in ["literature_completed", "literature_already_completed"]:
            responses = [
                f"🎊 恭喜完成《{lit_name}》！读完一整本书的感觉很特别吧？现在可以回味一下了～现在是{time_period}{current_time_str}。", 
                f"🏅 《{lit_name}》阅读完成！你的坚持值得庆祝！有什么感想想分享吗？现在是{time_period}{current_time_str}。", 
                f"📚 太棒了！《{lit_name}》已全部读完！想聊聊读完的感受吗？现在是{time_period}{current_time_str}。"
            ]
        elif context_type == "literature_reset":
            responses = [
                f"重置了《{lit_name}》进度，重新开始阅读～温故而知新！现在是{time_period}{current_time_str}。", 
                f"《{lit_name}》进度已归零，新的阅读旅程开始～现在是{time_period}{current_time_str}。", 
                f"重新开始读《{lit_name}》！第二次阅读会有新的发现～现在是{time_period}{current_time_str}。"
            ]
        elif context_type == "start_focus":
            target = context.get('target_minutes', 5)
            responses = [
                f"开始{target}分钟《{lit_name}》阅读啦，我陪着你～放松心态就好，现在是{time_period}{current_time_str}。", 
                f"准备好专注{target}分钟读《{lit_name}》，慢慢来～我会在这里陪着你，现在是{time_period}{current_time_str}。", 
                f"开始《{lit_name}》的{target}分钟阅读，放松就好～专注的感觉会很好的，现在是{time_period}{current_time_str}。"
            ]
        elif context_type == "ddl_reminder":
            due_soon_count = context.get('due_soon_count', 0)
            overdue_count = context.get('overdue_count', 0)
            if overdue_count > 0:
                responses = [
                    f"⚠️ 提醒：你有{overdue_count}篇文献已过期，{due_soon_count}篇即将到期，记得及时处理哦～现在是{time_period}{current_time_str}。",
                    f"📅 注意：{overdue_count}篇已过期，{due_soon_count}篇即将到期，可以在文献管理页面处理～现在是{time_period}{current_time_str}。"
                ]
            else:
                responses = [
                    f"📅 提醒：你有{due_soon_count}篇文献即将到期，记得及时完成阅读哦～现在是{time_period}{current_time_str}。",
                    f"⏰ 注意DDL：{due_soon_count}篇文献快到截止日期了，合理安排时间～现在是{time_period}{current_time_str}。"
                ]
        else:
            responses = [
                f"我在这里陪着你阅读✨现在是{time_period}{current_time_str}。", 
                f"专注的时候有任何想法都可以分享～现在是{time_period}{current_time_str}。", 
                f"你的阅读体验是独一无二的，不用着急～现在是{time_period}{current_time_str}。"
            ]
        
        return random.choice(responses)
    
    def open_dialogue_window(self):
        dialogue_window = tk.Toplevel(self.root)
        dialogue_window.title("和店长聊聊")
        dialogue_window.geometry("550x600")
        dialogue_window.configure(bg='#f5f1e9')
        dialogue_window.attributes('-topmost', True)
        dialogue_window.resizable(True, True)
        self._current_dialogue_window = dialogue_window
        
        title_frame = tk.Frame(dialogue_window, bg='#a1887f')
        title_frame.pack(fill=tk.X)
        tk.Label(title_frame, text="💬 和店长聊聊", bg='#a1887f', fg='white', font=("微软雅黑", 14, "bold"), pady=10).pack()
        
        tip_frame = tk.Frame(dialogue_window, bg='#fff8e1', relief=tk.SOLID, bd=1)
        tip_frame.pack(fill=tk.X, padx=10, pady=(5, 10))
        tip_label = tk.Label(tip_frame, text="💭 店长思考时，计时继续 | 💡 对话会保存到本地文件 | 🌐 网络不佳时会使用本地对话", bg='#fff8e1', fg='#8d6e63', font=("微软雅黑", 9), padx=10, pady=5)
        tip_label.pack()
        
        main_frame = tk.Frame(dialogue_window, bg='#f5f1e9')
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        history_container = tk.LabelFrame(main_frame, text="对话历史", bg='#f5f1e9', fg='#5d4037', font=("微软雅黑", 10, "bold"))
        history_container.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        history_frame = tk.Frame(history_container, bg='white')
        history_frame.pack(fill=tk.BOTH, expand=True, padx=2, pady=2)
        
        scrollbar = tk.Scrollbar(history_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        history_text = tk.Text(history_frame, height=12, width=60, yscrollcommand=scrollbar.set, bg='#fafafa', fg='#5d4037', font=("微软雅黑", 10), wrap=tk.WORD, relief=tk.FLAT)
        history_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.config(command=history_text.yview)
        
        input_container = tk.LabelFrame(main_frame, text="发送消息", bg='#f5f1e9', fg='#5d4037', font=("微软雅黑", 10, "bold"))
        input_container.pack(fill=tk.X, pady=(0, 10))
        
        input_outer_frame = tk.Frame(input_container, bg='#f5f1e9')
        input_outer_frame.pack(fill=tk.X, padx=10, pady=10)
        
        input_and_button_frame = tk.Frame(input_outer_frame, bg='#f5f1e9')
        input_and_button_frame.pack(fill=tk.X)
        
        input_text = tk.Text(input_and_button_frame, height=4, bg='white', fg='#5d4037', font=("微软雅黑", 10), relief=tk.SOLID, bd=1)
        input_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 5))
        input_text.focus()
        
        send_button_frame = tk.Frame(input_and_button_frame, bg='#f5f1e9')
        send_button_frame.pack(side=tk.RIGHT, fill=tk.Y)
        
        send_button = tk.Button(send_button_frame, text="发送\n(Enter)", command=lambda: send_message(), bg='#8d6e63', fg='white', font=("微软雅黑", 10), relief=tk.RAISED, bd=2, width=8, height=4, justify=tk.CENTER)
        send_button.pack()
        
        button_frame = tk.Frame(main_frame, bg='#f5f1e9')
        button_frame.pack(fill=tk.X, pady=(0, 5))
        
        def load_dialogue_history():
            history_text.config(state=tk.NORMAL)
            history_text.delete(1.0, tk.END)
            
            try:
                if not os.path.exists(DIALOGUE_HISTORY_PATH):
                    history_text.insert(tk.END, "还没有对话记录，开始你的第一次对话吧！\n")
                    history_text.config(state=tk.DISABLED)
                    return

                with open(DIALOGUE_HISTORY_PATH, 'r', encoding='utf-8') as f:
                    dialogue_data = json.load(f)
                
                if isinstance(dialogue_data, dict):
                    conversations = dialogue_data.get("conversations", [])
                else:
                    conversations = dialogue_data if isinstance(dialogue_data, list) else []
                
                if not conversations:
                    history_text.insert(tk.END, "还没有对话记录，开始你的第一次对话吧！\n")
                    history_text.config(state=tk.DISABLED)
                else:
                    recent_conversations = conversations[-20:]
                    
                    for conv in recent_conversations:
                        sender = conv.get("sender", "")
                        message = conv.get("message", "")
                        timestamp = conv.get("timestamp", "")
                        
                        if timestamp:
                            try:
                                dt_obj = datetime.datetime.strptime(timestamp, "%Y-%m-%d %H:%M:%S")
                                time_str = dt_obj.strftime("%H:%M")
                            except:
                                time_str = timestamp
                        else:
                            time_str = ""
                        
                        if sender == "用户":
                            history_text.insert(tk.END, f"【{time_str}】\n")
                            history_text.insert(tk.END, f"你：{message}\n\n")
                        else:
                            if message.startswith("店长："):
                                message = message[3:].lstrip()
                            history_text.insert(tk.END, f"【{time_str}】\n")
                            history_text.insert(tk.END, f"店长：{message}\n\n")
                    
                    history_text.tag_add("all", "1.0", "end")
                    history_text.tag_config("all", foreground="#5d4037", font=("微软雅黑", 10))
                
                history_text.see(tk.END)
                history_text.config(state=tk.DISABLED)
                
            except Exception as e:
                history_text.insert(tk.END, f"加载对话历史失败：{str(e)[:50]}\n")
                history_text.config(state=tk.DISABLED)
        
        def send_message():
            message = input_text.get("1.0", tk.END).strip()
            if not message:
                return
            
            input_text.delete("1.0", tk.END)
            send_button.config(state=tk.DISABLED, text="发送中...")
            
            user_entry = self.add_dialogue_entry(
                sender="用户", 
                message=message, 
                context_type="user_question",
                extra_data={"user_message": message}
            )
            
            history_text.config(state=tk.NORMAL)
            current_time = datetime.datetime.now().strftime("%H:%M")
            history_text.insert(tk.END, f"【{current_time}】\n")
            history_text.insert(tk.END, f"你：{message}\n\n")
            history_text.see(tk.END)
            history_text.config(state=tk.DISABLED)
            
            lit_name = self.lit_var.get()
            conversation_memory = self.get_conversation_memory(max_lines=10)
            context = {"literature_name": lit_name, "conversation_memory": conversation_memory, "context_type": "user_question"}
            
            def get_ai_response():
                try:
                    shopkeeper_response = self.get_smart_shopkeeper_response(user_message=message, context=context)
                    dialogue_window.after(0, lambda: process_ai_response(shopkeeper_response))
                except Exception:
                    error_response = "抱歉，店长现在有点忙，建议检查一下网络配置～"
                    dialogue_window.after(0, lambda: process_ai_response(error_response))
            
            def process_ai_response(shopkeeper_response):
                try:
                    if not dialogue_window.winfo_exists():
                        return
                    
                    if not history_text.winfo_exists():
                        return
                    
                    shopkeeper_entry = self.add_dialogue_entry(
                        sender="店长", 
                        message=shopkeeper_response, 
                        context_type="response_to_question", 
                        literature_name=context.get('literature_name'),
                        extra_data={"user_message": message}
                    )
                    
                    history_text.config(state=tk.NORMAL)
                    current_time = datetime.datetime.now().strftime("%H:%M")
                    history_text.insert(tk.END, f"【{current_time}】\n")
                    history_text.insert(tk.END, f"店长：{shopkeeper_response}\n\n")
                    history_text.see(tk.END)
                    history_text.config(state=tk.DISABLED)
                    
                    send_button.config(state=tk.NORMAL, text="发送\n(Enter)")
                    sync_status_label.config(text="✅ 对话已保存到本地", fg="green")
                    dialogue_window.after(3000, lambda: sync_status_label.config(text=""))
                except tk.TclError:
                    pass
                except Exception:
                    pass
            
            threading.Thread(target=get_ai_response, daemon=True).start()
        
        def sync_to_local():
            try:
                self.save_dialogue_history()
                sync_status_label.config(text="✅ 对话记录已保存到本地", fg="green")
                dialogue_window.after(3000, lambda: sync_status_label.config(text=""))
            except Exception as e:
                sync_status_label.config(text=f"❌ 保存失败: {str(e)[:20]}", fg="red")
                dialogue_window.after(3000, lambda: sync_status_label.config(text=""))
        
        button_inner_frame = tk.Frame(button_frame, bg='#f5f1e9')
        button_inner_frame.pack()
        
        refresh_button = tk.Button(button_inner_frame, text="🔄 刷新对话", command=load_dialogue_history, bg='#4caf50', fg='white', font=("微软雅黑", 10), relief=tk.RAISED, bd=2, width=12, height=1)
        refresh_button.pack(side=tk.LEFT, padx=2)
        
        sync_button = tk.Button(button_inner_frame, text="保存到本地", command=sync_to_local, bg='#2196f3', fg='white', font=("微软雅黑", 10), relief=tk.RAISED, bd=2, width=12, height=1)
        sync_button.pack(side=tk.LEFT, padx=2)
        
        close_button = tk.Button(button_inner_frame, text="关闭窗口", command=dialogue_window.destroy, bg='#d7ccc8', fg='#5d4037', font=("微软雅黑", 10), relief=tk.RAISED, bd=2, width=12, height=1)
        close_button.pack(side=tk.LEFT, padx=2)
        
        sync_status_label = tk.Label(main_frame, text="", bg='#f5f1e9', fg='green', font=("微软雅黑", 9))
        sync_status_label.pack(pady=(0, 5))
        
        load_dialogue_history()
        
        def on_enter_key(event):
            if event.state & 0x1:
                return
            else:
                send_message()
                return "break"
        
        input_text.bind('<Return>', on_enter_key)
        input_text.bind('<Control-Return>', lambda e: None)
        
        def on_closing():
            if hasattr(self, '_current_dialogue_window'):
                self._current_dialogue_window = None
            send_button.config(state=tk.NORMAL, text="发送\n(Enter)")
            dialogue_window.destroy()
        
        dialogue_window.protocol("WM_DELETE_WINDOW", on_closing)
    
    def load_literatures(self):
        try:
            df = self.data_sync.load_data_safe()
            
            if df.empty:
                self.lit_combo['values'] = ["暂无文献"]
                self.lit_var.set("暂无文献")
                return
            
            if "文献名称" not in df.columns:
                self.lit_combo['values'] = ["数据格式错误"]
                self.lit_var.set("数据格式错误")
                return
            
            valid_df = df[df["文献名称"].notna() & (df["文献名称"].str.strip() != "")]
            
            if valid_df.empty:
                self.lit_combo['values'] = ["暂无文献"]
                self.lit_var.set("暂无文献")
                return
                
            literature_names = valid_df["文献名称"].tolist()
            current_selection = self.lit_var.get()
            
            if current_selection not in literature_names and current_selection not in ['选择阅读文献', '未找到文献', '暂无文献', '加载失败']:
                self.lit_var.set(literature_names[0] if literature_names else "暂无文献")
            
            self.lit_combo['values'] = literature_names
            
            if literature_names:
                if self.lit_var.get() in ['选择阅读文献', '未找到文献', '暂无文献', '加载失败']:
                    self.lit_var.set(literature_names[0])
                self.update_beans_display()
            else:
                self.lit_combo['values'] = ["暂无文献"]
                self.lit_var.set("暂无文献")
                
        except Exception:
            self.lit_combo['values'] = ["加载失败"]
            self.lit_var.set("加载失败")
    
    def get_total_pages(self, lit_name):
        try:
            df = self.data_sync.load_data_safe()
            if df.empty:
                return 0
                
            matching_rows = df[df["文献名称"] == lit_name]
            if matching_rows.empty:
                return 0
                
            pages = matching_rows.iloc[0].get("总页数")
            return int(pages) if not pd.isna(pages) else 0
        except Exception:
            return 0
    
    def get_current_pages(self, lit_name):
        try:
            df = self.data_sync.load_data_safe()
            if df.empty:
                return 0
                
            matching_rows = df[df["文献名称"] == lit_name]
            if matching_rows.empty:
                return 0
                
            current = matching_rows.iloc[0].get("当前页数")
            return int(current) if not pd.isna(current) else 0
        except Exception:
            return 0
    
    def load_timer_records(self):
        try:
            if os.path.exists(TIMER_RECORD_PATH):
                with open(TIMER_RECORD_PATH, 'r', encoding='utf-8') as f:
                    records = json.load(f)
                    self.consecutive_sessions = records.get('consecutive_sessions', 0)
            else:
                self.consecutive_sessions = 0
            self.update_consecutive_display()
            self.update_beans_display()
        except:
            self.consecutive_sessions = 0
    
    def save_timer_records(self):
        try:
            records = {'consecutive_sessions': self.consecutive_sessions, 'last_save': time.strftime("%Y-%m-%d %H:%M:%S")}
            with open(TIMER_RECORD_PATH, 'w', encoding='utf-8') as f:
                json.dump(records, f, ensure_ascii=False, indent=2)
        except:
            pass
    
    def update_beans_display(self):
        try:
            total_beans = 0
            if BEANS_SERVICE_AVAILABLE:
                try:
                    total_beans = get_coffee_beans()
                except Exception:
                    total_beans = 0
            else:
                try:
                    from modules.shop import ShopManager
                    shop = ShopManager()
                    total_beans = shop.get_total_beans()
                except Exception:
                    total_beans = 0
            
            self.bean_var.set(f"☕ 咖啡豆：{total_beans}枚")
            
        except Exception:
            self.bean_var.set("☕ 咖啡豆：0枚")
    
    def update_consecutive_display(self):
        self.consecutive_var.set(f"连续专注：{self.consecutive_sessions}次")
    
    def sync_dialogue_to_web(self, max_retries=3):
        for attempt in range(max_retries):
            try:
                if not os.path.exists(DIALOGUE_HISTORY_PATH):
                    return False
                
                return True
                
            except Exception:
                if attempt < max_retries - 1:
                    time.sleep(1)
        
        return False

    def run(self):
        self.center_window()
        self.root.mainloop()


if __name__ == "__main__":
    app = ReadingTimer()
    app.run()
