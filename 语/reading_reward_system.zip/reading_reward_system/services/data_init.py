# services/data_init.py
import json
import pandas as pd
from datetime import datetime
from pathlib import Path

BASE_DIR = Path(__file__).parent.parent
DATA_DIR = BASE_DIR / "data"

def init_data():
    return init_all_data()

def init_all_data():
    """初始化所有数据文件"""
    print("🔄 初始化所有数据文件...")
    
    DATA_DIR.mkdir(exist_ok=True)
    
    init_literature_list()
    init_exchange_records()
    init_timer_records()
    init_dialogue_history()
    init_shop_data()
    
    print("✅ 所有数据文件初始化完成")
    return True

def init_literature_list():
    """初始化文献清单"""
    file_path = DATA_DIR / "文献清单.csv"
    if not file_path.exists():
        df = pd.DataFrame(columns=[
            "文献名称", "作者", "文献类型", "总页数", 
            "当前页数", "咖啡豆数量", "上次进度(%)", "备注", "上次更新"
        ])
        df.to_csv(file_path, index=False, encoding="utf-8-sig")
        print(f"📄 已创建文献清单: {file_path}")
    else:
        print(f"✅ 文献清单已存在: {file_path}")

def init_exchange_records():
    """初始化兑换记录"""
    exchange_path = DATA_DIR / "兑换记录.csv"
    if not exchange_path.exists():
        df = pd.DataFrame(columns=[
            "时间", "奖励名称", "消耗豆子", "物品类型", "备注"
        ])
        df.to_csv(exchange_path, index=False, encoding="utf-8-sig")
        print(f"📄 已创建兑换记录: {exchange_path}")
    else:
        print(f"✅ 兑换记录已存在: {exchange_path}")

def init_timer_records():
    """初始化专注记录"""
    timer_path = DATA_DIR / "timer_records.json"
    if not timer_path.exists():
        with open(timer_path, "w", encoding="utf-8") as f:
            json.dump({
                "focus_records": [],
                "total_focus_beans": 0,
                "consecutive_sessions": 0,
                "last_update": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            }, f, ensure_ascii=False, indent=2)
        print(f"📄 已创建专注记录: {timer_path}")
    else:
        print(f"✅ 专注记录已存在: {timer_path}")

def init_dialogue_history():
    """初始化对话记录"""
    dialogue_path = DATA_DIR / "店长对话记录.json"
    if not dialogue_path.exists():
        with open(dialogue_path, "w", encoding="utf-8") as f:
            json.dump({
                "conversations": [],
                "last_interaction_time": None,
                "total_interactions": 0,
                "user_progress_context": {}
            }, f, ensure_ascii=False, indent=2)
        print(f"📄 已创建对话记录: {dialogue_path}")
    else:
        print(f"✅ 对话记录已存在: {dialogue_path}")

def init_shop_data():
    """初始化商店数据"""
    shop_path = DATA_DIR / "shop_data.json"
    if not shop_path.exists():
        default_data = {
            "equipped": {"background": "none", "coffee": "caramel", "coffee_type": "01"},
            "unlocked": {"backgrounds": ["none"], "coffees": ["caramel"], "barista_level": "普通顾客"},
            "beans": 0, "focus_count": 0, "last_sync": datetime.now().strftime("%Y%m%d-%H%M%S")
        }
        with open(shop_path, "w", encoding="utf-8") as f:
            json.dump(default_data, f, ensure_ascii=False, indent=2)
        print(f"📄 已创建商店数据: {shop_path}")
    else:
        print(f"✅ 商店数据已存在: {shop_path}")

def update_shop_data_from_timer():
    """从专注记录更新商店数据"""
    try:
        shop_path = DATA_DIR / "shop_data.json"
        if not shop_path.exists():
            init_shop_data()
        
        with open(shop_path, "r", encoding="utf-8") as f:
            shop_data = json.load(f)
        
        timer_path = DATA_DIR / "timer_records.json"
        if not timer_path.exists():
            init_timer_records()
        
        with open(timer_path, "r", encoding="utf-8") as f:
            timer_data = json.load(f)
        
        focus_count = len(timer_data.get("focus_records", []))
        focus_beans = timer_data.get("total_focus_beans", 0)
        
        reading_beans = 0
        file_path = DATA_DIR / "文献清单.csv"
        if file_path.exists():
            try:
                df = pd.read_csv(file_path, encoding="utf-8-sig")
                if not df.empty and "咖啡豆数量" in df.columns:
                    reading_beans = int(df["咖啡豆数量"].sum())
            except:
                reading_beans = 0
        
        total_beans = focus_beans + reading_beans
        
        shop_data["beans"] = total_beans
        shop_data["focus_count"] = focus_count
        
        # 更新咖啡师等级
        if focus_count >= 100:
            barista_level = "店长"
        elif focus_count >= 50:
            barista_level = "初级咖啡师"
        elif focus_count >= 30:
            barista_level = "资深爱好者"
        elif focus_count >= 10:
            barista_level = "业余爱好者"
        else:
            barista_level = "普通顾客"
        
        shop_data["unlocked"]["barista_level"] = barista_level
        shop_data["last_sync"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        with open(shop_path, "w", encoding="utf-8") as f:
            json.dump(shop_data, f, ensure_ascii=False, indent=2)
        
        print(f"🔄 商店数据已更新: {focus_count}次专注, {total_beans}枚豆子")
        return True
        
    except Exception as e:
        print(f"❌ 更新商店数据失败: {e}")
        return False

if __name__ == "__main__":
    init_all_data()
