import json
import pandas as pd
from pathlib import Path

DATA_DIR = Path("data")
SHOP_DATA_PATH = DATA_DIR / "shop_data.json"
TIMER_RECORD_PATH = DATA_DIR / "timer_records.json"

def load_shop_data():
    """加载并统一商店数据"""
    if not SHOP_DATA_PATH.exists():
        default_data = {
            "coffee_beans": 0,
            "purchased_items": ["coffee_caramel"],
            "equipped": {
                "background": "bg_none",
                "coffee_pet": "coffee_caramel"
            },
            "achievements": {
                "focus_count": 0,
                "current_barista": "普通顾客",
                "unlocked_baristas": ["普通顾客"]
            },
            "stats": {
                "total_focus_time": 0,
                "total_pages": 0,
                "current_session_time": 0,
                "session_progress": 0.0
            }
        }
        save_shop_data(default_data)
        return default_data
    
    try:
        with open(SHOP_DATA_PATH, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        # 统一咖啡豆字段
        if "coffee_beans" not in data:
            coffee_beans = 0
            
            # 从专注记录获取豆子
            coffee_beans += get_focus_beans_from_timer()
            
            # 从旧字段迁移
            if "beans" in data:
                if "reading_beans" in data["beans"]:
                    coffee_beans += data["beans"]["reading_beans"]
                if "focus_beans" in data["beans"]:
                    coffee_beans += data["beans"]["focus_beans"]
            
            data["coffee_beans"] = coffee_beans
            
            # 清理旧字段
            if "beans" in data:
                old_total = data["beans"].get("total", 0)
                print(f"🔄 已迁移旧豆子数据，旧total值: {old_total}")
            
            save_shop_data(data)
        
        return data
    
    except Exception as e:
        print(f"❌ 加载商店数据失败: {e}")
        return {"coffee_beans": 0}

def save_shop_data(data):
    """保存商店数据"""
    try:
        DATA_DIR.mkdir(exist_ok=True)
        
        with open(SHOP_DATA_PATH, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        return True
    except Exception as e:
        print(f"❌ 保存商店数据失败: {e}")
        return False

def get_focus_beans_from_timer():
    """从专注记录获取豆子"""
    try:
        if TIMER_RECORD_PATH.exists():
            with open(TIMER_RECORD_PATH, 'r', encoding='utf-8') as f:
                data = json.load(f)
                return int(data.get("coffee_beans", data.get("total_focus_beans", 0)))
    except:
        pass
    return 0

def get_coffee_beans() -> int:
    """获取总的咖啡豆数量"""
    try:
        data = load_shop_data()
        return data.get("coffee_beans", 0)
    except Exception as e:
        print(f"❌ 获取咖啡豆失败: {e}")
        return 0

def add_coffee_beans(n=1, source=""):
    """增加咖啡豆
    
    参数:
        n: 增加的豆子数量
        source: 来源说明
    """
    try:
        data = load_shop_data()
        current = data.get("coffee_beans", 0)
        new_total = current + n
        data["coffee_beans"] = new_total
        
        save_shop_data(data)
        
        if source:
            print(f"☕ +{n} 咖啡豆 (来源: {source}) 当前: {new_total}")
        
        return new_total
    
    except Exception as e:
        print(f"❌ 增加咖啡豆失败: {e}")
        return 0

def deduct_coffee_beans(n=1, item_name=""):
    """扣除咖啡豆（用于商店购买）
    
    参数:
        n: 扣除的豆子数量
        item_name: 购买物品名称
    """
    try:
        data = load_shop_data()
        current = data.get("coffee_beans", 0)
        
        if current < n:
            print(f"❌ 咖啡豆不足！需要: {n}, 当前: {current}")
            return False, current
        
        new_total = current - n
        data["coffee_beans"] = new_total
        
        if item_name:
            print(f"💰 购买 {item_name} 扣除 {n} 咖啡豆")
            print(f"   剩余: {new_total}")
        
        save_shop_data(data)
        return True, new_total
    
    except Exception as e:
        print(f"❌ 扣除咖啡豆失败: {e}")
        return False, 0

def get_reading_beans():
    """获取阅读豆（兼容性函数）"""
    print("⚠️ 警告: get_reading_beans() 已废弃，请使用 get_coffee_beans()")
    total = get_coffee_beans()
    return total // 2

def get_focus_beans():
    """获取专注豆（兼容性函数）"""
    print("⚠️ 警告: get_focus_beans() 已废弃，请使用 get_coffee_beans()")
    total = get_coffee_beans()
    return total // 2
