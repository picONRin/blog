import subprocess
import sys
import time
import socket
from pathlib import Path

BASE_DIR = Path(__file__).parent
PYTHON = sys.executable  # 确保用当前Python解释器


def install_packaging():
    """确保packaging包已安装"""
    try:
        import packaging.version
        return True
    except ImportError:
        print("安装 packaging 用于版本检查...")
        result = subprocess.run([PYTHON, "-m", "pip", "install", "packaging"],
                                capture_output=True, timeout=60)
        return result.returncode == 0


def get_python_version():
    """获取Python版本号"""
    return (sys.version_info.major, sys.version_info.minor)


def parse_version(version_str):
    """安全解析版本号"""
    if not version_str or version_str.lower() in ['unknown', 'none', '']:
        return None

    try:
        import packaging.version as ver
        return ver.parse(version_str)
    except:
        import re
        match = re.search(r'(\d+\.\d+(\.\d+)*)', str(version_str))
        if match:
            try:
                import packaging.version as ver
                return ver.parse(match.group(1))
            except:
                pass
        return None


def get_compatible_versions(py_major, py_minor):
    """根据Python版本返回兼容版本"""
    if py_major == 3 and py_minor <= 8:
        return {
            "streamlit": "1.28.0",
            "pandas": "2.1.0",
            "plotly": "5.17.0",
            "pystray": "0.19.0",
            "Pillow": "10.0.0"
        }
    elif py_major == 3 and py_minor <= 11:
        return {
            "streamlit": "1.28.0",
            "pandas": "2.3.2",
            "plotly": "6.3.1",
            "pystray": "0.19.5",
            "Pillow": "10.0.0"
        }
    else:
        return {
            "streamlit": "1.50.0",
            "pandas": "2.3.2",
            "plotly": "6.3.1",
            "pystray": "0.19.5",
            "Pillow": "11.0.0"  # Python 3.12+可以使用更高版本
        }


def get_minimum_versions():
    """返回最低版本要求"""
    return {
        "streamlit": "1.28.0",
        "pandas": "2.0.0",
        "plotly": "5.0.0",
        "pystray": "0.19.0",
        "Pillow": "9.0.0"
    }


def get_installed_version(package_name):
    """安全获取已安装包的版本"""
    try:
        if package_name == "Pillow":
            from PIL import Image
            version = Image.__version__
        elif package_name == "pystray":
            import pystray
            version = getattr(pystray, "__version__", None)
            if version is None:
                try:
                    result = subprocess.run(
                        [PYTHON, "-m", "pip", "show", "pystray"],
                        capture_output=True,
                        text=True,
                        timeout=10
                    )
                    if result.returncode == 0:
                        for line in result.stdout.split('\n'):
                            if line.startswith('Version:'):
                                version = line.split(':', 1)[1].strip()
                                break
                except:
                    pass
        else:
            imported = __import__(package_name)
            version = getattr(imported, "__version__", None)

        return version if version else "unknown"
    except ImportError:
        return None


def compare_versions(current_str, required_str):
    """比较版本"""
    if current_str is None or required_str is None:
        return "unknown"

    current_ver = parse_version(current_str)
    required_ver = parse_version(required_str)

    if current_ver is None or required_ver is None:
        return "unknown"

    if current_ver < required_ver:
        return "too_low"
    elif current_ver == required_ver:
        return "equal"
    else:
        return "higher"


def install_package(package, target_version):
    """安装包"""
    # 尝试不同源
    sources = [
        [],
        ["-i", "https://pypi.tuna.tsinghua.edu.cn/simple"],
        ["-i", "https://mirrors.aliyun.com/pypi/simple/"],
    ]

    for source_args in sources:
        cmd = [PYTHON, "-m", "pip", "install", f"{package}=={target_version}"] + source_args
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)

        if result.returncode == 0:
            return True, ""
        elif "already satisfied" in result.stdout.lower():
            return True, "already_satisfied"

    return False, "安装失败"


def check_pillow_specifically():
    """专门处理Pillow：已安装则不重复安装"""
    try:
        from PIL import Image
        current_version = Image.__version__

        py_major, py_minor = get_python_version()
        target_versions = get_compatible_versions(py_major, py_minor)
        target_version = target_versions["Pillow"]
        min_version = "9.0.0"

        current_ver = parse_version(current_version)
        target_ver = parse_version(target_version)
        min_ver = parse_version(min_version)

        if current_ver is None:
            return "unknown", current_version, target_version

        # 关键修复：已经安装且版本足够高，就不安装
        if current_ver >= min_ver:
            if current_ver < target_ver:
                return "optional", current_version, target_version
            else:
                return "ok", current_version, current_version
        else:
            return "too_low", current_version, target_version

    except ImportError:
        py_major, py_minor = get_python_version()
        target_versions = get_compatible_versions(py_major, py_minor)
        return "not_installed", None, target_versions["Pillow"]


def check_and_install_dependencies():
    """检查并安装依赖（无交互）"""
    print("🔍 自动检查依赖兼容性...")

    # 确保packaging已安装
    install_packaging()

    py_major, py_minor = get_python_version()
    min_versions = get_minimum_versions()
    target_versions = get_compatible_versions(py_major, py_minor)

    packages = ["streamlit", "pandas", "plotly", "pystray", "Pillow"]
    results = []

    for package in packages:
        if package == "Pillow":
            # 特殊处理Pillow
            status, current_version, target_version = check_pillow_specifically()

            if status == "not_installed":
                print(f"   📦 Pillow: 未安装 → {target_version}")
                print(f"      正在安装...", end="", flush=True)
                success, error_msg = install_package("Pillow", target_version)
                if success:
                    print(" ✅")
                    results.append(("Pillow", True, f"安装成功: {target_version}"))
                else:
                    print(f" ❌")
                    results.append(("Pillow", False, f"安装失败"))

            elif status == "too_low":
                print(f"   ⚠️  Pillow: {current_version} → {target_version} (版本过低)")
                print(f"      正在升级...", end="", flush=True)
                success, error_msg = install_package("Pillow", target_version)
                if success:
                    print(" ✅")
                    results.append(("Pillow", True, f"升级到: {target_version}"))
                else:
                    print(f" ❌")
                    results.append(("Pillow", False, f"升级失败"))

            elif status == "optional":
                print(f"   🔄 Pillow: {current_version} → {target_version} (可选升级)")
                print(f"      跳过可选升级，保持当前版本")
                results.append(("Pillow", True, f"保持当前: {current_version}"))

            elif status == "ok":
                print(f"   ✅ Pillow: {current_version} (已满足要求)")
                results.append(("Pillow", True, f"已满足: {current_version}"))

            else:  # unknown
                print(f"   ⚠️  Pillow: 版本信息不明")
                print(f"      保持当前版本")
                results.append(("Pillow", True, f"保持当前"))

        else:
            # 处理其他包
            current_version = get_installed_version(package)
            min_version = min_versions[package]
            target_version = target_versions[package]

            if current_version is None:
                print(f"   📦 {package}: 未安装 → {target_version}")
                print(f"      正在安装...", end="", flush=True)
                success, error_msg = install_package(package, target_version)
                if success:
                    print(" ✅")
                    results.append((package, True, f"安装成功: {target_version}"))
                else:
                    print(f" ❌")
                    results.append((package, False, f"安装失败"))
            else:
                comparison = compare_versions(current_version, min_version)

                if comparison == "unknown":
                    print(f"   ⚠️  {package}: {current_version} (版本信息不明)")
                    print(f"      保持当前版本")
                    results.append((package, True, f"保持当前: {current_version}"))
                elif comparison == "too_low":
                    print(f"   ⚠️  {package}: {current_version} → {target_version} (版本过低)")
                    print(f"      正在升级...", end="", flush=True)
                    success, error_msg = install_package(package, target_version)
                    if success:
                        print(" ✅")
                        results.append((package, True, f"升级到: {target_version}"))
                    else:
                        print(f" ❌")
                        results.append((package, False, f"升级失败"))
                else:
                    if current_version == target_version:
                        print(f"   ✅ {package}: {current_version} (已是最佳版本)")
                        results.append((package, True, f"已是最佳: {current_version}"))
                    else:
                        upgrade_comparison = compare_versions(current_version, target_version)
                        if upgrade_comparison == "too_low":
                            print(f"   🔄 {package}: {current_version} → {target_version} (可选升级)")
                            print(f"      跳过可选升级，保持当前版本")
                            results.append((package, True, f"保持当前: {current_version}"))
                        else:
                            print(f"   ✅ {package}: {current_version} (已满足要求)")
                            results.append((package, True, f"已满足: {current_version}"))

    # 汇总结果
    print("\n📊 依赖检查完成")
    all_success = True
    for package, success, message in results:
        if not success:
            all_success = False
            print(f"   ❌ {package}: {message}")
        else:
            print(f"   ✅ {package}: {message}")

    return all_success


def check_python_compatibility():
    """检查Python版本兼容性"""
    py_major, py_minor = get_python_version()

    print(f"🐍 检测到 Python {py_major}.{py_minor}")

    if py_major < 3 or (py_major == 3 and py_minor < 7):
        print("❌ 错误：需要 Python 3.7 或更高版本")
        print("请从 https://www.python.org/downloads/ 升级")
        return False

    if py_major == 3 and py_minor <= 8:
        print("⚠️  提示：当前为 Python 3.8 或更低，某些功能可能受限")
        print("     建议升级到 Python 3.9+ 以获得更好兼容性")

    return True


def is_port_in_use(port):
    """检测端口是否被占用"""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        return s.connect_ex(('localhost', port)) == 0


def start_services():
    """启动服务（修复Streamlit启动方式+自动换端口）"""
    print("\n🚀 启动系统服务...")

    # 自动检测可用端口（从8501开始）
    port = 8501
    while is_port_in_use(port):
        port += 1
    print(f"   🔍 已选择可用端口: {port}")

    # 启动Web界面（强制用当前Python解释器）
    web_process = None
    try:
        web_process = subprocess.Popen(
            [PYTHON, "-m", "streamlit", "run", "app.py", f"--server.port={port}"],
            cwd=BASE_DIR
        )
        print(f"   ✅ Web界面: http://localhost:{port}")
    except Exception as e:
        print(f"   ❌ Web界面启动失败: {e}")
        return

    # 等待Web界面启动（延长等待时间）
    time.sleep(5)
    print("   ⏳ 等待Web界面加载完成...")

    # 检查Web界面是否正常运行
    if web_process.poll() is not None:
        print("   ❌ Web界面启动后意外退出，请检查app.py代码")
        return

    # 启动悬浮窗（如果Web界面正常）
    try:
        subprocess.Popen(
            [PYTHON, "floating_window.py"],
            cwd=BASE_DIR
        )
        print("   ✅ 悬浮窗已启动")
    except Exception as e:
        print(f"   ❌ 悬浮窗启动失败: {e}")

    print("\n🎉 系统启动完成！")
    print("=" * 50)
    print(f"🌐 访问地址: http://localhost:{port}")
    print("💡 提示：首次启动可能需要10-20秒")
    print("     如果页面空白，请刷新浏览器")
    print("🔧 按 Ctrl+C 退出系统")
    print("=" * 50)


def main():
    print("=" * 60)
    print("汉语言文学ADHD文献阅读激励系统")
    print("=" * 60)

    # 检查Python版本
    if not check_python_compatibility():
        print("\n⚠️  Python版本不兼容，程序退出")
        time.sleep(3)
        sys.exit(1)

    # 自动检查依赖（无跳过选项）
    print("\n" + "=" * 60)
    check_and_install_dependencies()

    # 启动服务
    start_services()

    # 保持运行
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n👋 正在退出系统...")
        sys.exit(0)


if __name__ == "__main__":
    main()