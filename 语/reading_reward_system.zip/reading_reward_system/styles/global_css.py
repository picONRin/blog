import streamlit as st
import base64
from pathlib import Path

# 使用相对路径而不是绝对导入
BACKGROUNDS_DIR = Path(__file__).parent.parent / "assets" / "backgrounds"

def load_global_css():
    """加载全局CSS样式"""
    st.markdown("""
<style>
/* =========================
   隐藏Streamlit无关元素
========================= */
div[data-testid="stToolbar"],
footer[data-testid="stFooter"],
button[kind="secondaryIcon"],
div[data-testid="stDecoration"],
button[kind="header"],
.stTooltipIcon,
[title*="keyboard"], 
[aria-label*="keyboard"],
[data-testid*="keyboard"],
[class*="shortcut"] {
    display: none !important;
}

/* 隐藏默认顶部元素 */
header[data-testid="stHeader"] {
    display: none !important;
    height: 0 !important;
    padding: 0 !important;
    margin: 0 !important;
}

/* =========================
   主页面布局
========================= */
.stApp {
    background-color: #f5f2ed !important;
    background-image: radial-gradient(rgba(0, 0, 0, 0.015) 1px, transparent 1px) !important;
    background-size: 12px 12px !important;
    padding-top: 0 !important;
}

.main .block-container {
    padding-top: 0.2rem !important;
    padding-bottom: 1rem !important;
    max-width: 1000px !important;
}

.main-container {
    max-width: 1000px !important;
    margin: 0 auto !important;
    padding: 10px 20px 20px 20px !important;
    background-color: rgba(255, 255, 255, 0.6) !important;
    border-radius: 10px !important;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.04) !important;
    margin-top: 0 !important;
    padding-top: 5px !important;
}

/* =========================
   标题系统
========================= */
h1 {
    color: #5d4037 !important;
    font-weight: 700 !important;
    font-size: 2.0rem !important;
    text-align: center !important;
    margin: 0 0 5px 0 !important;
    padding-bottom: 8px !important;
    border-bottom: 2px solid #bca89a !important;
    font-family: "STKaiti", "Microsoft YaHei", serif !important;
}

h2 {
    color: #6d4c41 !important;
    font-weight: 600 !important;
    font-size: 1.4rem !important;
    margin: 12px 0 8px 0 !important;
    padding-left: 6px !important;
    border-left: 3px solid #a1887f !important;
    font-family: "STKaiti", "Microsoft YaHei", sans-serif !important;
}

h3 {
    color: #7a5a4d !important;
    font-weight: 600 !important;
    font-size: 1.1rem !important;
    margin: 10px 0 6px 0 !important;
    font-family: "Microsoft YaHei", sans-serif !important;
}

/* =========================
   表单控件
========================= */
.stSelectbox > div > div {
    border: 1px solid #c7bfb8 !important;
    border-radius: 5px !important;
    background-color: #ffffff !important;
    font-size: 13px !important;
    height: 40px !important;
    min-height: 40px !important;
}

.stSelectbox > div > div > div {
    line-height: 38px !important;
    padding: 0 10px !important;
    font-size: 14px !important;
    color: #5d4037 !important;
}

.stTextInput > div > div > input {
    border: 1px solid #c7bfb8 !important;
    border-radius: 5px !important;
    padding: 8px 10px !important;
    font-size: 14px !important;
    background-color: #ffffff !important;
    font-family: "Microsoft YaHei", sans-serif !important;
    width: 100% !important;
    height: 40px !important;
    min-height: 40px !important;
    color: #5d4037 !important;
}

/* 进度页数输入框 */
div[data-testid="stNumberInput"] > div > div > input {
    width: 120px !important;
    min-width: 120px !important;
    max-width: 150px !important;
    text-align: center !important;
}

div[data-testid="stSelectbox"],
div[data-testid="stTextInput"],
div[data-testid="stNumberInput"] {
    margin-bottom: 8px !important;
}

/* 表单标签 */
div[data-testid="stSelectbox"] label,
div[data-testid="stTextInput"] label,
div[data-testid="stNumberInput"] label {
    font-size: 14px !important;
    font-weight: 500 !important;
    color: #5d4037 !important;
    margin-bottom: 3px !important;
    display: block !important;
}

/* =========================
   卡片样式
========================= */
.card,
.music-card {
    background-color: #ffffff !important;
    border-radius: 8px !important;
    padding: 16px 18px !important;
    margin-bottom: 15px !important;
    box-shadow: 0 3px 10px rgba(0, 0, 0, 0.05) !important;
    border: 1px solid #e3ded9 !important;
}

/* =========================
   UI组件颜色覆盖
========================= */
/* 主要按钮 */
.stButton > button[kind="primary"],
.stButton > button[data-testid="baseButton-primary"] {
    background-color: #8d6e63 !important;
    border-color: #8d6e63 !important;
    color: white !important;
    font-weight: 600 !important;
}

/* 次要按钮 */
.stButton > button[kind="secondary"],
.stButton > button[data-testid="baseButton-secondary"] {
    background-color: #d7ccc8 !important;
    border-color: #d7ccc8 !important;
    color: #5d4037 !important;
    font-weight: 500 !important;
}

/* 输入框焦点状态 */
.stTextInput > div > div > input:focus,
.stNumberInput > div > div > input:focus {
    border-color: #8d6e63 !important;
    box-shadow: 0 0 0 2px rgba(141, 110, 99, 0.2) !important;
}

.stSelectbox > div > div:focus-within {
    border-color: #8d6e63 !important;
    box-shadow: 0 0 0 2px rgba(141, 110, 99, 0.2) !important;
}

/* 标签页 */
.stTabs [data-baseweb="tab"][aria-selected="true"] {
    color: #8d6e63 !important;
    border-bottom-color: #8d6e63 !important;
}

/* 指标组件 */
[data-testid="stMetricValue"] {
    color: #5d4037 !important;
}

[data-testid="stMetricLabel"] {
    color: #8c7b72 !important;
}

/* 进度条 */
.stProgress > div > div > div {
    background-color: #8d6e63 !important;
}

/* 表单 */
.stForm {
    border: 1px solid #e3ded9 !important;
    border-radius: 8px !important;
    padding: 15px !important;
    background-color: #f8f4f0 !important;
}

button[kind="primaryFormSubmit"] {
    background-color: #8d6e63 !important;
    color: white !important;
    font-weight: 600 !important;
}

/* =========================
   自定义符号进度条
========================= */
.symbol-progress-container {
    margin: 8px 0 !important;
    padding: 6px 0 !important;
}

.symbol-progress-bar {
    font-family: 'Courier New', 'Monaco', monospace !important;
    font-size: 16px !important;
    letter-spacing: 1px !important;
    line-height: 1.3 !important;
    margin-bottom: 4px !important;
    display: block !important;
}

.symbol-progress-filled {
    color: #8d6e63 !important;
    font-weight: bold !important;
}

.symbol-progress-empty {
    color: #d7ccc8 !important;
}

.symbol-progress-percent {
    color: #6d4c41 !important;
    font-weight: 600 !important;
    font-size: 14px !important;
    margin-left: 8px !important;
}

.symbol-progress-info {
    font-size: 12px !important;
    color: #8c7b72 !important;
    margin-top: 3px !important;
}

/* =========================
   成功提示样式
========================= */
.success-message {
    background-color: #e8f5e9 !important;
    color: #2e7d32 !important;
    padding: 12px 16px !important;
    border-radius: 6px !important;
    border-left: 4px solid #4caf50 !important;
    margin: 10px 0 15px 0 !important;
    font-size: 14px !important;
    opacity: 1 !important;
    animation: fadeInOut 4s ease-in-out forwards !important;
    position: relative !important;
    z-index: 100 !important;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1) !important;
}

@keyframes fadeInOut {
    0% {
        opacity: 0 !important;
        transform: translateY(-5px) !important;
    }
    20% {
        opacity: 1 !important;
        transform: translateY(0) !important;
    }
    80% {
        opacity: 1 !important;
        transform: translateY(0) !important;
    }
    100% {
        opacity: 0 !important;
        transform: translateY(-5px) !important;
        max-height: 0 !important;
        padding: 0 16px !important;
        margin: 0 !important;
        overflow: hidden !important;
    }
}

/* =========================
   标签页
========================= */
.stTabs [data-baseweb="tab-list"] {
    background-color: transparent !important;
    border-bottom: 2px solid #e4dfda !important;
    margin-bottom: 15px !important;
}

.stTabs [data-baseweb="tab"] {
    padding: 10px 18px !important;
    font-weight: 500 !important;
    color: #7a6a60 !important;
    font-size: 14px !important;
    font-family: "Microsoft YaHei", sans-serif !important;
}

.stTabs [data-baseweb="tab"][aria-selected="true"] {
    color: #8d6e63 !important;
    border-bottom: 2px solid #8d6e63 !important;
    font-weight: 600 !important;
}

/* =========================
   数据表格
========================= */
.stDataFrame {
    border: 1px solid #e3ded9 !important;
    border-radius: 6px !important;
    overflow: hidden !important;
    margin-bottom: 15px !important;
}

/* =========================
   对话气泡
========================= */
.chat-bubble-user {
    background-color: #8d6e63 !important;
    color: white !important;
    border-radius: 12px 12px 4px 12px !important;
    padding: 12px 16px !important;
    margin: 8px 0 !important;
    max-width: 85% !important;
    margin-left: auto !important;
    font-family: "Microsoft YaHei", sans-serif !important;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1) !important;
}

.chat-bubble-shopkeeper {
    background-color: #ffffff !important;
    color: #333 !important;
    border-radius: 12px 12px 12px 4px !important;
    padding: 12px 16px !important;
    margin: 8px 0 !important;
    max-width: 85% !important;
    border: 1px solid #e0dbd6 !important;
    font-family: "STKaiti", "Microsoft YaHei", sans-serif !important;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05) !important;
}

.chat-sender {
    font-weight: bold !important;
    font-size: 13px !important;
    font-family: "Microsoft YaHei", sans-serif !important;
    margin-bottom: 4px !important;
}

.chat-message {
    font-size: 15px !important;
    line-height: 1.5 !important;
    font-family: inherit !important;
}

.chat-time {
    font-size: 11px !important;
    color: #9e9e9e !important;
    text-align: right !important;
    margin-top: 4px !important;
    font-family: "Microsoft YaHei", sans-serif !important;
}

.dialogue-history-container {
    background-color: #f9f7f3 !important;
    border-radius: 10px !important;
    padding: 20px !important;
    margin-bottom: 20px !important;
    border: 1px solid #e3ded9 !important;
}

/* =========================
   紧凑布局
========================= */
.compact-row {
    display: flex !important;
    align-items: center !important;
    gap: 10px !important;
    margin: 5px 0 !important;
    flex-wrap: wrap !important;
}

.compact-item {
    flex: 0 0 auto !important;
}

/* =========================
   文献卡片
========================= */
.literature-card {
    background: white !important;
    border-radius: 6px !important;
    padding: 12px !important;
    margin: 8px 0 !important;
    border: 1px solid #e3ded9 !important;
    box-shadow: 0 2px 4px rgba(0,0,0,0.03) !important;
}

.literature-title {
    color: #5d4037 !important;
    font-size: 15px !important;
    font-weight: 600 !important;
    margin-bottom: 4px !important;
}

.literature-meta {
    color: #8c7b72 !important;
    font-size: 12px !important;
    margin-bottom: 6px !important;
}

/* =========================
   指标显示
========================= */
.stMetric {
    background-color: #f8f4f0 !important;
    border: 1px solid #e3ded9 !important;
    border-radius: 6px !important;
    padding: 12px !important;
    text-align: center !important;
}

/* =========================
   页脚
========================= */
.footer {
    text-align: center !important;
    color: #8c7b72 !important;
    font-size: 12px !important;
    padding: 15px 0 5px 0 !important;
    border-top: 1px solid #e3ded9 !important;
    margin-top: 20px !important;
}

/* =========================
   分隔线
========================= */
hr {
    border: none !important;
    border-top: 1px solid #e3ded9 !important;
    margin: 20px 0 !important;
}

/* =========================
   副标题
========================= */
.caption {
    color: #8c7b72 !important;
    font-size: 14px !important;
    text-align: center !important;
    margin-bottom: 20px !important;
    font-family: "Microsoft YaHei", sans-serif !important;
}

/* =========================
   折叠框
========================= */
.stExpander {
    margin-top: 15px !important;
}

div[data-testid="stExpander"] > div:nth-child(2) {
    padding-top: 10px !important;
    padding-bottom: 10px !important;
}

/* =========================
   按钮
========================= */
.stButton > button {
    margin-bottom: 8px !important;
    transition: all 0.2s ease !important;
}

/* =========================
   图表容器
========================= */
.js-plotly-plot {
    border-radius: 8px !important;
    overflow: hidden !important;
}

/* =========================
   信息卡片
========================= */
.info-card {
    background-color: #f8f4f0 !important;
    border: 1px solid #e3ded9 !important;
    border-radius: 6px !important;
    padding: 12px !important;
    margin-bottom: 10px !important;
}

/* 进度输入框容器 */
div[data-testid="column"]:has(div[data-testid="stNumberInput"]) {
    padding-right: 10px !important;
}
</style>
""", unsafe_allow_html=True)

def load_top_background(bg_name='bar.png', height=180):
    """加载顶部背景图片"""
    bg_path = BACKGROUNDS_DIR / bg_name
    if not bg_path.exists():
        return
    
    try:
        with open(bg_path, 'rb') as f:
            encoded = base64.b64encode(f.read()).decode()
        
        st.markdown(f"""
        <style>
        .top-bg {{
            width: 100%;
            height: {height}px;
            background-image: url("data:image/png;base64,{encoded}");
            background-size: cover;
            background-position: center;
            border-radius: 0 0 12px 12px;
            margin-bottom: 10px;
        }}
        </style>
        <div class="top-bg"></div>
        """, unsafe_allow_html=True)
    except Exception as e:
        print(f"加载背景图片失败: {e}")
